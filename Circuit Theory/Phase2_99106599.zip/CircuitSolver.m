function result = CircuitSolver(input_path)
syms s t;
assumeAlso(t,'real');
assumeAlso(t,'positive')

text = fileread(input_path);
text1 = splitlines(text);
text1_size = size(text1);
Length = text1_size(1);
help = cell(1,8);
a = cell(1,8);
input = cell(Length,7);
for i=1:Length
    a = split(text1(i),',');
    a(numel(help))={0};
    input(i,:) = a(1:7);
end
%input = split(text1,',');
input_size = size(input);
elements = sym(zeros(input_size(1),5));
elements(:,1) = cell2sym(input(:,1));
elements(:,2) = cell2sym(input(:,2));
help = 0;
for i = 1:input_size(1)
    if str2double(input(i,3))> help
        help =  str2double(input(i,3));
    end
    if  str2double(input(i,4))> help
        help =  str2double(input(i,4));
    end
end
N = help;
nodes_voltage = sym('V_',[N,1]);
I_branches = sym('I_',[input_size(1),1]);
node_equations = sym(zeros(N,1));
extra_equations = sym(zeros(input_size(1),1));
elements(:,4) = I_branches; 
node1 = 0;
node2 = 0;
is = 0;Is=0;Vs=0;vs=0;R=0;Zl=0;Zc=0;Zm=0;a=0;
for i=1:input_size(1)
    node1 = str2double(input(i,3));
    node2 = str2double(input(i,4));
    if node1 == 0
        elements(i,3) = 0 - nodes_voltage(node2);
        node_equations(node2) = node_equations(node2)- elements(i,4);
    elseif node2 == 0
        elements(i,3) = nodes_voltage(node1);
        node_equations(node1) = node_equations(node1)+ elements(i,4);
    else
        elements(i,3) = nodes_voltage(node1) - nodes_voltage(node2);
        node_equations(node1) = node_equations(node1)+ elements(i,4);
        node_equations(node2) = node_equations(node2)- elements(i,4);
    end
    
    switch cell2mat(input(i,1))
        case 'R'
            R = str2double(input(i,5));
            extra_equations(i) = elements(i,3) - R*elements(i,4);
        case 'L'
            Zl = s*str2double(input(i,5));
            extra_equations(i) = elements(i,3) - Zl*elements(i,4);
            
        case 'C'
            Zc = 1/(s*str2double(input(i,5)));
            extra_equations(i) = elements(i,3) - Zc*elements(i,4);
        case 'ML'
            Zl = s*str2double(input(i,7));
            Zm = s*str2double(input(i,6));
            extra_equations(i) = elements(i,3)-Zl*elements(i,4)-Zm*elements(elements(:,2)==cell2sym(input(i,5)),4);
        case 'I'
            is = inline(cell2mat(input(i,5)),'t');
            Is = laplace(is(t),s);
            extra_equations(i) = elements(i,4) - Is;
        case 'V'
            vs = inline(cell2mat(input(i,5)),'t');
            Vs = laplace(vs(t),s);
            extra_equations(i) = elements(i,3) - Vs;
        case 'Z'
            a = str2double(input(i,6));
            extra_equations(i) = elements(i,3) - a * elements(elements(:,2)==cell2sym(input(i,5)),3);
        case 'Y'
            a = str2double(input(i,6));
            extra_equations(i) = elements(i,3) - a * elements(elements(:,2)==cell2sym(input(i,5)),4);
        case 'H'
            a = str2double(input(i,6));
            extra_equations(i) = elements(i,4) - a * elements(elements(:,2)==cell2sym(input(i,5)),3);
        case 'T'
            a = str2double(input(i,6));
            extra_equations(i) = elements(i,4) - a * elements(elements(:,2)==cell2sym(input(i,5)),4);
    end
end
node_equations = node_equations==0;
extra_equations = extra_equations==0;
Solution = solve([node_equations;extra_equations],[nodes_voltage;I_branches]);
elements(:,3:4) = subs(elements(:,3:4),[nodes_voltage;I_branches],cell2sym(struct2cell(Solution)));
elements(:,3:4) = ilaplace(elements(:,3:4),t);
elements(:,5) = elements(:,3) .* elements(:,4);
elements = simplify(elements);

fid = fopen("circuit_output.txt",'W');
text_format = '<%s><%s><%s><%s>\n';
fprintf(fid,text_format,transpose(elements(:,2:5)));
fclose(fid);

%plot
for i=1:input_size(1)
    figure;
    subplot(1,3,1);
    fplot(elements(i,3),"LineWidth",2,"Color",'b');
    title("Voltage","FontName",'serif',"FontSize",20);
    xlabel("$t$","Interpreter","Latex","Fontsize",20);
    grid minor;
    subplot(1,3,2);
    fplot(elements(i,4),"LineWidth",2,"Color",'r');
    title("Current","FontName",'serif',"FontSize",20);
    xlabel("$t$","Interpreter","Latex","Fontsize",20);
    grid minor;
    subplot(1,3,3);
    fplot(elements(i,5),"LineWidth",2,"Color",'g');
    title("Power","FontName",'serif',"FontSize",20);
    xlabel("$t$","Interpreter","Latex","Fontsize",20);
    grid minor;
    sgtitle("Element "+char(elements(i,2)),"FontName",'serif',"FontSize",30); 
end
result = "The Analyst was successful.";
end