%% Test CircuitSolver
clear;clc;close all;
result = CircuitSolver("input.txt");
disp(result);