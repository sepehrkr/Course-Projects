function [y1,y2] = analogDemod(y,fs,w,fc)
    t = 0:1/fs:(length(y)-1)/fs;
    help1 = y .* cos(2*pi*fc*t);
    help2 = y .* sin(2*pi*fc*t);
    y1 = lowPassFilter(help1,4*w,fs);
    y2 = lowPassFilter(help2,4*w,fs);

end

