function y = bandPassFilter(x,f1,f2,fs)
    L = length(x);
    X = fft(x);
    freq = (0:L-1)*fs/L;
    H = zeros(1,L);
    temp1 = (f1) / (fs/L);
    temp2 = (f2) / (fs/L);
    for i=temp1:temp2
        H(i) = 1;
        H(L-i+1) = 1;
    end
    y = real(ifft(H .* X));
end

