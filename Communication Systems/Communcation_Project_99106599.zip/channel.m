function y = channel(xc,fs,fc,w)
    f1 = fc - w/2;
    f2 = fc + w/2;
    %y = bandpass(xc,[f1,f2],fs);
    y = bandPassFilter(xc,f1,f2,fs);
end

