function  ber = checkBits(b,b_hat)
    L = length(b);
    help = (b==b_hat);
    ber = length(find(~help))/L;
end

