function b = combine(b1,b2)
    L = length(b1) + length(b2);
    b = zeros(1,L);
    for i=1:L
        if mod(i,2) == 0
            b(i) = b2(i/2);
        else
            b(i) = b1((i+1)/2);
        end
    end
end

