function [b1,b2] = divide(b)
    L = length(b);
    if mod(L,2) ~= 0
        ME = MException("Odd Length","the Length of b[n] must be even.");
        throw(ME);
    end
    b1 = b(1:2:end);
    b2 = b(2:2:end);
end

