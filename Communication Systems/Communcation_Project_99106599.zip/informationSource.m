function image = informationSource()
    Ix = [0,50,100,150,200,250];
    W = [0.5,1/32,1/8,1/16,1/32,1/4];
    image = zeros(28);
    for i=1:28
        image(i,:) = randsample(Ix,28,true,W);
    end
end

