function y = lowPassFilter(x,f_cut,fs)
    L = length(x);
    X = fft(x);
    freq = (0:L-1)*fs/L;
    H = zeros(1,L);
    temp = (f_cut) / (fs/L);
    for i=1:temp
        H(i) = 1;
        H(L-i+1) = 1;
    end
    y = real(ifft(H .* X));
end

