%% Section 3, Part 1-a
clear; clc; close all;
Tb = 0.01;
fs = 10^6;
fc = 10^4;
w = 10^3;
tmax = 0.5;
t = 0:1/fs:tmax-1/fs;
N = 2*tmax/Tb;
L = length(t);
% Divide
b = randi([0 1],1,N);
[b1,b2] = divide(b);
figure;
stem(1:2:N,b1,"filled");
hold on;
stem(2:2:N,b2,'filled');
grid minor;
xlabel("$n$","Interpreter","latex","FontSize",20);
legend(["$b_1[n]$","$b_2[n]$"],"Interpreter","latex");

% Pulse Shaping
p1 = rectangularPulse(0:1/fs:Tb-1/fs);
p0 = -p1;
x1 = pulseShaping(b1,p0,p1);
x2 = pulseShaping(b2,p0,p1);
figure;
subplot(211);
plot(t,x1,"LineWidth",1);
ylabel("$x_1(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;
subplot(212);
plot(t,x2,"LineWidth",1)
ylabel("$x_2(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;

% Analog Modulation
xc = analogMod(x1,x2,fc,fs);
figure;
plot(t,xc,"LineWidth",1);
ylabel("$x_c(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
xlim([0,0.05]);
grid minor;

% Channel
y = channel(xc,fs,fc,w);
figure;
plot(t,y,"LineWidth",1);
ylabel("$y(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
xlim([0,0.05]);
grid minor;

% Analog Demodulation
[y1,y2] = analogDemod(y,fs,w,fc);
figure;
subplot(211);
plot(t,y1,"LineWidth",1);
ylabel("$y_1(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;
subplot(212);
plot(t,y2,"LineWidth",1)
ylabel("$y_2(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;

% Matched Filter
[ym_1,a1] = matchedFilter(y1,p1,p0);
[ym_2,a2] = matchedFilter(y2,p1,p0);
figure;
subplot(211);
plot(t,ym_1(1:L),"LineWidth",1);
ylabel("$r_1(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;
subplot(212);
plot(t,ym_2(1:L),"LineWidth",1)
ylabel("$r_2(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;
figure;
stem(1:2:N,a1,"filled");
hold on;
stem(2:2:N,a2,"filled");
legend(["$\hat{b_1}[n]$","$\hat{b_2}[n]$"],"Interpreter","latex");
xlabel("$n$","Interpreter","latex","FontSize",20);
grid minor;

% Combine
b_hat = combine(a1,a2);
figure;
stem(1:N,b,"filled");
hold on;
stem(1:N,b_hat,"filled");
legend(["$b[n]$","$\hat{b}[n]$"],"Interpreter","latex");
xlabel("$n$","Interpreter","latex","FontSize",20);
grid minor;

%% Section 3, Part 1-b
% run "Section 3 Part 1-b" before!!!
clc;close all;
varn = 1:10:1000;
varn_length = length(varn);
ber = zeros(1,varn_length);
temp = 0;
for i = 1:varn_length
    for j = 1:20
        noise = normrnd(0,sqrt(varn(i)),1,L);
        y_n = channel(xc,fs,fc,w) + noise;
        [y1_n,y2_n] = analogDemod(y_n,fs,w,fc);
        [ym1_n,a1_n] = matchedFilter(y1_n,p1,p0);
        [ym2_n,a2_n] = matchedFilter(y2_n,p1,p0);
        b_hat_n = combine(a1_n,a2_n);
        temp = temp + checkBits(b,b_hat_n);
    end
    ber(i) = temp / 20;
    temp = 0;
end
figure;
plot(varn,ber,"LineWidth",1);
ylabel("$P_e$","Interpreter","latex","FontSize",20);
xlabel("$\sigma_{n}^2$","Interpreter","latex","FontSize",20);
grid minor;

%% Section 3 Part 1-c
% run "Section 3 Part 1-a" before!!!
clc;close all;
varn = [100,300,500,700,900,1000];
temp = 0;
Lp = length(p0);
ym1_n = zeros(6,N/2);
ym2_n = zeros(6,N/2);
temp = zeros(1,L+Lp-1);
k = 1:N/2;
for i=1:6
    noise = normrnd(0,sqrt(varn(i)),1,L);
    y_n = y + noise;
    [y1_n,y2_n] = analogDemod(y_n,fs,w,fc);
    [temp,bhat1_n] = matchedFilter(y1_n,p1,p0);
    ym1_n(i,:) = temp(k*Lp);
    [temp,bhat2_n] = matchedFilter(y2_n,p1,p0);
    ym2_n(i,:) = temp(k*Lp);
end

scatterplot(ym1_n(1,:)+1j*ym2_n(1,:));
ylabel("$\hat{b}_2[n]$","Interpreter","latex","FontSize",20);
xlabel("$\hat{b}_1[n]$","Interpreter","latex","FontSize",20);
title("$\sigma_{n}^2=100$","Interpreter","latex","FontSize",20);

scatterplot(ym1_n(2,:)+1j*ym2_n(2,:));
ylabel("$\hat{b}_2[n]$","Interpreter","latex","FontSize",20);
xlabel("$\hat{b}_1[n]$","Interpreter","latex","FontSize",20);
title("$\sigma_{n}^2=300$","Interpreter","latex","FontSize",20);

scatterplot(ym1_n(3,:)+1j*ym2_n(3,:));
ylabel("$\hat{b}_2[n]$","Interpreter","latex","FontSize",20);
xlabel("$\hat{b}_1[n]$","Interpreter","latex","FontSize",20);
title("$\sigma_{n}^2=500$","Interpreter","latex","FontSize",20);

scatterplot(ym1_n(4,:)+1j*ym2_n(4,:));
ylabel("$\hat{b}_2[n]$","Interpreter","latex","FontSize",20);
xlabel("$\hat{b}_1[n]$","Interpreter","latex","FontSize",20);
title("$\sigma_{n}^2=700$","Interpreter","latex","FontSize",20);

scatterplot(ym1_n(5,:)+1j*ym2_n(5,:));
ylabel("$\hat{b}_2[n]$","Interpreter","latex","FontSize",20);
xlabel("$\hat{b}_1[n]$","Interpreter","latex","FontSize",20);
title("$\sigma_{n}^2=900$","Interpreter","latex","FontSize",20);

scatterplot(ym1_n(6,:)+1j*ym2_n(6,:));
ylabel("$\hat{b}_2[n]$","Interpreter","latex","FontSize",20);
xlabel("$\hat{b}_1[n]$","Interpreter","latex","FontSize",20);
title("$\sigma_{n}^2=1000$","Interpreter","latex","FontSize",20);

%% Section 3 Part 2-a
clear; clc; close all;
Tb = 0.01;
fs = 10^6;
fc = 10^4;
w = 10^3;
tmax = 0.5;
t = 0:1/fs:tmax-1/fs;
N = 2*tmax/Tb;
L = length(t);

% Divide
b = randi([0 1],1,N);
[b1,b2] = divide(b);
figure;
stem(1:2:N,b1,"filled");
hold on;
stem(2:2:N,b2,'filled');
grid minor;
xlabel("$n$","Interpreter","latex","FontSize",20);
legend(["$b_1[n]$","$b_2[n]$"],"Interpreter","latex");

% Pulse Shaping
fp = 500;
p1 = sin(2*pi*fp*(0:1/fs:Tb-1/fs));
p0 = -p1;
x1 = pulseShaping(b1,p0,p1);
x2 = pulseShaping(b2,p0,p1);
figure;
subplot(211);
plot(t,x1,"LineWidth",1);
ylabel("$x_1(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;
subplot(212);
plot(t,x2,"LineWidth",1)
ylabel("$x_2(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;

% Analog Modulation
xc = analogMod(x1,x2,fc,fs);
figure;
plot(t,xc,"LineWidth",1);
ylabel("$x_c(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
xlim([0,0.05]);
grid minor;

% Channel
y = channel(xc,fs,fc,w);
figure;
plot(t,y,"LineWidth",1);
ylabel("$y(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
xlim([0,0.05]);
grid minor;

% Analog Demodulation
[y1,y2] = analogDemod(y,fs,w,fc);
figure;
subplot(211);
plot(t,y1,"LineWidth",1);
ylabel("$y_1(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;
subplot(212);
plot(t,y2,"LineWidth",1)
ylabel("$y_2(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;

% Matched Filter
[ym_1,a1] = matchedFilter(y1,p1,p0);
[ym_2,a2] = matchedFilter(y2,p1,p0);
figure;
subplot(211);
plot(t,ym_1(1:L),"LineWidth",1);
ylabel("$r_1(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;
subplot(212);
plot(t,ym_2(1:L),"LineWidth",1)
ylabel("$r_2(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;
figure;
stem(1:2:N,a1,"filled");
hold on;
stem(2:2:N,a2,"filled");
legend(["$\hat{b_1}[n]$","$\hat{b_2}[n]$"],"Interpreter","latex");
xlabel("$n$","Interpreter","latex","FontSize",20);
grid minor;

% Combine
b_hat = combine(a1,a2);
figure;
stem(1:N,b,"filled");
hold on;
stem(1:N,b_hat,"filled");
legend(["$b[n]$","$\hat{b}[n]$"],"Interpreter","latex");
xlabel("$n$","Interpreter","latex","FontSize",20);
grid minor;

%% Section 3, Part 2-b
% run "Section 3 Part 2-a" before!!!
clc;close all;
varn = 1:10:1000;
varn_length = length(varn);
ber = zeros(1,varn_length);
temp = 0;
for i = 1:varn_length
    for j = 1:20
        noise = normrnd(0,sqrt(varn(i)),1,L);
        y_n = channel(xc,fs,fc,w) + noise;
        [y1_n,y2_n] = analogDemod(y_n,fs,w,fc);
        [ym1_n,a1_n] = matchedFilter(y1_n,p1,p0);
        [ym2_n,a2_n] = matchedFilter(y2_n,p1,p0);
        b_hat_n = combine(a1_n,a2_n);
        temp = temp + checkBits(b,b_hat_n);
    end
    ber(i) = temp / 20;
    temp = 0;
end
figure;
plot(varn,ber,"LineWidth",1);
ylabel("$P_e$","Interpreter","latex","FontSize",20);
xlabel("$\sigma_{n}^2$","Interpreter","latex","FontSize",20);
grid minor;

%% Section 3 Part 2-c
% run "Section 3 Part 1-a" before!!!
clc;close all;
varn = [100,300,500,700,900,1000];
temp = 0;
Lp = length(p0);
ym1_n = zeros(6,N/2);
ym2_n = zeros(6,N/2);
temp = zeros(1,L+Lp-1);
k = 1:N/2;
for i=1:6
    noise = normrnd(0,sqrt(varn(i)),1,L);
    y_n = y + noise;
    [y1_n,y2_n] = analogDemod(y_n,fs,w,fc);
    [temp,bhat1_n] = matchedFilter(y1_n,p1,p0);
    ym1_n(i,:) = temp(k*Lp);
    [temp,bhat2_n] = matchedFilter(y2_n,p1,p0);
    ym2_n(i,:) = temp(k*Lp);
end

scatterplot(ym1_n(1,:)+1j*ym2_n(1,:));
ylabel("$\hat{b}_2[n]$","Interpreter","latex","FontSize",20);
xlabel("$\hat{b}_1[n]$","Interpreter","latex","FontSize",20);
title("$\sigma_{n}^2=100$","Interpreter","latex","FontSize",20);

scatterplot(ym1_n(2,:)+1j*ym2_n(2,:));
ylabel("$\hat{b}_2[n]$","Interpreter","latex","FontSize",20);
xlabel("$\hat{b}_1[n]$","Interpreter","latex","FontSize",20);
title("$\sigma_{n}^2=300$","Interpreter","latex","FontSize",20);

scatterplot(ym1_n(3,:)+1j*ym2_n(3,:));
ylabel("$\hat{b}_2[n]$","Interpreter","latex","FontSize",20);
xlabel("$\hat{b}_1[n]$","Interpreter","latex","FontSize",20);
title("$\sigma_{n}^2=500$","Interpreter","latex","FontSize",20);

scatterplot(ym1_n(4,:)+1j*ym2_n(4,:));
ylabel("$\hat{b}_2[n]$","Interpreter","latex","FontSize",20);
xlabel("$\hat{b}_1[n]$","Interpreter","latex","FontSize",20);
title("$\sigma_{n}^2=700$","Interpreter","latex","FontSize",20);

scatterplot(ym1_n(5,:)+1j*ym2_n(5,:));
ylabel("$\hat{b}_2[n]$","Interpreter","latex","FontSize",20);
xlabel("$\hat{b}_1[n]$","Interpreter","latex","FontSize",20);
title("$\sigma_{n}^2=900$","Interpreter","latex","FontSize",20);

scatterplot(ym1_n(6,:)+1j*ym2_n(6,:));
ylabel("$\hat{b}_2[n]$","Interpreter","latex","FontSize",20);
xlabel("$\hat{b}_1[n]$","Interpreter","latex","FontSize",20);
title("$\sigma_{n}^2=1000$","Interpreter","latex","FontSize",20);

%% Section 3, Part 3-a
clear; clc; close all;
Tb = 0.01;
fs = 10^6;
fc = 10^4;
w = 4*10^3;
tmax = 0.5;
t = 0:1/fs:tmax-1/fs;
N = 2*tmax/Tb;
L = length(t);

% Divide
b = randi([0 1],1,N);
[b1,b2] = divide(b);
figure;
stem(1:2:N,b1,"filled");
hold on;
stem(2:2:N,b2,'filled');
grid minor;
xlabel("$n$","Interpreter","latex","FontSize",20);
legend(["$b_1[n]$","$b_2[n]$"],"Interpreter","latex");

% Pulse Shaping
fp1 = 1000;
fp0 = 1500;
p1 = sin(2*pi*fp1*(0:1/fs:Tb-1/fs));
p0 = sin(2*pi*fp0*(0:1/fs:Tb-1/fs));
x1 = pulseShaping(b1,p0,p1);
x2 = pulseShaping(b2,p0,p1);
figure;
subplot(211);
plot(t,x1,"LineWidth",1);
ylabel("$x_1(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;
subplot(212);
plot(t,x2,"LineWidth",1)
ylabel("$x_2(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;

% Analog Modulation
xc = analogMod(x1,x2,fc,fs);
figure;
plot(t,xc,"LineWidth",1);
ylabel("$x_c(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
xlim([0,0.05]);
grid minor;

% Channel
y = channel(xc,fs,fc,w);
figure;
plot(t,y,"LineWidth",1);
ylabel("$y(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
xlim([0,0.05]);
grid minor;

% Analog Demodulation
[y1,y2] = analogDemod(y,fs,w,fc);
figure;
subplot(211);
plot(t,y1,"LineWidth",1);
ylabel("$y_1(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;
subplot(212);
plot(t,y2,"LineWidth",1)
ylabel("$y_2(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;

% Matched Filter
[ym_1,a1] = matchedFilter(y1,p1,p0);
[ym_2,a2] = matchedFilter(y2,p1,p0);
figure;
subplot(211);
plot(t,ym_1(1:L),"LineWidth",1);
ylabel("$r_1(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;
subplot(212);
plot(t,ym_2(1:L),"LineWidth",1)
ylabel("$r_2(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;
figure;
stem(1:2:N,a1,"filled");
hold on;
stem(2:2:N,a2,"filled");
legend(["$\hat{b_1}[n]$","$\hat{b_2}[n]$"],"Interpreter","latex");
xlabel("$n$","Interpreter","latex","FontSize",20);
grid minor;

% Combine
b_hat = combine(a1,a2);
figure;
stem(1:N,b,"filled");
hold on;
stem(1:N,b_hat,"filled");
legend(["$b[n]$","$\hat{b}[n]$"],"Interpreter","latex");
xlabel("$n$","Interpreter","latex","FontSize",20);
grid minor;

Xc = abs(fft(xc/L));
freq = (0:L/2-1)*fs/L;
Xc = Xc(1:end/2);
Xc(2:end) = 2 * Xc(2:end);
Y = abs(fft(y/L));
Y = Y(1:end/2);
Y(2:end) = 2 * Y(2:end);

figure;
plot(freq,Xc,freq,Y,"LineWidth",1);
grid minor;
legend(["$X_c(f)$","$Y(f)$"],"Interpreter","latex");
xlabel("$f$","Interpreter","latex",FontSize=20);

%% Section 3, Part 3-b
% 
clc;close all;
varn = 1:10:1000;
varn_length = length(varn);
ber = zeros(1,varn_length);
temp = 0;
for i = 1:varn_length
    for j = 1:20
        noise = normrnd(0,sqrt(varn(i)),1,L);
        y_n = channel(xc,fs,fc,w) + noise;
        [y1_n,y2_n] = analogDemod(y_n,fs,w,fc);
        [ym1_n,a1_n] = matchedFilter(y1_n,p1,p0);
        [ym2_n,a2_n] = matchedFilter(y2_n,p1,p0);
        b_hat_n = combine(a1_n,a2_n);
        temp = temp + checkBits(b,b_hat_n);
    end
    ber(i) = temp / 20;
    temp = 0;
end
figure;
plot(varn,ber,"LineWidth",1);
ylabel("$P_e$","Interpreter","latex","FontSize",20);
xlabel("$\sigma_{n}^2$","Interpreter","latex","FontSize",20);
grid minor;

%% Section 3 Part 3-c
% run "Section 3 Part 1-a" before!!!
clc;close all;
varn = [100,300,500,700,900,1000];
temp = 0;
Lp = length(p0);
ym1_n = zeros(6,N/2);
ym2_n = zeros(6,N/2);
temp = zeros(1,L+Lp-1);
k = 1:N/2;
for i=1:6
    noise = normrnd(0,sqrt(varn(i)),1,L);
    y_n = y + noise;
    [y1_n,y2_n] = analogDemod(y_n,fs,w,fc);
    [temp,bhat1_n] = matchedFilter(y1_n,p1,p0);
    ym1_n(i,:) = temp(k*Lp);
    [temp,bhat2_n] = matchedFilter(y2_n,p1,p0);
    ym2_n(i,:) = temp(k*Lp);
end

scatterplot(ym1_n(1,:)+1j*ym2_n(1,:));
ylabel("$\hat{b}_2[n]$","Interpreter","latex","FontSize",20);
xlabel("$\hat{b}_1[n]$","Interpreter","latex","FontSize",20);
title("$\sigma_{n}^2=100$","Interpreter","latex","FontSize",20);

scatterplot(ym1_n(2,:)+1j*ym2_n(2,:));
ylabel("$\hat{b}_2[n]$","Interpreter","latex","FontSize",20);
xlabel("$\hat{b}_1[n]$","Interpreter","latex","FontSize",20);
title("$\sigma_{n}^2=300$","Interpreter","latex","FontSize",20);

scatterplot(ym1_n(3,:)+1j*ym2_n(3,:));
ylabel("$\hat{b}_2[n]$","Interpreter","latex","FontSize",20);
xlabel("$\hat{b}_1[n]$","Interpreter","latex","FontSize",20);
title("$\sigma_{n}^2=500$","Interpreter","latex","FontSize",20);

scatterplot(ym1_n(4,:)+1j*ym2_n(4,:));
ylabel("$\hat{b}_2[n]$","Interpreter","latex","FontSize",20);
xlabel("$\hat{b}_1[n]$","Interpreter","latex","FontSize",20);
title("$\sigma_{n}^2=700$","Interpreter","latex","FontSize",20);

scatterplot(ym1_n(5,:)+1j*ym2_n(5,:));
ylabel("$\hat{b}_2[n]$","Interpreter","latex","FontSize",20);
xlabel("$\hat{b}_1[n]$","Interpreter","latex","FontSize",20);
title("$\sigma_{n}^2=900$","Interpreter","latex","FontSize",20);

scatterplot(ym1_n(6,:)+1j*ym2_n(6,:));
ylabel("$\hat{b}_2[n]$","Interpreter","latex","FontSize",20);
xlabel("$\hat{b}_1[n]$","Interpreter","latex","FontSize",20);
title("$\sigma_{n}^2=1000$","Interpreter","latex","FontSize",20);

%% Section 4, Part 2
clear; clc; close all;
Tb = 0.01;
fs = 10^6;
fc = 10^4;
w = 10^3;
N_int = 10;
numbers = randi([0 255],1,10);
tmax = Tb * N_int * 4;
t = 0:1/fs:tmax-1/fs;
N = 2*tmax/Tb;
L = length(t);
% Divide
b = sourceGenerator(numbers);
[b1,b2] = divide(b);
figure;
stem(1:2:N,b1,"filled");
hold on;
stem(2:2:N,b2,'filled');
grid minor;
xlabel("$n$","Interpreter","latex","FontSize",20);
legend(["$b_1[n]$","$b_2[n]$"],"Interpreter","latex");

% Pulse Shaping
p1 = rectangularPulse(0:1/fs:Tb-1/fs);
p0 = -p1;
x1 = pulseShaping(b1,p0,p1);
x2 = pulseShaping(b2,p0,p1);
figure;
subplot(211);
plot(t,x1,"LineWidth",1);
ylabel("$x_1(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;
subplot(212);
plot(t,x2,"LineWidth",1)
ylabel("$x_2(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;

% Analog Modulation
xc = analogMod(x1,x2,fc,fs);
figure;
plot(t,xc,"LineWidth",1);
ylabel("$x_c(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
xlim([0,0.05]);
grid minor;

% Channel
y = channel(xc,fs,fc,w);
figure;
plot(t,y,"LineWidth",1);
ylabel("$y(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
xlim([0,0.05]);
grid minor;

% Analog Demodulation
[y1,y2] = analogDemod(y,fs,w,fc);
figure;
subplot(211);
plot(t,y1,"LineWidth",1);
ylabel("$y_1(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;
subplot(212);
plot(t,y2,"LineWidth",1)
ylabel("$y_2(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;

% Matched Filter
[ym_1,a1] = matchedFilter(y1,p1,p0);
[ym_2,a2] = matchedFilter(y2,p1,p0);
figure;
subplot(211);
plot(t,ym_1(1:L),"LineWidth",1);
ylabel("$r_1(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;
subplot(212);
plot(t,ym_2(1:L),"LineWidth",1)
ylabel("$r_2(t)$","Interpreter","latex","FontSize",20);
xlabel("$t$","Interpreter","latex","FontSize",20);
grid minor;
figure;
stem(1:2:N,a1,"filled");
hold on;
stem(2:2:N,a2,"filled");
legend(["$\hat{b_1}[n]$","$\hat{b_2}[n]$"],"Interpreter","latex");
xlabel("$n$","Interpreter","latex","FontSize",20);
grid minor;

% Combine
b_hat = combine(a1,a2);
figure;
stem(1:N,b,"filled");
hold on;
stem(1:N,b_hat,"filled");
legend(["$b[n]$","$\hat{b}[n]$"],"Interpreter","latex");
xlabel("$n$","Interpreter","latex","FontSize",20);
grid minor;

% Output Decoder
numbers_hat = outputDecoder(b_hat);
figure;
stem(1:N_int,numbers,"filled");
hold on;
stem(1:N_int,numbers_hat,"filled");
legend(["transmitted numbers","recived numbers"]);
xlabel("$n$","Interpreter","latex","FontSize",20);
grid minor;

%% Section 4, Part 2, variance of error
% % "Section 4, Part2" must be run before!

varn = 1:10000:1000000;
varn_length = length(varn);
ber = zeros(1,varn_length);
temp = 0;
for i = 1:varn_length
    for j = 1:20
        noise = normrnd(0,sqrt(varn(i)),1,L);
        y_n = channel(xc,fs,fc,w) + noise;
        [y1_n,y2_n] = analogDemod(y_n,fs,w,fc);
        [ym1_n,a1_n] = matchedFilter(y1_n,p1,p0);
        [ym2_n,a2_n] = matchedFilter(y2_n,p1,p0);
        b_hat_n = combine(a1_n,a2_n);
        numbers_hat_n = outputDecoder(b_hat_n);
        temp = temp + var(numbers-numbers_hat_n);
    end
    ber(i) = temp / 20;
    temp = 0;
end
figure;
plot(varn,ber,"LineWidth",1);
ylabel("$\sigma_{error}^2$","Interpreter","latex","FontSize",20);
xlabel("$\sigma_{n}^2$","Interpreter","latex","FontSize",20);
grid minor;

%% Section 4, Part 3
% "Section 4, Part2" must be run before!
clc;close all;
varn = [500,600,700,800,900,1000];
varn_length = length(varn);
pmf = zeros(varn_length,100);
temp = 0;
for i = 1:varn_length
    for j = 1:100
        noise = normrnd(0,sqrt(varn(i)),1,L);
        y_n = channel(xc,fs,fc,w) + noise;
        [y1_n,y2_n] = analogDemod(y_n,fs,w,fc);
        [ym1_n,a1_n] = matchedFilter(y1_n,p1,p0);
        [ym2_n,a2_n] = matchedFilter(y2_n,p1,p0);
        b_hat_n = combine(a1_n,a2_n);
        numbers_hat_n = outputDecoder(b_hat_n);
        pmf(i,j) = sum((abs(numbers_hat_n-numbers)) .^ 2);
    end
end
figure;
subplot(3,3,1);
histogram(pmf(1,:));
title("$\sigma_{n}^2=500$","Interpreter","latex","FontSize",20);
grid minor;

subplot(3,3,2);
histogram(pmf(2,:));
title("$\sigma_{n}^2=600$","Interpreter","latex","FontSize",20);
grid minor;

subplot(3,3,3);
histogram(pmf(3,:));
title("$\sigma_{n}^2=700$","Interpreter","latex","FontSize",20);
grid minor;

subplot(3,3,4);
histogram(pmf(4,:));
title("$\sigma_{n}^2=800$","Interpreter","latex","FontSize",20);
grid minor;

subplot(3,3,5);
histogram(pmf(5,:));
title("$\sigma_{n}^2=900$","Interpreter","latex","FontSize",20);
grid minor;

subplot(3,3,6);
histogram(pmf(6,:));
title("$\sigma_{n}^2=1000$","Interpreter","latex","FontSize",20);
grid minor;

%% Section 5, Part 8
clc; clear; close all;
images = zeros(28,28,10);
images_hat = zeros(28,28,10);
for i=1:10
    images(:,:,i) = informationSource();
     b = sourceEncoder(images(:,:,i));
     images_hat(:,:,i) = sourceDecoder(b);
end
figure;
subplot(251);
imshow(images(:,:,1));
title("image1");
subplot(256)
imshow(images_hat(:,:,1));
title("decoded image1");

subplot(252);
imshow(images(:,:,2));
title("image2");
subplot(257)
imshow(images_hat(:,:,2));
title("decoded image2");

subplot(253);
imshow(images(:,:,3));
title("image3");
subplot(258)
imshow(images_hat(:,:,3));
title("decoded image3");

subplot(254);
imshow(images(:,:,4));
title("image4");
subplot(259)
imshow(images_hat(:,:,4));
title("decoded image4");

subplot(255);
imshow(images(:,:,5));
title("image5");
subplot(2,5,10);
imshow(images_hat(:,:,5));
title("decoded image5");

figure;
subplot(251);
imshow(images(:,:,6));
title("image6");
subplot(256)
imshow(images_hat(:,:,6));
title("decoded image6");

subplot(252);
imshow(images(:,:,7));
title("image7");
subplot(257)
imshow(images_hat(:,:,7));
title("decoded image7");

subplot(253);
imshow(images(:,:,8));
title("image8");
subplot(258)
imshow(images_hat(:,:,8));
title("decoded image8");

subplot(254);
imshow(images(:,:,9));
title("image9");
subplot(259)
imshow(images_hat(:,:,9));
title("decoded image9");

subplot(255);
imshow(images(:,:,10));
title("image10");
subplot(2,5,10);
imshow(images_hat(:,:,10));
title("decoded image10");

%% Section 5, Part 9
clc; clear; close all;
n = 1000;
images = zeros(28,28,n);
L_avg = zeros(n);
sum = 0;
for i=1:n
    images(:,:,i) = informationSource();
     b = sourceEncoder(images(:,:,i));
     sum = sum + length(b);
     L_avg(i) = sum / i;
end

figure;
plot((1:n),L_avg,"LineWidth",1);
grid minor;
xlabel("$n$","Interpreter","latex","FontSize",20);
ylabel("$L_{avg}$","Interpreter","latex","FontSize",20);