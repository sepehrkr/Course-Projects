function [x,a] = matchedFilter(y,p1,p0)
L_p = length(p0);
L = length(y);
N = round(L/L_p);
h = flip(p1) - flip(p0);
x = zeros(1,L+L_p-1);
a = zeros(1,N);
for i=1:N
    x((i-1)*L_p+1:(i+1)*L_p-1) = x((i-1)*L_p+1:(i+1)*L_p-1) + conv(y((i-1)*L_p+1:i*L_p),h)/L_p;
end
ph1 = conv(p1,h)/L_p;
ph0 = conv(p0,h)/L_p;
lambda = (ph1(L_p) + ph0(L_p))/2;
for i=1:N
    if x(i*L_p) > lambda
        a(i) = 1;
    else
        a(i) = 0;
    end
end
end