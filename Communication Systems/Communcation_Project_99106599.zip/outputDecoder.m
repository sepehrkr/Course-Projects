function a = outputDecoder(b)
    a = transpose(bit2int(b',8));
end

