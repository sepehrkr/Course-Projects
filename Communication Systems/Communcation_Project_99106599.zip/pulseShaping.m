function x = pulseShaping(b,p0,p1)
    if length(p0) ~= length(p1)
        ME = MException("Pulse Error:Different Length","p0, p1 must have same length!");
        throw(ME);
    end
    L_b = length(b);
    L_p = length(p0);
    x = zeros(1,L_b*L_p);
    for i=1:L_b
        if b(i)==0
            x((i-1)*L_p+1:i*L_p) = p0;
        else
            x((i-1)*L_p+1:i*L_p) = p1;
        end
    end
end

