function image = sourceDecoder(b)
    L = length(b);
    i = 1;
    k = 1;
    image = zeros(28);
    while i<=L
        j = i;
        while b(j) == 0
            j = j+1;
        end
        switch j-i+1
            case 1
                image(k) = 0;
            case 2
                image(k) = 250;
            case 3
                image(k) = 100;
            case 4
                image(k) = 150;
            case 5
                image(k) = 50;
            case 6
                image(k) = 200;
        end
        k = k+1;
        i = j+1;
    end
end

