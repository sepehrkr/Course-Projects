function b = sourceEncoder(image)
    L = 28*28;
    b = zeros(1,L*6);
    i = 1;
    j = 1;
    while j <= L
        switch image(j)
            case 0
                b(i) = 1;
                i = i+1;
            case 50
                b(i)=0; b(i+1)=0; b(i+2)=0; b(i+3)=0; b(i+4)=1;
                i = i+5;
            case 100
                b(i)=0; b(i+1)=0; b(i+2)=1;
                i = i+3;
            case 150
                b(i)=0; b(i+1)=0; b(i+2)=0; b(i+3)=1;
                i = i+4;
            case 200
                b(i)=0; b(i+1)=0; b(i+2)=0; b(i+3)=0; b(i+4)=0; b(i+5)=1;
                i = i+6;
            case 250
                b(i)=0; b(i+1)=1;
                i = i+2;
        end
        j = j+1;
    end
    b = b(1:i-1);
end

