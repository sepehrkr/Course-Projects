function b = sourceGenerator(a)
    L = length(a);
    help = int2bit(a,8);
    b = zeros(1,L*8);
    for i=1:L
        b(8*(i-1)+1:8*i) = help(:,i);
    end
end