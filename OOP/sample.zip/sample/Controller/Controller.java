package sample.Controller;

import sample.Model.*;
import sample.Model.animal.*;
import sample.Model.factory.*;
import sample.Model.product.*;
import sample.View.InputCommand;
import sample.View.OutputProcessor;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class Controller {
    public Mission mission;
    ArrayList<Mission> missions;
    public static ArrayList<Person> users;
    Map map;
    OutputProcessor output;
    public int Well;
    public boolean wellRequest;
    MyTime time;
    public int currentLevel;
    public Level[] level;
    public Level[] levelAlter;

    public int buyAnimal(String name) {
        long coins = levelAlter[currentLevel].coins;
        Task task = this.levelAlter[currentLevel].task;
        boolean isBought = false;
        switch (name) {
            case "buffalo":
                if (coins - Price.BUFFALO.getPrice() >= 0) {
                    Map.domestics.add(new Buffalo());
                    levelAlter[currentLevel].coins -= Price.BUFFALO.getPrice();
                    task.setDomestic("Buffalo", 1);
                    isBought = true;
                }
                break;
            case "cat":
                if (coins - Price.CAT.getPrice() >= 0) {
                    Map.cats.add(new Cat());
                    levelAlter[currentLevel].coins -= Price.CAT.getPrice();
                    isBought = true;
                }
                break;
            case "chicken":
                if (coins - Price.CHICKEN.getPrice() >= 0) {
                    Map.domestics.add(new Chicken());
                    levelAlter[currentLevel].coins -= Price.CHICKEN.getPrice();
                    task.setDomestic("Chicken", 1);
                    isBought = true;
                }
                break;
            case "dog":
                if (coins - Price.DOG.getPrice() >= 0) {
                    Map.dogs.add(new Dog());
                    levelAlter[currentLevel].coins -= Price.DOG.getPrice();
                    isBought = true;
                }
                break;
            case "turkey":
                if (coins - Price.TURKEY.getPrice() >= 0) {
                    Map.domestics.add(new Turkey());
                    levelAlter[currentLevel].coins -= Price.TURKEY.getPrice();
                    task.setDomestic("Turkey", 1);
                    isBought = true;
                }
                break;
            /*default:
                Log.logCompile("There is no animal with this name!", "error");
                output.printError("There is no animal with this name!");
                return;*/
        }
        if (isBought) {
            Log.logCompile("User bought this animal successfully", "info");
            //output.printResult("You successfully bought this animal\nYour coins : " + levelAlter[currentLevel].coins);
            return 1;
        } else {
            Log.logCompile("User coins is not enough to buy this animal!", "error");
            /*output.printError("Your coins is not enough!");*/
            return -1;
        }

    }

    public int pickUp(int row, int col) {
        Store store = Store.getInstance();
        if (row <= 6 && row >= 1 && col <= 6 && col >= 1) {
            int a1 = store.pickupProduct(row, col);
            if (a1 == 1) {
                Log.logCompile("The product is picked up", "info");
                output.printResult("The product is picked up.");
                return 1;
            }
            if (a1 == -1) {
                Log.logCompile("The store has not enough storage to keep the product!", "error");
                output.printError("The store has not enough storage to keep the product!");
            }
            if (a1 == -4) {
                Log.logCompile("There is no product in this coordinate!", "error");
                output.printError("There is no product in this coordinate!");
            }
        } else {
            Log.logCompile("INVALID INPUT in pickUp in Controller!", "error");
            output.invalidInputError();
        }
        return -1;
    }

    public boolean pickupWild (int row , int col){
        Store store = Store.getInstance();
        if (row <= 6 && row >= 1 && col <= 6 && col >= 1) {
            int a2 = store.pickupWild(row, col);
            if (a2 == 1) {
                Log.logCompile("The wild is picked up", "info");
                output.printResult("The wild is picked up");
                return true;
            }
            if (a2 == -5) {
                Log.logCompile("The wild animal is not caged", "error");
                output.printError("The wild animal is not caged!");
            }
            if (a2 == -6) {
                Log.logCompile("Caged animal can be picked up one time unit later", "error");
                output.printError("You should wait one time unit to pick this animal!");
            }
            if (a2 == -1) {
                Log.logCompile("The store has not enough storage to keep the wild!", "error");
                output.printError("The store has not enough storage to keep the wild!");
            }
            if (a2 == -4) {
                Log.logCompile("There is no wild in this coordinate!", "error");
                output.printError("There is no wild in this coordinate!");
            }
        } else {
            Log.logCompile("INVALID INPUT in pickUp in Controller!", "error");
            output.invalidInputError();
        }
        return false;
    }

    public boolean well() {
        if (Well == 0) {
            wellRequest = true;
            Log.logCompile("User well is done", "info");
            output.printResult("Your request done.");
            return true;
        } else {
            Log.logCompile("The User Bucket is not empty!", "error");
            output.printError("Yore bucket is not empty!");
            return false;
        }
    }

    public boolean plant(int row, int col) {
        if (row <= 6 && row >= 1 && col <= 6 && col >= 1) {
            if (Well > 0) {
                Grass.addGrass(row, col);
                Log.logCompile("The grass added", "info");
                output.printResult("The grass added.");
                Well--;
                return true;
            } else {
                Log.logCompile("The User bucket is  empty!", "error");
                output.printError("Your bucket is empty!");
                return false;
            }
        } else {
            Log.logCompile("INVALID INPUT in plant in Controller", "error");
            output.invalidInputError();
            return false;
        }
    }

    public int build(String factoryName) {
        int a = 0;
        long coins = levelAlter[currentLevel].coins;
        switch (factoryName) {
            case "bakery f":
                if (Map.getThereBakeryF() == null) {
                    if (coins - Price.BAKERY_F.getPrice() >= 0) {
                        Map.factories.add(new BakeryF());
                        levelAlter[currentLevel].coins -= Price.BAKERY_F.getPrice();
                        a = 1;
                    } else a = -2;
                } else a = -1;
                break;
            case "ice cream f":
                if (Map.getThereIceCreamF() == null) {
                    if (coins - Price.ICE_CREAM_F.getPrice() >= 0) {
                        Map.factories.add(new IceCreamF());
                        levelAlter[currentLevel].coins -= Price.ICE_CREAM_F.getPrice();
                        a = 1;
                    } else a = -2;
                } else a = -1;
                break;
            case "milk f":
                if (Map.getThereMilkF() == null) {
                    if (coins - Price.MILK_F.getPrice() >= 0) {
                        Map.factories.add(new MilkF());
                        levelAlter[currentLevel].coins -= Price.MILK_F.getPrice();
                        a = 1;
                    } else a = -2;
                } else a = -1;
                break;
            case "mill f":
                if (coins - Price.MILL_F.getPrice() >= 0) {
                    if (Map.getThereMillF() == null) {
                        Map.factories.add(new MillF());
                        levelAlter[currentLevel].coins -= Price.MILL_F.getPrice();
                        a = 1;
                    } else a = -2;
                } else a = -1;
                break;
            case "tailoring f":
                if (Map.getThereTailoringF() == null) {
                    if (coins - Price.TAILORING_F.getPrice() >= 0) {
                        Map.factories.add(new TailoringF());
                        levelAlter[currentLevel].coins -= Price.TAILORING_F.getPrice();
                        a = 1;
                    } else a = -2;
                } else a = -1;
                break;
            case "textile f":
                if (Map.getThereTextileF() == null) {
                    if (coins - Price.TEXTILE_F.getPrice() >= 0) {
                        Map.factories.add(new TextileF());
                        levelAlter[currentLevel].coins -= Price.TEXTILE_F.getPrice();
                        a = 1;
                    } else a = -2;
                } else a = -1;
                break;
            case "chicken f":
                if (Map.getThereChickenF() == null) {
                    if (coins - Price.CHICKEN_F.getPrice() >= 0) {
                        Map.factories.add(new ChickenF());
                        levelAlter[currentLevel].coins -= Price.CHICKEN_F.getPrice();
                        a = 1;
                    } else a = -2;
                } else a = -1;
                break;
        }
        if (a == 1) {
            Log.logCompile("the factory is successfully built", "info");
           /* output.printResult("the factory is successfully built.");*/
            return 1;
        } else if (a == -1) {
            Log.logCompile("This factory is already exist", "error");
            /*output.printError("This factory is already exist!");*/
            return -1;
        } else if (a == -2) {
            Log.logCompile("User coin is not enough!", "error");
            /*output.printError("Your coin is not enough!");*/
            return -1;
        } /*else {
            Log.logCompile("INVALID INPUT in build in Controller", "error");
            output.invalidInputError();
        }*/
        return 0;
    }

    public boolean work(String factoryName) {
        Factory factory;
        int a = 0;
        switch (factoryName) {
            case "bakery f":
                if ((factory = Map.getThereBakeryF()) != null) {
                    a = factory.work();
                }
                break;
            case "ice cream f":
                if ((factory = Map.getThereIceCreamF()) != null) {
                    a = factory.work();
                }
                break;
            case "milk f":
                if ((factory = Map.getThereMilkF()) != null) {
                    a = factory.work();
                }
                break;
            case "mill f":
                if (((factory = Map.getThereMillF()) != null)) {
                    a = factory.work();
                }
                break;
            case "tailoring f":
                if ((factory = Map.getThereTailoringF()) != null) {
                    a = factory.work();
                }
                break;
            case "textile f":
                if ((factory = Map.getThereTextileF()) != null) {
                    a = factory.work();
                }
                break;
            case "chicken f":
                if ((factory = Map.getThereChickenF()) != null) {
                    a = factory.work();
                }
                break;
            default:
                output.invalidInputError();
                return false;
        }
        if (a == 1) {
            Log.logCompile("The factory Start working ...", "info");
            output.printResult("start working ...");
            return true;
        } else if (a == -1) {
            Log.logCompile("There is no Supply!", "error");
            output.printError("There is no Supply!");
        } else if (a == -2) {
            Log.logCompile("The factory is already working!", "error");
            output.printError("The factory is already working!");
        } else if (a==0) {
            Log.logCompile("There is no factory in map!", "error");
            output.printError("There is no factory in map!");
        }
        return false;
    }

    public int upgrade(String factoryName) {
        int a = 0;
        long coins = levelAlter[currentLevel].coins;
        switch (factoryName) {
            case "bakery f":
                if (Map.getThereBakeryF() != null) {
                    if (coins - Price.BAKERY_F_UPGRADE.getPrice() >= 0) {
                        a = Map.getThereBakeryF().upgrade();
                        if (a == 1)
                            levelAlter[currentLevel].coins -= Price.BAKERY_F_UPGRADE.getPrice();
                    } else a = -4;
                } else a = -3;
                break;
            case "ice cream f":
                if (Map.getThereIceCreamF() != null) {
                    if (coins - Price.ICE_CREAM_F_UPGRADE.getPrice() >= 0) {
                        a = Map.getThereIceCreamF().upgrade();
                        if (a == 1)
                            levelAlter[currentLevel].coins -= Price.ICE_CREAM_F_UPGRADE.getPrice();
                    } else a = -4;
                } else a = -3;
                break;
            case "milk f":
                if (Map.getThereMilkF() != null) {
                    if (coins - Price.MILK_F_UPGRADE.getPrice() >= 0) {
                        a = Map.getThereMilkF().upgrade();
                        if (a == 1)
                            levelAlter[currentLevel].coins -= Price.MILK_F_UPGRADE.getPrice();
                    } else a = -4;
                } else a = -3;
                break;
            case "mill f":
                if (Map.getThereMillF() != null) {
                    if (coins - Price.MILL_F_UPGRADE.getPrice() >= 0) {
                        a = Map.getThereMillF().upgrade();
                        if (a == 1)
                            levelAlter[currentLevel].coins -= Price.MILL_F_UPGRADE.getPrice();
                    } else a = -4;
                } else a = -3;
                break;
            case "tailoring f":
                if (Map.getThereTailoringF() != null) {
                    if (coins - Price.TAILORING_F_UPGRADE.getPrice() >= 0) {
                        a = Map.getThereTailoringF().upgrade();
                        if (a == 1)
                            levelAlter[currentLevel].coins -= Price.TAILORING_F_UPGRADE.getPrice();
                    } else a = -4;
                } else a = -3;
                break;
            case "textile f":
                if (Map.getThereTextileF() != null) {
                    if (coins - Price.TEXTILE_F_UPGRADE.getPrice() >= 0) {
                        a = Map.getThereTextileF().upgrade();
                        if (a == 1)
                            levelAlter[currentLevel].coins -= Price.TEXTILE_F_UPGRADE.getPrice();
                    } else a = -4;
                } else a = -3;
                break;
            case "chicken f":
                if (Map.getThereChickenF() != null) {
                    if (coins - Price.CHICKEN_F_UPGRADE.getPrice() >= 0) {
                        a = Map.getThereChickenF().upgrade();
                        if (a == 1)
                            levelAlter[currentLevel].coins -= Price.CHICKEN_F_UPGRADE.getPrice();
                    } else a = -4;
                } else a = -3;
                break;
        }
        if (a == 1) {
            Log.logCompile("The factory upgraded", "info");
            /*output.printResult("The factory upgraded successfully");*/
            return 1;
        } else if (a == -1) {
            Log.logCompile("The factory already is in the Max level!", "error");
           /* output.printError("The factory already is in the Max level");*/
            return -1;
        } else if (a == -2) {
            Log.logCompile("The factory is working!", "error");
            /*output.printError("The factory is working!\nPlease try later.");*/
            return -1;
        } else if (a == -3) {
            Log.logCompile("There is not this factory in the map", "error");
           /* output.printError("There is not this factory in the map");*/
            return -1;
        } else if (a == -4) {
            Log.logCompile("Your coins is not enough!", "error");
           /* output.printError("Your coins is not enough!");*/
            return -1;
        }
        return 0;
    }

    public boolean cage(int row, int col) {
        if (row <= 6 && row >= 1 && col <= 6 && col >= 1) {
            boolean isThere = false;
            boolean isCaged = false;
            int a = -2;
            for (Wild wild : Map.wilds)
                if (wild.row == row && wild.col == col) {
                    a = wild.cage();
                    if (wild.cages == wild.maxCage) {
                        isCaged = true;
                    }
                    isThere = true;
                }
            if (isThere && a == 1 && !isCaged) {
                Log.logCompile("the wild animal cages increased", "info");
                output.printResult("Cage units increased!");
                return true;
            } else if (isThere && a == 1) {
                Log.logCompile("the wild animal caged successfully", "info");
                output.printResult("Animal caged! wait one time unit to pick up");
                return true;
            } else if (isThere && a == 0) {
                Log.logCompile("attempt to do more than one cage for one animal", "error");
                output.printError("Only one cage per time unit!");
            } else if (isThere && a == -1) {
                Log.logCompile("attempt to cage a caged animal", "error");
                output.printError("Already caged!");
            } else if (!isThere) {
                Log.logCompile("attempt to cage some place with no wild animal", "error");
                output.printError("There is no wild animal here!");
            }
        } else {
            Log.logCompile("INVALID INPUT in Cage in Controller!", "error");
            output.invalidInputError();
        }
        return false;
    }

    public void turn(int n) throws IOException {
        Update.getInstance().updateAll(n);
        Log.logCompile("showInquiry is called", "info");
        showInquiry();
    }

    public int truckLoad(String itemName) {
        if (Vehicle.getInstance().isState()) {
            int a = Vehicle.getInstance().truckLoad(itemName);
            if (a == 1) {
                Log.logCompile("The item Successfully load in Truck", "info");
                output.printResult("Successfully load");
                return 1;
            } else if (a == -1) {
                Log.logCompile("The capacity of Truck is not enough!", "error");
                output.printError("The capacity of Truck is not enough!");
                return -1;
            } else if (a == -2) {
                Log.logCompile("The item is not available in the store!", "info");
                output.printError("The item is not available in the store!");
                return -2;
            } else if (a == -3) {
                Log.logCompile("INVALID INPUT in truckLoad in Controller", "error");
                output.invalidInputError();
                return -3;
            }
        } else {
            Log.logCompile("The truck is not here!", "error");
            output.printError("The truck is not here!");
            return -4;
        }
        return 0;
    }

    public int truckUnload(String itemName) {
        if (Vehicle.getInstance().isState()) {
            int a = Vehicle.getInstance().truckUnLoad(itemName);
            if (a == 1) {
                Log.logCompile("The item has Successfully unloaded of truck", "info");
                output.printResult("Successfully unload.");
                return 1;
            } else if (a == -1) {
                Log.logCompile("The capacity of store is not enough!", "error");
                output.printError("The capacity of store is not enough!");
                return -1;
            } else if (a == -2) {
                Log.logCompile("The item is not available in the truck!", "error");
                output.printError("The item is not available in the truck!");
                return -2;
            } else if (a == -3) {
                Log.logCompile("INVALID INPUT in truckUnload in Controller", "error");
                output.invalidInputError();
                return -3;
            }
        } else {
            Log.logCompile("The truck is not here!", "error");
            output.printError("The truck is not here!");
            return -4;
        }
        return 0;
    }

    public boolean truckGO() {
        Vehicle truck = Vehicle.getInstance();
        if (truck.isState()) {
            truck.setState(false);
            Log.logCompile("The travel of truck starts ...", "info");
            output.printResult("The travel of truck starts...");
            return true;
        } else {
            Log.logCompile("The truck already left!", "error");
            output.printError("The truck already left!");
            return false;
        }
    }

    public void showInquiry() {
        System.out.println("Time : "+MyTime.getInstance().time);
        Map.showGrass();
        for (Domestic domestic : Map.domestics) {
            System.out.println(nameA(domestic) + " " + domestic.life + "%" + " [" + domestic.row + " " + domestic.col + "]");
        }
        for (Wild wild : Map.wilds) {
            System.out.println(nameA(wild) + " " + (wild.maxCage - wild.cages) + " [" + wild.row + " " + wild.col + "]");
        }
        for (Dog dog : Map.dogs) {
            System.out.println("Dog" + " [" + dog.row + " " + dog.col + "]");
        }
        for (Cat cat : Map.cats) {
            System.out.println("Cat" + " [" + cat.row + " " + cat.col + "]");
        }
        for (Product product : Map.products) {
            System.out.println(nameP(product) + " [" + product.row + " " + product.col + "]");
        }
        System.out.println("Store current storage : "+Store.getInstance().currentStorage);
        showTask();
    }

    void showTask() {
        Task task = levelAlter[currentLevel].task;
        if (task.EGGS != 0)
            output.printResult("Egg : " + task.getCurrentEggs() + "/" + task.EGGS);
        if (task.FEATHERS != 0)
            output.printResult("Feather : " + task.getCurrentFeathers() + "/" + task.FEATHERS);
        if (task.MILKS != 0)
            output.printResult("Milk : " + task.getCurrentMilks() + "/" + task.MILKS);
        if (task.FLOURS != 0)
            output.printResult("Flour : " + task.getCurrentFlours() + "/" + task.FLOURS);
        if (task.CLOTHS != 0)
            output.printResult("Cloth : " + task.getCurrentCloths() + "/" + task.CLOTHS);
        if (task.PACK_MILKS != 0)
            output.printResult("Pack Milk : " + task.getCurrentPackMilks() + "/" + task.PACK_MILKS);
        if (task.BREADS != 0)
            output.printResult("Bread : " + task.getCurrentBreads() + "/" + task.BREADS);
        if (task.SHIRTS != 0)
            output.printResult("Shirt : " + task.getCurrentShirts() + "/" + task.SHIRTS);
        if (task.ICE_CREAMS != 0)
            output.printResult("Ice cream : " + task.getCurrentIceCreams() + "/" + task.ICE_CREAMS);
        if (task.CHICKENS != 0)
            output.printResult("Chicken : " + task.getCurrentChickens() + "/" + task.CHICKENS);
        if (task.TURKEYS != 0)
            output.printResult("Turkey : " + task.getCurrentTurkeys() + "/" + task.TURKEYS);
        if (task.BUFFALOES != 0)
            output.printResult("Buffalo : " + task.getCurrentBuffaloes() + "/" + task.BUFFALOES);
        if (task.COINS != 0)
            output.printResult("Coin : " + levelAlter[currentLevel].coins + "/" + task.COINS);
    }

    public static boolean addPerson(String username, String password) {
        for (Person user : users) {
            if (user.getUsername().equals(username)) {
                return false;
            }
        }
        users.add(new Person(username, password));
        return true;
    }

    public void doRegistration (){
        //File file = new File("files\\missions.txt");
        String s = Database.read_missions();
        ObjectMapper mapper = new ObjectMapper();
        mapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        try {
            controller_instance.missions = mapper.readValue(s, new TypeReference<ArrayList<Mission>>() {});
        } catch (IOException e) {
            e.printStackTrace();
        }
        Mission mission = new Mission(users.get(users.size() - 1), controller_instance.resetLevelAlter());
        controller_instance.missions.add(mission);
        controller_instance.mission = mission;
        controller_instance.level=mission.levels;
    }

    public static Person getPerson(String username, String password) {
        for (Person user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return user;
            }
        }
        return null;
    }

    public static boolean checkRegistration (String username){
        for (Person person : users){
            if (person.getUsername().equals(username))
                return false;
        }
        return true;
    }

    public static void readPerson() {
        //File file = new File("files\\users.txt");
        String s = Database.readUsers();
        ObjectMapper mapper = new ObjectMapper();
        mapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        try {
            users = mapper.readValue(s, new TypeReference<ArrayList<Person>>() {});
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static boolean checkTask(int Level) {
        Task task = controller_instance.levelAlter[Level].task;
        return task.getCurrentEggs() >= task.EGGS && task.getCurrentFeathers() >= task.FEATHERS && task.getCurrentMilks() >= task.MILKS
                && task.getCurrentFlours() >= task.FLOURS && task.getCurrentCloths() >= task.CLOTHS && task.getCurrentPackMilks() >= task.PACK_MILKS
                && task.getCurrentBreads() >= task.BREADS && task.getCurrentShirts() >= task.SHIRTS && task.getCurrentIceCreams() >= task.ICE_CREAMS
                && controller_instance.levelAlter[controller_instance.currentLevel].coins >= task.COINS && task.getCurrentChickens()>=task.CHICKENS
                && task.getCurrentTurkeys()>=task.TURKEYS && task.getCurrentBuffaloes()>=task.BUFFALOES ;
    }

    public String checkLevelForStart(int stage) {
        if (stage >= 0 && stage <= 4) {
            if (level[stage].timeFinished == -1) {
                if (stage == 0)
                    return "the first try for level 1";
                else {
                    if (this.level[stage - 1].timeFinished != -1)
                        return "the first try for level [stage]";
                    else return "incorrect level";
                }
            } else {
                return "again level";
            }

        } else return "invalid";
    }

    public Level[] resetLevelAlter() {
        /*Task task1 = new Task(4, 2, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 200L);
        Task task2 = new Task(5, 3, 2, 1, 0, 0, 0, 0, 0, 3, 0, 0, 350L);
        Task task3 = new Task(0, 0, 0, 0, 2, 2, 0, 0, 0, 4, 1, 0, 500L);
        Task task4 = new Task(0, 0, 0, 0, 0, 0, 4, 2, 2, 2, 4, 0, 800L);
        Task task5 = new Task(0, 0, 0, 0, 0, 0, 8, 4, 4, 0, 5, 4, 1500L);
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////
        HashMap<Wild, Integer> wildShowTime1 = new HashMap<>();
        wildShowTime1.put(new Lion(), 3);
        wildShowTime1.put(new Lion(), 5);
        HashMap<Wild, Integer> wildShowTime2 = new HashMap<>();
        wildShowTime2.put(new Bear(), 2);
        wildShowTime2.put(new Lion(), 2);
        wildShowTime2.put(new Bear(), 6);
        HashMap<Wild, Integer> wildShowTime3 = new HashMap<>();
        wildShowTime3.put(new Lion(), 3);
        wildShowTime3.put(new Lion(), 3);
        wildShowTime3.put(new Lion(), 3);
        wildShowTime3.put(new Tiger(), 9);
        HashMap<Wild, Integer> wildShowTime4 = new HashMap<>();
        wildShowTime4.put(new Bear(), 3);
        wildShowTime4.put(new Bear(), 3);
        wildShowTime4.put(new Bear(), 3);
        wildShowTime4.put(new Tiger(), 10);
        wildShowTime4.put(new Tiger(), 12);
        HashMap<Wild, Integer> wildShowTime5 = new HashMap<>();
        wildShowTime5.put(new Tiger(), 5);
        wildShowTime5.put(new Bear(), 5);
        wildShowTime5.put(new Bear(), 5);
        wildShowTime5.put(new Tiger(), 10);
        wildShowTime5.put(new Tiger(), 14);
        wildShowTime5.put(new Tiger(), 14);
        wildShowTime5.put(new Tiger(), 25);
        ArrayList<Wild> wild1 = new ArrayList<>(wildShowTime1.keySet());
        ArrayList<Integer> ShowTime1 =new ArrayList<>(wildShowTime1.values());
        ArrayList<Wild> wild2 = new ArrayList<>(wildShowTime2.keySet());
        ArrayList<Integer> ShowTime2 =new ArrayList<>(wildShowTime2.values());
        ArrayList<Wild> wild3 = new ArrayList<>(wildShowTime3.keySet());
        ArrayList<Integer> ShowTime3 =new ArrayList<>(wildShowTime3.values());
        ArrayList<Wild> wild4 = new ArrayList<>(wildShowTime4.keySet());
        ArrayList<Integer> ShowTime4 =new ArrayList<>(wildShowTime4.values());
        ArrayList<Wild> wild5 = new ArrayList<>(wildShowTime5.keySet());
        ArrayList<Integer> ShowTime5 =new ArrayList<>(wildShowTime5.values());
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        HashMap<Integer, Long> timePrize1 = new HashMap<>();
        timePrize1.put(40, 400L);
        timePrize1.put(45, 200L);
        timePrize1.put(50, 100L);
        HashMap<Integer, Long> timePrize2 = new HashMap<>();
        timePrize2.put(50, 400L);
        timePrize2.put(55, 200L);
        timePrize2.put(60, 100L);
        HashMap<Integer, Long> timePrize3 = new HashMap<>();
        timePrize3.put(60, 400L);
        timePrize3.put(65, 200L);
        timePrize3.put(70, 100L);
        HashMap<Integer, Long> timePrize4 = new HashMap<>();
        timePrize4.put(70, 400L);
        timePrize4.put(75, 200L);
        timePrize4.put(80, 100L);
        HashMap<Integer, Long> timePrize5 = new HashMap<>();
        timePrize5.put(80, 400L);
        timePrize5.put(85, 200L);
        timePrize5.put(90, 100L);
        ArrayList<Integer> time1 =new ArrayList<>(timePrize1.keySet());
        ArrayList<Long> Prize1 = new ArrayList<>(timePrize1.values());
        ArrayList<Integer> time2 =new ArrayList<>(timePrize2.keySet());
        ArrayList<Long> Prize2 = new ArrayList<>(timePrize2.values());
        ArrayList<Integer> time3 =new ArrayList<>(timePrize3.keySet());
        ArrayList<Long> Prize3 = new ArrayList<>(timePrize3.values());
        ArrayList<Integer> time4 =new ArrayList<>(timePrize4.keySet());
        ArrayList<Long> Prize4 = new ArrayList<>(timePrize4.values());
        ArrayList<Integer> time5 =new ArrayList<>(timePrize5.keySet());
        ArrayList<Long> Prize5 = new ArrayList<>(timePrize5.values());
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Level[] levels = new Level[5];
        levels[0] = new Level(1, 150, wild1,ShowTime1, task1, -1, time1,Prize1);
        levels[1] = new Level(2, 250, wild2,ShowTime2, task2, -1, time2,Prize2);
        levels[2] = new Level(3, 250,wild3,ShowTime3, task3, -1, time3,Prize3);
        levels[3] = new Level(4, 300, wild4,ShowTime4, task4, -1, time4,Prize4);
        levels[4] = new Level(5, 300, wild5,ShowTime5, task5, -1, time5,Prize5);*/
        //File file = new File("files\\Mission.txt");
        String s = Database.readMission();
        ObjectMapper mapper =new ObjectMapper();
        mapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        Level[] levels;
        try {
            levels = mapper.readValue(s, new TypeReference<Level[]>() {});
            return levels;
        } catch (IOException e) {
            e.printStackTrace();
        }
        OutputProcessor.getInstance().printError("System Error in Controller ResetLevelAlter method!!!!!!!");
        return null;
    }

    public Level deepCopyLevelAlter() throws CloneNotSupportedException {
        int coins = levelAlter[currentLevel].coins;
        ArrayList<Wild> wildCopied = new ArrayList<>();
        ArrayList<Wild> wilds = levelAlter[currentLevel].wild;
        for (Wild wild : wilds)
        {
            wildCopied.add((Wild) wild.clone());
        }
        ArrayList<Integer> ShowTime = (ArrayList<Integer>) levelAlter[currentLevel].ShowTime.clone();
        ArrayList<Integer> time = (ArrayList<Integer>) levelAlter[currentLevel].time.clone();
        ArrayList<Long> Prize = (ArrayList<Long>) levelAlter[currentLevel].Prize.clone();
        Task taskCopied = (Task) levelAlter[currentLevel].task.clone();
        return new Level(levelAlter[currentLevel].levelNum, level[currentLevel].coins, wildCopied,ShowTime,taskCopied,levelAlter[currentLevel].timeFinished,time,Prize);
    }

    public Long ResetLevel() throws CloneNotSupportedException {
        if (levelAlter[currentLevel].timeFinished != -1 && level[currentLevel].timeFinished != -1) {
            if (levelAlter[currentLevel].timeFinished < level[currentLevel].timeFinished) {
                level[currentLevel] = deepCopyLevelAlter();
            }
        } else if (levelAlter[currentLevel].timeFinished != -1 && level[currentLevel].timeFinished == -1) {
            level[currentLevel] = deepCopyLevelAlter();
        }
        Map.domestics.clear();
        Map.cats.clear();
        Map.products.clear();
        Map.dogs.clear();
        Map.wilds.clear();
        Map.factories.clear();
        Map.grasses.clear();
        Store.getInstance().storeEggs.clear();
        Store.getInstance().storeFeathers.clear();
        Store.getInstance().storeMilks.clear();
        Store.getInstance().storeFlours.clear();
        Store.getInstance().storeClothes.clear();
        Store.getInstance().storePackMilks.clear();
        Store.getInstance().storeBreads.clear();
        Store.getInstance().storeShirts.clear();
        Store.getInstance().storeIceCreams.clear();
        Store.getInstance().storeWilds.clear();
        Store.getInstance().currentStorage = 0;
        Vehicle.getInstance().eggs.clear();
        Vehicle.getInstance().feathers.clear();
        Vehicle.getInstance().milks.clear();
        Vehicle.getInstance().flours.clear();
        Vehicle.getInstance().clothes.clear();
        Vehicle.getInstance().packMilks.clear();
        Vehicle.getInstance().breads.clear();
        Vehicle.getInstance().shirts.clear();
        Vehicle.getInstance().iceCreams.clear();
        Vehicle.getInstance().wilds.clear();
        Vehicle.getInstance().setCurrentStorage(0);
        Vehicle.getInstance().setState(true);
        int[] times = new int[3];
        long[] prizes = new long[3];
        int i = 0;
        for (Integer t : levelAlter[currentLevel].time)
        {
            times[i]=t;
            i++;
        }
        i=0;
        for (Long pr : levelAlter[currentLevel].Prize)
        {
            prizes[i]=pr;
            i++;
        }
        Arrays.sort(times);
        Arrays.sort(prizes);
        long time = MyTime.getInstance().time;
        long totalPrize=0;
        if (levelAlter[currentLevel].timeFinished!=-1 && time <= times[0]) {
            totalPrize = prizes[2];
        }
        else if (levelAlter[currentLevel].timeFinished!=-1 && time > times[0] && time <= times[1]) {
            totalPrize = prizes[1];
        }
        else if (levelAlter[currentLevel].timeFinished!=-1 && time > times[1] && time <= times[2]) {
            totalPrize = prizes[0];
        }
        else if (levelAlter[currentLevel].timeFinished!=-1 && time > times[2]) {
            totalPrize = (times[2] / time) * prizes[0];
        }
        levelAlter = resetLevelAlter();
        System.out.println(levelAlter[currentLevel + 1].coins);
        System.out.println(level[currentLevel + 1].coins);
        if (currentLevel == 0 || currentLevel == 1 || currentLevel == 2 || currentLevel == 3) {
            levelAlter[currentLevel + 1].coins += totalPrize;
            level[currentLevel+1].coins+=totalPrize;
            System.out.println(levelAlter[currentLevel + 1].coins);
            System.out.println(mission.levels[currentLevel+1].coins);
        }

        MyTime.getInstance().time=0;
        wellRequest=false;
        Well=5;
        Update.getInstance().TruckTime=0;
        Update.getInstance().wellTime=0;
        return totalPrize;
    }

    String nameA(Animal animal) {
        if (animal instanceof Chicken) {
            return "Chicken";
        }
        if (animal instanceof Turkey) {
            return "Turkey";
        }
        if (animal instanceof Buffalo) {
            return "Buffalo";
        }
        if (animal instanceof Lion) {
            return "Lion";
        }
        if (animal instanceof Bear) {
            return "Bear";
        }
        if (animal instanceof Tiger) {
            return "Tiger";
        }
        return null;
    }

    String nameP(Product product) {
        if (product instanceof Egg) {
            return "Egg";
        } else if (product instanceof Feather) {
            return "Feather";
        } else if (product instanceof Milk) {
            return "Milk";
        } else if (product instanceof Flour) {
            return "Flour";
        } else if (product instanceof Cloth) {
            return "Cloth";
        } else if (product instanceof PackMilk) {
            return "PackMilk";
        } else if (product instanceof Bread) {
            return "Bread";
        } else if (product instanceof Shirt) {
            return "Shirt";
        } else if (product instanceof IceCream) {
            return "IceCream";
        }
        return null;
    }

    public void saveGame() {
        //File file = new File("files\\missions.txt");
        ObjectMapper mapper = new ObjectMapper();
        mapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        try {
           // mapper.writeValue(file, missions);
            String s = mapper.writeValueAsString(missions);
            Database.update_missions(s);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void saveUsers()
    {
        //File file =new File("files\\users.txt");
        ObjectMapper mapper =new ObjectMapper();
        mapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        try {
           // mapper.writeValue(file,users);
            String s = mapper.writeValueAsString(users);
            Database.updateUsers(s);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void initializeMission(Person person) {
        //File file = new File("files\\missions.txt");
        String s = Database.read_missions();
        ObjectMapper mapper = new ObjectMapper();
        mapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        try {
            this.missions = mapper.readValue(s, new TypeReference<ArrayList<Mission>>() {
            });
            for (Mission mission : this.missions) {
                if (mission.person.getUsername().equals(person.getUsername()) && mission.person.getPassword().equals(person.getPassword())) {
                    controller_instance.mission = mission;
                    level = mission.levels;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // singleton design
    private static Controller controller_instance = null;

    private Controller() {
    }

    public static Controller getInstance() {
        if (controller_instance == null) {
            controller_instance = new Controller();
            controller_instance.map = Map.getInstance();
            controller_instance.output = OutputProcessor.getInstance();
            controller_instance.time = MyTime.getInstance();
            controller_instance.Well = 5;
            controller_instance.wellRequest = false;
            controller_instance.levelAlter = getInstance().resetLevelAlter();
        }
        return controller_instance;
    }

}
