package sample.Controller;

import java.sql.*;

public class Database {

   public static Connection connection;
   public static Statement statement;

    static {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/project_faze2","root","root");
            statement = connection.createStatement();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public static void updateUsers (String s) {
        try {
            statement.executeUpdate("UPDATE users SET jsonString='"+s+"'");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    public static void update_missions (String s){
        try {
            statement.executeUpdate("UPDATE missions SET jsonString='"+s+"'");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }
    public static String readMission (){
        try {
            ResultSet resultSet = statement.executeQuery("SELECT * FROM mission ");
            String s = "";
            while (resultSet.next()){
                s = resultSet.getString("jsonString");
            }
            return s;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }

    public static String readUsers (){
        try {
            ResultSet resultSet = statement.executeQuery("SELECT * FROM users ");
            String s = "";
            while (resultSet.next()){
                s = resultSet.getString("jsonString");
            }
            return s;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }

    public static String read_missions (){
        try {
            ResultSet resultSet = statement.executeQuery("SELECT * FROM missions ");
            String s = "";
            while (resultSet.next()){
                s = resultSet.getString("jsonString");
            }
            return s;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }

}
