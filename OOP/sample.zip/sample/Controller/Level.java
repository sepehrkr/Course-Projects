package sample.Controller;

import sample.Model.Person;
import sample.Model.animal.Domestic;
import sample.Model.animal.Lion;
import sample.Model.animal.Other;
import sample.Model.animal.Wild;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Stack;

public class Level implements Cloneable {
    public int levelNum;
    public int coins;
    public ArrayList<Wild> wild;
    public ArrayList<Integer> ShowTime;
    public Task task;
    public int timeFinished;
    public ArrayList<Integer> time ;
    public ArrayList<Long> Prize;

    public Level(int levelNum, int coins, ArrayList<Wild> wild, ArrayList<Integer> showTime, Task task, int timeFinished, ArrayList<Integer> time, ArrayList<Long> prize) {
        this.levelNum = levelNum;
        this.coins = coins;
        this.wild = wild;
        ShowTime = showTime;
        this.task = task;
        this.timeFinished = timeFinished;
        this.time = time;
        Prize = prize;
    }

    public Level() {
    }
}
