package sample.Controller;
import sample.Model.Person;
import sample.View.OutputProcessor;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Log {
    public static Person person;
    public static Logger logger;
    public static FileHandler handler;
    static {
        logger = Logger.getLogger("GameLog");
        try {
            handler =new FileHandler("files\\log.txt",true);
            handler.setFormatter(new SimpleFormatter());
            logger.addHandler(handler);
            logger.setUseParentHandlers(false);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void initialize (Person person1)
    {
        person = person1;
        logger.info(person.getUsername()+"      "+person.getPassword());
    }
    public static void logCompile (String message , String format)
    {
        switch (format)
        {
            case "info" :
                logger.info(message);
                break;
            case "error":
                logger.warning(message);
                break;
            default:
                OutputProcessor.getInstance().printError("Error in logCompile in Log Class!");
        }
    }
}
