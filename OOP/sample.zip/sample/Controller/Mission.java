package sample.Controller;

import  sample.Model.Person;
import  sample.Model.animal.Wild;

import java.util.HashMap;

public class Mission {

    Person person;
    public Level [] levels;

    public Mission(Person person, Level[] levels) {
        this.person = person;
        this.levels = levels;
    }

    public Mission() {
    }
}
