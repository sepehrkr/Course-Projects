package sample.Controller;

import javafx.application.Platform;
import javafx.concurrent.Task;
import sample.View.Menu1.GameMenu;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

public class MyTime  {
    public long time;
    public boolean exited = false;

    public void add(int n)
    {
        this.time+=n;
    }


    public long getTime() {
        return time;
    }

    public static int timeUnit = 1 ;   // in second



   /* @Override
    public void run() {
        Timer timer = new Timer();
        TimerTask timerTask =new TimerTask() {
            @Override
            public void run() {
                if (!exited) {
                    try {
                        Controller.getInstance().turn(1);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    this.cancel();
                }
            }
        };
        timer.schedule(timerTask,0L,timeUnit* 1000L);
    }
*/

    public void execute (){
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                while (!exited) {
                    try {
                        Controller.getInstance().turn(1);
                        System.out.println(time);
                        Thread.sleep(1000);
                    } catch (IOException | InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }




    // singleton design
    private static MyTime myTime_instance=null;
    private MyTime () {
    }


    public static MyTime getInstance()
    {
        if (myTime_instance==null){
            myTime_instance=new MyTime();
            myTime_instance.time=0;
        }
        return myTime_instance;
    }

}