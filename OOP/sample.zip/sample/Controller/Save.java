package sample.Controller;

import sample.Model.animal.Domestic;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.annotation.*;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.FileHandler;
import java.util.logging.Logger;

public class Save {
    public static ObjectMapper mapper;
    public static Logger logger;
    static {
        mapper=new ObjectMapper();
        mapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
    }
    public static <T> void save (T target , File file)
    {
        try {
            mapper.writeValue(file ,target);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static <T> ArrayList<T> load (Class<T> target , File file)
    {
        mapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        try {
            return mapper.readValue(file, new TypeReference<ArrayList<T>>() {});
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
