package sample.Controller;

import sample.Model.animal.Animal;
import sample.Model.animal.Domestic;
import sample.Model.animal.Other;
import sample.Model.animal.Wild;
import sample.Model.product.Product;

import java.util.ArrayList;
import java.util.HashMap;

public class Task implements Cloneable {
    public int EGGS;
    private int currentEggs;
    public int FEATHERS;
    private int currentFeathers;
    public int MILKS;
    private int currentMilks;
    public int FLOURS;
    private int currentFlours;
    public int CLOTHS;
    private int currentCloths;
    public int PACK_MILKS;
    private int currentPackMilks;
    public int BREADS;
    private int currentBreads;
    public int SHIRTS;
    private int currentShirts;
    public int ICE_CREAMS;
    private int currentIceCreams;
    public int CHICKENS;
    private int currentChickens;
    public int TURKEYS;
    private int currentTurkeys;
    public int BUFFALOES;
    private int currentBuffaloes;
    public long COINS;
    private int currentCoins;

    Task() {
    }

    public Task(int EGGS, int FEATHERS, int MILKS, int FLOURS, int CLOTHS, int PACK_MILKS, int BREADS, int SHIRTS, int ICE_CREAMS, int CHICKENS, int TURKEYS, int BUFFALOES, long COINS) {
        this.EGGS = EGGS;
        this.currentEggs = 0;
        this.FEATHERS = FEATHERS;
        this.currentFeathers = 0;
        this.MILKS = MILKS;
        this.currentMilks = 0;
        this.FLOURS = FLOURS;
        this.currentFlours = 0;
        this.CLOTHS = CLOTHS;
        this.currentCloths = 0;
        this.PACK_MILKS = PACK_MILKS;
        this.currentPackMilks = 0;
        this.BREADS = BREADS;
        this.currentBreads = 0;
        this.SHIRTS = SHIRTS;
        this.currentShirts = 0;
        this.ICE_CREAMS = ICE_CREAMS;
        this.currentIceCreams = 0;
        this.CHICKENS = CHICKENS;
        this.currentChickens = 0;
        this.TURKEYS = TURKEYS;
        this.currentTurkeys = 0;
        this.BUFFALOES = BUFFALOES;
        this.currentBuffaloes = 0;
        this.COINS = COINS;
        this.currentCoins = 0;
    }


    public int getCurrentEggs() {
        return currentEggs;
    }

    public int getCurrentFeathers() {
        return currentFeathers;
    }

    public int getCurrentMilks() {
        return currentMilks;
    }

    public int getCurrentFlours() {
        return currentFlours;
    }

    public int getCurrentCloths() {
        return currentCloths;
    }

    public int getCurrentPackMilks() {
        return currentPackMilks;
    }

    public int getCurrentBreads() {
        return currentBreads;
    }

    public int getCurrentShirts() {
        return currentShirts;
    }

    public int getCurrentIceCreams() {
        return currentIceCreams;
    }

    public int getCurrentChickens() {
        return currentChickens;
    }

    public int getCurrentTurkeys() {
        return currentTurkeys;
    }

    public int getCurrentBuffaloes() {
        return currentBuffaloes;
    }

    public int getCurrentCoins() {
        return currentCoins;
    }

    public void setCurrentEggs(int currentEggs) {
        if (currentEggs>=0) {
            this.currentEggs = currentEggs;
        }
    }

    public void setCurrentFeathers(int currentFeathers) {
        if (currentFeathers>=0) {
            this.currentFeathers = currentFeathers;
        }
    }

    public void setCurrentMilks(int currentMilks) {
        if (currentMilks>=0) {
            this.currentMilks = currentMilks;
        }
    }

    public void setCurrentFlours(int currentFlours) {
        if (currentFlours>=0) {
            this.currentFlours = currentFlours;
        }
    }

    public void setCurrentCloths(int currentCloths) {
        if (currentCloths>=0) {
            this.currentCloths = currentCloths;
        }
    }

    public void setCurrentPackMilks(int currentPackMilks) {
        if (currentPackMilks>=0) {
            this.currentPackMilks = currentPackMilks;
        }
    }

    public void setCurrentBreads(int currentBreads) {
        if (currentBreads>=0) {
            this.currentBreads = currentBreads;
        }
    }

    public void setCurrentShirts(int currentShirts) {
        if (currentShirts>=0) {
            this.currentShirts = currentShirts;
        }
    }

    public void setCurrentIceCreams(int currentIceCreams) {
        if (currentIceCreams>=0) {
            this.currentIceCreams = currentIceCreams;
        }
    }

    public void setCurrentCoins(int currentCoins) {
        if (currentCoins>=0) {
            this.currentCoins = currentCoins;
        }
    }
    public void setDomestic (String name , int n)
    {
        switch (name)
        {
            case "Chicken" :
                if (this.currentChickens+n >=0)
                    this.currentChickens+=n;
                break;
            case "Turkey" :
                if (this.currentTurkeys+n>=0)
                    this.currentTurkeys+=n;
                break;
            case "Buffalo" :
                if (this.currentBuffaloes+n>=0)
                    this.currentBuffaloes+=n;
                break;
        }
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
