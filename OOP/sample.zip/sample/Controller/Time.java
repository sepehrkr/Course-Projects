package sample.Controller ;

public enum Time {
    BRING_WATER_OF_WELL(3),
    EGG_PRODUCE(2), FEATHER(3), MILK_PRODUCE(5),
    FLOUR_PRODUCE(4), CLOTH_PRODUCE(5), FINAL_MILK_PRODUCE(6), BREAD_PRODUCE(5), SHIRT_PRODUCE(6), ICE_CREAM_PRODUCE(7),
    RAW_PRODUCT_DISAPPEAR(4), MID_PRODUCT_DISAPPEAR(5), FINAL_PRODUCT_DISAPPEAR(6) , WILD_ANIMAL_DISAPPEAR(5),
    TRUCK_TRAVEL(10);

    int value;
    Time(int value) {
        this.value=value;
    }

    public int getValue() {
        return value;
    }
}
