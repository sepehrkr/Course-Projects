package sample.Controller;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.image.ImageView;
import javafx.util.Duration;
import sample.Main;
import sample.Model.Grass;
import sample.Model.Map;
import sample.Model.Price;
import sample.Model.Vehicle;
import sample.Model.animal.*;
import sample.Model.factory.*;
import sample.Model.product.*;
import sample.Model.product.Product;
import sample.View.Menu1.*;

import java.io.IOException;
import java.util.Objects;

public class Update {
    int wellTime;
    int TruckTime;

    void setObject (){
        System.out.println("---------------------------------------");
        System.out.println("setObject method called...");
        System.out.println(MainMenu.gameMenu.getFarm().getChildren().size());
        MainMenu.gameMenu.getFarm().getChildren().clear();
        MainMenu.gameMenu.getFarm().getChildren().addAll(GameMenu.domestics);
        MainMenu.gameMenu.getFarm().getChildren().addAll(GameMenu.wilds);
        MainMenu.gameMenu.getFarm().getChildren().addAll(GameMenu.cats);
        MainMenu.gameMenu.getFarm().getChildren().addAll(GameMenu.dogs);
        MainMenu.gameMenu.getFarm().getChildren().addAll(GameMenu.products);
        MainMenu.gameMenu.getFarm().getChildren().addAll(GameMenu.grasses);
        System.out.println(MainMenu.gameMenu.getFarm().getChildren().size());
        System.out.println("---------------------------------------");
    }

    public void updateAll(int n) throws IOException {
         MainMenu.gameMenu.getFarm().getChildren().clear();
         addGrass();
         addProduct();
        //setObject();

        for (int i = 1; i <= n; i++) {
            MyTime.getInstance().add(1);
            MainMenu.gameMenu.time.setText(Long.toString(MyTime.getInstance().time));
            GameMenu.checkTask();
            addWild();
            WellDelay(i);
            TruckGO();
            Factory.update();
            Factory.produce();
            checkFactory();
            Domestic.lifeDecrease();
            Domestic.lifeChecker();
            for (Cat cat : Map.cats) {
                int row = cat.row;
                int col = cat.col;
                cat.move();
               MainMenu.gameMenu.moveCat(cat,row,col);
            }
            Cat.productChecker();
            Cat.pick();
            Wild.update();
            Wild.kill();
            Tiger.killT();
            Dog.kill();
            Dog.killT();
            Domestic.foodChecker();
            Domestic.update();
            Domestic.produce();
            int j=0;
            for (Domestic domestic : Map.domestics) {
                int row = domestic.row;
                int col = domestic.col;
                domestic.move();
                MainMenu.gameMenu.moveDomestic(domestic,row,col,j);
                j++;
            }
            j=0;
            Domestic.eat();
            for (Wild wild : Map.wilds) {
                int row = wild.row;
                int col = wild.col;
                wild.move();
                MainMenu.gameMenu.moveWild(wild,row,col,j);
                j++;
            }
            for (Dog dog : Map.dogs) {
                int row = dog.row;
                int col = dog.col;
                dog.move();
                MainMenu.gameMenu.moveDog(dog,row,col);
            }
            Product.update();
            updateTask();
        }
    }
    void WellDelay(int n) {
        if(Controller.getInstance().wellRequest) {
            wellTime++;
            if (wellTime==3) {
                long time1 = MyTime.getInstance().time;
                Controller.getInstance().wellRequest = false;
                Controller.getInstance().Well = 5;
                wellTime=0;
                GameMenu.wellAnimation.stop();
                MainMenu.gameMenu.well.setViewport(new Rectangle2D(0,0,148,150));
            }
        }
    }

    void TruckGO ()
    {
        Vehicle truck = Vehicle.getInstance();
        if (!truck.isState()) {
            TruckTime++;
            if (TruckTime == 10) {
                Level level = Controller.getInstance().levelAlter[Controller.getInstance().currentLevel];
                level.coins += truck.eggs.size() * Price.EGG.getPrice() + truck.feathers.size() * Price.FEATHER.getPrice()
                        + truck.milks.size() * Price.MILK.getPrice() + truck.flours.size() * Price.FLOUR.getPrice()
                        + truck.clothes.size() * Price.CLOTH.getPrice() + truck.packMilks.size() * Price.PACK_MILK.getPrice()
                        + truck.breads.size() * Price.BREAD.getPrice() + truck.shirts.size() * Price.SHIRT.getPrice()
                        + truck.iceCreams.size() * Price.ICE_CREAM.getPrice();
                for (Wild wild : truck.wilds) {
                    if (wild instanceof Lion)
                        level.coins += Price.LION.getPrice();
                    else if (wild instanceof Bear)
                        level.coins += Price.BEAR.getPrice();
                    else if (wild instanceof Tiger)
                        level.coins += Price.TIGER.getPrice();
                }
                MainMenu.gameMenu.coin.setText(Long.toString(level.coins));
                truck.setCurrentStorage(0);
                truck.eggs.clear();
                truck.feathers.clear();
                truck.milks.clear();
                truck.flours.clear();
                truck.clothes.clear();
                truck.packMilks.clear();
                truck.breads.clear();
                truck.shirts.clear();
                truck.iceCreams.clear();
                truck.wilds.clear();
                truck.setState(true);
                TruckTime=0;
                ImageView imageView = new ImageView(MyImage.vehicle_left);
                Animation animation = new SpriteAnimation(imageView, Duration.millis(300),MyImage.vehicle_left_count,MyImage.vehicle_left_column,0,0,MyImage.vehicle_left_width,MyImage.vehicle_left_height);
                animation.setCycleCount(Animation.INDEFINITE);
                animation.play();
                MainMenu.gameMenu.mainPane.getChildren().add(imageView);
                TranslateTransition transition = new TranslateTransition();
                transition.setDuration(Duration.millis(3000));
                transition.setInterpolator(Interpolator.LINEAR);
                transition.setNode(imageView);
                transition.setFromX(1250);
                transition.setFromY(200);
                transition.setToX(370);
                transition.setToY(200);
                transition.play();
                transition.setOnFinished(e -> {
                    TranslateTransition transition1 = new TranslateTransition();
                    transition1.setDuration(Duration.millis(3000));
                    transition1.setInterpolator(Interpolator.LINEAR);
                    transition1.setNode(imageView);
                    transition1.setFromX(370);
                    transition1.setFromY(200);
                    transition1.setToX(370);
                    transition1.setToY(598);
                    transition1.play();
                    transition1.setOnFinished( s ->{
                        MainMenu.gameMenu.mainPane.getChildren().remove(imageView);
                        MainMenu.gameMenu.vehicle.setVisible(true);
                    });
                });
            }
        }
    }
    void addWild ()
    {
        Level level = Controller.getInstance().levelAlter[Controller.getInstance().currentLevel];
        for (int i=0; i<level.wild.size();i++){
            if (MyTime.getInstance().time==level.ShowTime.get(i)){
                Map.wilds.add(level.wild.get(i));
            }
        }
    }

    void updateTask () {
        int chickenCount=0;
        int turkeyCount=0;
        int buffaloCount=0;
        for (Domestic domestic : Map.domestics){
            if (domestic instanceof Chicken)
                chickenCount++;
            else if (domestic instanceof Turkey)
                turkeyCount++;
            else if (domestic instanceof Buffalo)
                buffaloCount++;
        }
        Task task = Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].task;
        task.setDomestic("chicken",chickenCount);
        task.setDomestic("turkey",turkeyCount);
        task.setDomestic("buffalo",buffaloCount);
    }

    public static void addGrass () {
        double [] coordinate;
        for (Grass grass : Map.grasses){
            ImageView imageView = new ImageView(MyImage.grassFixed);
            coordinate = GameMenu.convertTo(grass.row,grass.col);
            imageView.setLayoutX(coordinate[0]);
            imageView.setLayoutY(coordinate[1]);
            MainMenu.gameMenu.getFarm().getChildren().add(imageView);
        }
    }

    public  void addProduct (){
        double [] coordinate ;
        ImageView imageView;
        for(Product product : Map.products){
            imageView = new ImageView();
            coordinate = GameMenu.convertTo(product.row,product.col);
            if (product instanceof Bread){
                imageView.setImage(MyImage.bread);
                ImageView finalImageView = imageView;
                imageView.setOnMouseClicked(e ->  {
                    GameMenu.gotoMouseMethod=false;
                    Controller.getInstance().pickUp(product.row,product.col);
                    finalImageView.setVisible(false);
                });
            } else if (product instanceof Cloth){
                imageView.setImage(MyImage.cloth);
                ImageView finalImageView1 = imageView;
                imageView.setOnMouseClicked(e ->  {
                    GameMenu.gotoMouseMethod=false;
                    Controller.getInstance().pickUp(product.row,product.col);
                    finalImageView1.setVisible(false);
                });
            } else if (product instanceof Egg){
                imageView.setImage(MyImage.egg);
                ImageView finalImageView2 = imageView;
                imageView.setOnMouseClicked(e ->  {
                    GameMenu.gotoMouseMethod=false;
                    Controller.getInstance().pickUp(product.row,product.col);
                    finalImageView2.setVisible(false);
                });
            } else if (product instanceof Feather){
                imageView.setImage(MyImage.feather);
                ImageView finalImageView3 = imageView;
                imageView.setOnMouseClicked(e ->  {
                    GameMenu.gotoMouseMethod=false;
                    Controller.getInstance().pickUp(product.row,product.col);
                    finalImageView3.setVisible(false);
                });
            } else if (product instanceof Flour){
                imageView.setImage(MyImage.flour);
                ImageView finalImageView4 = imageView;
                imageView.setOnMouseClicked(e ->  {
                    GameMenu.gotoMouseMethod=false;
                    Controller.getInstance().pickUp(product.row,product.col);
                    finalImageView4.setVisible(false);
                });
            } else if (product instanceof IceCream){
                imageView.setImage(MyImage.iceCream);
                ImageView finalImageView5 = imageView;
                imageView.setOnMouseClicked(e ->  {
                    GameMenu.gotoMouseMethod=false;
                    Controller.getInstance().pickUp(product.row,product.col);
                    finalImageView5.setVisible(false);
                });
            } else if (product instanceof Milk){
                imageView.setImage(MyImage.milk);
                ImageView finalImageView6 = imageView;
                imageView.setOnMouseClicked(e ->  {
                    GameMenu.gotoMouseMethod=false;
                    Controller.getInstance().pickUp(product.row,product.col);
                    finalImageView6.setVisible(false);
                });
            } else if (product instanceof PackMilk){
                imageView.setImage(MyImage.packMilk);
                ImageView finalImageView7 = imageView;
                imageView.setOnMouseClicked(e ->  {
                    GameMenu.gotoMouseMethod=false;
                    Controller.getInstance().pickUp(product.row,product.col);
                    finalImageView7.setVisible(false);
                });
            } else if (product instanceof Shirt){
                imageView.setImage(MyImage.shirt);
                ImageView finalImageView8 = imageView;
                imageView.setOnMouseClicked(e ->  {
                    GameMenu.gotoMouseMethod=false;
                    Controller.getInstance().pickUp(product.row,product.col);
                    finalImageView8.setVisible(false);
                });
            }
            imageView.setLayoutX(coordinate[0]);
            imageView.setLayoutY(coordinate[1]);
            MainMenu.gameMenu.getFarm().getChildren().add(imageView);
        }
    }

    public void checkFactory (){
        System.out.println(Map.factories.size());
        for (Factory factory : Map.factories) {
            if (factory instanceof BakeryF) {
                if (!factory.isWorking && GameMenu.bakeryAnimation != null) {
                    GameMenu.bakeryAnimation.stop();
                    MainMenu.gameMenu.bakeryF.setViewport(new Rectangle2D(0,0,MyImage.bakery_width,MyImage.bakery_height));
                }
            } else if (factory instanceof TextileF) {
                if (!factory.isWorking && GameMenu.textileAnimation != null) {
                    GameMenu.textileAnimation.stop();
                    MainMenu.gameMenu.textileF.setViewport(new Rectangle2D(0,0,MyImage.textileF_width,MyImage.textileF_height));
                }
            } else if (factory instanceof TailoringF) {
                if (!factory.isWorking && GameMenu.tailoringAnimation != null) {
                    GameMenu.tailoringAnimation.stop();
                    MainMenu.gameMenu.tailoringF.setViewport(new Rectangle2D(0,0,MyImage.tailoringF_width,MyImage.tailoringF_height));
                }
            } else if (factory instanceof MilkF) {
                if (!factory.isWorking && GameMenu.milkAnimation != null) {
                    GameMenu.milkAnimation.stop();
                    MainMenu.gameMenu.milkF.setViewport(new Rectangle2D(0,0,MyImage.milkF_width,MyImage.milkF_height));
                }
            } else if (factory instanceof MillF) {
                if (!factory.isWorking && GameMenu.millAnimation != null) {
                    GameMenu.millAnimation.stop();
                    MainMenu.gameMenu.millF.setViewport(new Rectangle2D(0,0,MyImage.millF_width,MyImage.millF_height));
                }
            } else if (factory instanceof IceCreamF) {
                if (!factory.isWorking && GameMenu.iceCreamAnimation != null) {
                    GameMenu.iceCreamAnimation.stop();
                    MainMenu.gameMenu.iceCreamF.setViewport(new Rectangle2D(0,0,MyImage.iceCreamF_width,MyImage.iceCreamF_height));
                }
            } else if (factory instanceof ChickenF) {
                if (!factory.isWorking && GameMenu.chickenFAnimation != null) {
                    GameMenu.chickenFAnimation.stop();
                    MainMenu.gameMenu.chickenF.setViewport(new Rectangle2D(0,0,MyImage.chickenF_width,MyImage.chickenF_height));
                }
            }
        }
    }

    // singleton design
    private static Update updateInstance=null;

    private Update() {
    }
    public static Update getInstance()
    {
        if (updateInstance==null)
        {
            updateInstance=new Update();
            updateInstance.wellTime=0;
            updateInstance.TruckTime=0;
        }
        return updateInstance;
    }

}
