package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;
import sample.Controller.Controller;
import sample.Controller.Update;
import sample.Model.Map;
import sample.Model.animal.*;
import sample.View.Menu1.GameMenu;
import sample.View.Menu1.Login;
import sample.View.Menu1.MainMenu;
import sample.View.Menu1.MyImage;

import java.io.IOException;
import java.util.Objects;

public class Main extends Application {
    public static Stage window;
    public static Stage alertStage = new Stage();
    public static Scene scene;
    public static MediaPlayer mp ;

    @Override
    public void start(Stage primaryStage) throws Exception{
        alertStage.initModality(Modality.APPLICATION_MODAL);
        Media media = new Media(Objects.requireNonNull(getClass().getResource("/music/hero.mp3")).toURI().toString());
        mp = new MediaPlayer(media);
        mp.setOnEndOfMedia(() -> mp.seek(Duration.ZERO));
        Controller controller = Controller.getInstance();
        //System.out.println(Map.factories.size());
        //Map.dogs.add(new Dog());
        //Map.domestics.add(new Chicken());
       // Map.wilds.add(new Lion());
        //Map.wilds.add(new Bear());
        window = primaryStage;
        window.setResizable(false);
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("View/Menu1/firstMenu.fxml"));
        Parent root = loader.load();
        /*Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("View\\Menu1\\login.fxml")));*/
        scene = new Scene(root);
        window.setScene(scene);
        window.show();
    }

    public static void newStage(String fxml, int w, int h) throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(Main.class.getResource(fxml)));
        alertStage.setScene(new Scene(root, w, h));
        alertStage.show();
    }


    public static void Rooting () throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("View/Menu1/gameMenu.fxml"));
        Parent root = loader.load();
        MainMenu.gameMenu = loader.getController();
        scene.setRoot(root);
    }


    public static void changeScene (String fxml) throws IOException {
        Parent parent =FXMLLoader.load(Objects.requireNonNull(Main.class.getResource(fxml)));
        scene.setRoot(parent);
    }

    public static void main(String[] args) {
        launch(args);
    }

    public static GameMenu getController() throws IOException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("View/Menu1/gameMenu.fxml"));
        System.out.println(loader.getLocation());
        try {
            Parent root = loader.load();
        } catch (IOException e){
            e.printStackTrace();
            System.exit(0);
        }
        GameMenu menu = loader.getController();
        if (menu == null){
            System.out.println("null");

        } else {
            System.out.println("not null ");
            System.exit(0);
        }
        return null;
    }
}
