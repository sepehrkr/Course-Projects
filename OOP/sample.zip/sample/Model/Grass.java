package sample.Model;

public class Grass {
    public int row;
    public int col;

    public Grass(int row, int col) {
        this.row = row;
        this.col = col;
    }
    public static void addGrass (int row , int col)
    {
        Map.grasses.add(new Grass(row,col));
    }

}
