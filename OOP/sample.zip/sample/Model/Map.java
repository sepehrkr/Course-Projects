package sample.Model;

import sample.Model.animal.*;
import sample.Model.factory.*;
import sample.Model.product.IceCream;
import sample.Model.product.Product;

import java.util.ArrayList;
import java.util.List;

public class Map {
    public static ArrayList<Domestic> domestics;
    public static ArrayList<Wild> wilds;
    public static ArrayList<Dog> dogs ;
    public static ArrayList<Cat> cats;
    public static ArrayList<Grass> grasses;
    public static ArrayList<Factory> factories;
    public static ArrayList<Product> products;


    public static void showGrass() {
        int[][] grassMap = new int[6][6];
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                for (Grass grass : Map.grasses) {
                    if (grass.row == i+1 && grass.col == j+1) {
                        grassMap[i][j] = Map.interGrasses(grass).size();
                        break;
                    }
                }
            }
        }
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                System.out.print(grassMap[i][j] + " ");
            }
            System.out.print("\n");
        }
    }

    static ArrayList<Grass> interGrasses(Grass grass) {
        ArrayList<Grass> grasses = new ArrayList<>();
        for (Grass grass1 : Map.grasses) {
            if (grass1.row == grass.row && grass.col == grass1.col) {
                grasses.add(grass1);
            }
        }
        return grasses;
    }




    private Map() {
    }
    private static Map map = null;
    public static Map getInstance()
    {
        if (map==null)
        {
            map=new Map();
            domestics=new ArrayList<>();
            wilds=new ArrayList<>();
            dogs=new ArrayList<>();
            cats=new ArrayList<>();
            grasses=new ArrayList<>();
            factories=new ArrayList<>();
            products=new ArrayList<>();
        }
        return map;
    }
    public static Factory getThereBakeryF()
    {
        for (Factory factory : Map.factories)
        {
            if (factory instanceof BakeryF)
                return factory;
        }
        return null;
    }
    public static Factory getThereIceCreamF()
    {
        for (Factory factory : Map.factories)
        {
            if (factory instanceof IceCreamF)
                return factory;
        }
        return null;
    }
    public static Factory getThereMilkF()
    {
        for (Factory factory : Map.factories)
        {
            if (factory instanceof MilkF)
                return factory;
        }
        return null;
    }
    public static Factory getThereMillF()
    {
        for (Factory factory : Map.factories)
        {
            if (factory instanceof MillF)
                return factory;
        }
        return null;
    }
    public static Factory getThereTailoringF()
    {
        for (Factory factory : Map.factories)
        {
            if (factory instanceof TailoringF)
                return factory;
        }
        return null;
    }
    public static Factory getThereTextileF()
    {
        for (Factory factory : Map.factories)
        {
            if (factory instanceof TextileF)
                return factory;
        }
        return null;
    }
    public static Factory getThereChickenF()
    {
        for (Factory factory : Map.factories)
        {
            if (factory instanceof ChickenF)
                return factory;
        }
        return null;
    }

}
