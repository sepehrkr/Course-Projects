package sample.Model;

public enum Price {
    EGG(15), MILK(25), FEATHER(20),
    FLOUR(40), CLOTH(50), PACK_MILK(60),
    BREAD(80), SHIRT(100), ICE_CREAM(120),
    LION(300), BEAR(400), TIGER(500),
    CHICKEN(100), TURKEY(200), BUFFALO(400),
    DOG(100), CAT(150),
    MILL_F(150) , TEXTILE_F(250), MILK_F(400), BAKERY_F(250), TAILORING_F(400), ICE_CREAM_F(550), CHICKEN_F(200),
    MILL_F_UPGRADE(250) , TEXTILE_F_UPGRADE(400), MILK_F_UPGRADE(650), BAKERY_F_UPGRADE(400), TAILORING_F_UPGRADE(650), ICE_CREAM_F_UPGRADE(900) , CHICKEN_F_UPGRADE(300);
    private final int price;

    Price(int price) {
        this.price=price;
    }

    public int getPrice() {
        return this.price;
    }
}
