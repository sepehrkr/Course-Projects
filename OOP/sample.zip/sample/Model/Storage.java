package sample.Model;

public enum Storage {
    EGG(1), MILK(1), FEATHER(1),
    FLOUR(2), CLOTH(2), PACK_MILK(2),
    BREAD(4), SHIRT(4), ICE_CREAM(4),
    LION(15), BEAR(15), TIGER(15);
    private final int storage;
    Storage(int storage) {
        this.storage=storage;
    }
    public int getStorage()
    {
        return this.storage;
    }
}
