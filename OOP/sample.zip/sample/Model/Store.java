package sample.Model;

import sample.Controller.*;
import sample.Model.animal.Bear;
import sample.Model.animal.Lion;
import sample.Model.animal.Tiger;
import sample.Model.animal.Wild;
import sample.Model.product.*;

import java.util.ArrayList;

public class Store {
    public final int STORAGE=30;
    public int currentStorage;
    public ArrayList<Egg> storeEggs;
    public ArrayList<Feather> storeFeathers;
    public ArrayList<Milk> storeMilks;
    public ArrayList<Flour> storeFlours ;
    public ArrayList<Cloth> storeClothes;
    public ArrayList<PackMilk> storePackMilks;
    public ArrayList<Bread> storeBreads;
    public ArrayList<Shirt> storeShirts;
    public ArrayList<IceCream> storeIceCreams;
    public ArrayList<Wild> storeWilds;

   public int insertProduct (String name)        // return       -2 for invalid name   ,  -1 for not enough storage ,  1 for success
    {
        Task task = Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].task;
        switch (name)
        {
            case "Egg" :
                if (this.currentStorage +Storage.EGG.getStorage()<=STORAGE) {
                    this.storeEggs.add(new Egg());
                    this.currentStorage +=Storage.EGG.getStorage();
                    task.setCurrentEggs(task.getCurrentEggs()+1);
                } else return -1;
                break;
            case "Feather" :
                if (this.currentStorage +Storage.FEATHER.getStorage()<=STORAGE) {
                    this.storeFeathers.add(new Feather());
                    this.currentStorage +=Storage.FEATHER.getStorage();
                    task.setCurrentFeathers(task.getCurrentFeathers()+1);
                } else return -1;
                break;
            case "Milk" :
                if (this.currentStorage +Storage.MILK.getStorage()<=STORAGE) {
                    this.storeMilks.add(new Milk());
                    this.currentStorage +=Storage.MILK.getStorage();
                    task.setCurrentMilks(task.getCurrentMilks()+1);
                } else return -1;
                break;
            case "Flour" :
                if (this.currentStorage +Storage.FLOUR.getStorage()<=STORAGE) {
                    this.storeFlours.add(new Flour());
                    this.currentStorage += Storage.FLOUR.getStorage();
                    task.setCurrentFlours(task.getCurrentFlours()+1);
                } else return -1;
                break;
            case "Cloth" :
                if (this.currentStorage +Storage.CLOTH.getStorage()<=STORAGE) {
                    this.storeClothes.add(new Cloth());
                    this.currentStorage += Storage.CLOTH.getStorage();
                    task.setCurrentCloths(task.getCurrentCloths()+1);
                } else return -1;
                break;
            case "PackMilk" :
                if (this.currentStorage +Storage.PACK_MILK.getStorage()<=STORAGE) {
                    this.storePackMilks.add(new PackMilk());
                    this.currentStorage += Storage.PACK_MILK.getStorage();
                    task.setCurrentPackMilks(task.getCurrentPackMilks()+1);
                } else return -1;
                break;
            case "Bread" :
                if (this.currentStorage +Storage.BREAD.getStorage()<=STORAGE) {
                    this.storeBreads.add(new Bread());
                    this.currentStorage += Storage.BREAD.getStorage();
                    task.setCurrentBreads(task.getCurrentBreads()+1);
                }else return -1;
                break;
            case "Shirt" :
                if (this.currentStorage +Storage.SHIRT.getStorage()<=STORAGE) {
                    this.storeShirts.add(new Shirt());
                    this.currentStorage += Storage.SHIRT.getStorage();
                    task.setCurrentShirts(task.getCurrentShirts()+1);
                } else return -1;
                break;
            case "IceCream" :
                if (this.currentStorage +Storage.ICE_CREAM.getStorage()<=STORAGE) {
                    this.storeIceCreams.add(new IceCream());
                    this.currentStorage += Storage.ICE_CREAM.getStorage();
                    task.setCurrentIceCreams(task.getCurrentIceCreams()+1);
                } else return -1;
                break;
            case "Bear" :
                if (this.currentStorage +Storage.BEAR.getStorage()<=STORAGE) {
                    this.storeWilds.add(new Bear());
                    this.currentStorage += Storage.BEAR.getStorage();
                } else return -1;
                break;
            case "Lion" :
                if (this.currentStorage +Storage.LION.getStorage()<=STORAGE) {
                    this.storeWilds.add(new Lion());
                    this.currentStorage += Storage.LION.getStorage();
                } else return -1;
                break;
            case "Tiger" :
                if (this.currentStorage +Storage.TIGER.getStorage()<=STORAGE) {
                    this.storeWilds.add(new Tiger());
                    this.currentStorage += Storage.TIGER.getStorage();
                } else return -1;
                break;
            default:
                return -2;
        }
        return 1;
    }

    Wild checkLion ()
    {
        for (Wild wild : this.storeWilds)
            if (wild instanceof Lion) {
                return wild;
            }
        return null;
    }
    Wild checkBear ()
    {
        for (Wild wild : this.storeWilds)
            if (wild instanceof Bear) {
                return wild;
            }
        return null;
    }
    Wild checkTiger ()
    {
        for (Wild wild : this.storeWilds)
            if (wild instanceof Tiger) {
                return wild;
            }
        return null;
    }

    public int pickupProduct(int row , int col)
    {
        int a=0;
        for (Product product : Map.products)
        {
            if (product.row==row && product.col==col)
            {

                if (product instanceof Egg)
                    a = this.insertProduct("Egg");
                else if (product instanceof Feather)
                    a= this.insertProduct("Feather");
                else if (product instanceof Milk)
                    a=this.insertProduct("Milk");
                else if (product instanceof Flour)
                    a= this.insertProduct("Flour");
                else if (product instanceof Cloth)
                    a= this.insertProduct("Cloth");
                else if (product instanceof PackMilk)
                    a= this.insertProduct("PackMilk");
                else if (product instanceof Bread)
                    a= this.insertProduct("Bread");
                else if (product instanceof Shirt)
                    a= this.insertProduct("Shirt");
                else if (product instanceof IceCream)
                    a= this.insertProduct("IceCream");
                if (a==1) {
                    Map.products.remove(product);
                    return a;
                }
            }
        }
        return -4;
    }
    public int pickupWild(int row, int col) {
        int a = 0;
        for (Wild wild : Map.wilds) {
            if (wild.row == row && wild.col == col) {
                if (wild.isCaged) {
                    if (wild instanceof Lion)
                        a = insertProduct("Lion");
                    else if (wild instanceof Bear)
                        a = insertProduct("Bear");
                    else if (wild instanceof Tiger)
                        a = insertProduct("Tiger");
                    if (a == 1) {
                        Map.wilds.remove(wild);
                    }
                    return a;
                } else if (wild.cages == wild.maxCage) {
                    return -6;
                } else {
                    return -5;
                }
            }
        }
        return -4;
    }

        // singleton design
    private static Store storeInstance =null;
    private Store() {
    }
    public static Store getInstance()
    {
        if (storeInstance==null)
        {
            storeInstance=new Store();
            storeInstance.currentStorage =0;
            storeInstance.storeEggs=new ArrayList<>();
            storeInstance.storeFeathers=new ArrayList<>();
            storeInstance.storeMilks=new ArrayList<>();
            storeInstance.storeFlours=new ArrayList<>();
            storeInstance.storeClothes=new ArrayList<>();
            storeInstance.storePackMilks=new ArrayList<>();
            storeInstance.storeWilds=new ArrayList<>();
            storeInstance.storeBreads=new ArrayList<>();
            storeInstance.storeShirts=new ArrayList<>();
            storeInstance.storeIceCreams=new ArrayList<>();
        }
        return storeInstance;
    }

}
