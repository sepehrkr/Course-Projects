package sample.Model;

import sample.Model.animal.Bear;
import sample.Model.animal.Lion;
import sample.Model.animal.Tiger;
import sample.Model.animal.Wild;
import sample.Model.product.*;

import java.util.ArrayList;

public class Vehicle {
    final int STORAGE=15;
    int currentStorage;
    public ArrayList<Egg> eggs;
    public ArrayList<Feather> feathers;
    public ArrayList<Milk> milks;
    public ArrayList<Flour> flours ;
    public ArrayList<Cloth> clothes;
    public ArrayList<PackMilk> packMilks;
    public ArrayList<Bread> breads;
    public ArrayList<Shirt> shirts;
    public ArrayList<IceCream> iceCreams;
    public ArrayList<Wild> wilds;
    boolean state;       // true is here and false in not here

    public int truckLoad (String itemName)      // Return -1 for not enough truck capacity , -2 for not exist in store , -3 for Invalid Input , 1 for success
    {
        Store store=Store.getInstance();
        switch (itemName)
        {
            case "egg" :
                if (store.storeEggs.size()>0){
                    if (this.currentStorage+Storage.EGG.getStorage()<=STORAGE){
                        this.eggs.add(store.storeEggs.get(store.storeEggs.size()-1));
                        store.storeEggs.remove(store.storeEggs.size()-1);
                        this.currentStorage+=Storage.EGG.getStorage();
                        store.currentStorage -=Storage.EGG.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "feather" :
                if (store.storeFeathers.size()>0){
                    if (this.currentStorage+Storage.FEATHER.getStorage()<=STORAGE){
                        this.feathers.add(store.storeFeathers.get(store.storeFeathers.size()-1));
                        store.storeFeathers.remove(store.storeFeathers.size()-1);
                        this.currentStorage+=Storage.FEATHER.getStorage();
                        store.currentStorage -=Storage.FEATHER.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "milk" :
                if (store.storeMilks.size()>0){
                    if (this.currentStorage+Storage.MILK.getStorage()<=STORAGE){
                        this.milks.add(store.storeMilks.get(store.storeMilks.size()-1));
                        store.storeMilks.remove(store.storeMilks.size()-1);
                        this.currentStorage+=Storage.MILK.getStorage();
                        store.currentStorage -=Storage.MILK.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "flour" :
                if (store.storeFlours.size()>0){
                    if (this.currentStorage+Storage.FLOUR.getStorage()<=STORAGE){
                        this.flours.add(store.storeFlours.get(store.storeFlours.size()-1));
                        store.storeFlours.remove(store.storeFlours.size()-1);
                        this.currentStorage+=Storage.FLOUR.getStorage();
                        store.currentStorage -=Storage.FLOUR.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "cloth" :
                if (store.storeClothes.size()>0){
                    if (this.currentStorage+Storage.CLOTH.getStorage()<=STORAGE){
                        this.clothes.add(store.storeClothes.get(store.storeClothes.size()-1));
                        store.storeClothes.remove(store.storeClothes.size()-1);
                        this.currentStorage+=Storage.CLOTH.getStorage();
                        store.currentStorage -=Storage.CLOTH.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "pack milk" :
                if (store.storePackMilks.size()>0){
                    if (this.currentStorage+Storage.PACK_MILK.getStorage()<=STORAGE){
                        this.packMilks.add(store.storePackMilks.get(store.storePackMilks.size()-1));
                        store.storePackMilks.remove(store.storePackMilks.size()-1);
                        this.currentStorage+=Storage.PACK_MILK.getStorage();
                        store.currentStorage -=Storage.PACK_MILK.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "bread" :
                if (store.storeBreads.size()>0){
                    if (this.currentStorage+Storage.BREAD.getStorage()<=STORAGE){
                        this.breads.add(store.storeBreads.get(store.storeBreads.size()-1));
                        store.storeBreads.remove(store.storeBreads.size()-1);
                        this.currentStorage+=Storage.BREAD.getStorage();
                        store.currentStorage -=Storage.BREAD.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "shirt" :
                if (store.storeShirts.size()>0){
                    if (this.currentStorage+Storage.SHIRT.getStorage()<=STORAGE){
                        this.shirts.add(store.storeShirts.get(store.storeShirts.size()-1));
                        store.storeShirts.remove(store.storeShirts.size()-1);
                        this.currentStorage+=Storage.SHIRT.getStorage();
                        store.currentStorage -=Storage.SHIRT.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "ice cream" :
                if (store.storeIceCreams.size()>0){
                    if (this.currentStorage+Storage.ICE_CREAM.getStorage()<=STORAGE){
                        this.iceCreams.add(store.storeIceCreams.get(store.storeIceCreams.size()-1));
                        store.storeIceCreams.remove(store.storeIceCreams.size()-1);
                        this.currentStorage+=Storage.ICE_CREAM.getStorage();
                        store.currentStorage -=Storage.ICE_CREAM.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "bear" :
                if (store.checkBear()!=null){
                    if (this.currentStorage+Storage.BEAR.getStorage()<=STORAGE){
                        Wild wild =store.checkBear();
                        store.storeWilds.remove(wild);
                        this.wilds.add(wild);
                        this.currentStorage+=Storage.BEAR.getStorage();
                        store.currentStorage -=Storage.BEAR.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "lion" :
                if (store.checkLion()!=null){
                    if (this.currentStorage+Storage.LION.getStorage()<=STORAGE){
                        Wild wild =store.checkLion();
                        store.storeWilds.remove(wild);
                        this.wilds.add(wild);
                        this.currentStorage+=Storage.LION.getStorage();
                        store.currentStorage -=Storage.LION.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "tiger" :
                if (store.checkTiger()!=null){
                    if (this.currentStorage+Storage.TIGER.getStorage()<=STORAGE){
                        Wild wild =store.checkTiger();
                        store.storeWilds.remove(wild);
                        this.wilds.add(wild);
                        this.currentStorage+=Storage.TIGER.getStorage();
                        store.currentStorage -=Storage.TIGER.getStorage();
                    } else return -1;
                } else return -2;
                break;
            default:
                return -3;
        }
        return 1;
    }
    public int truckUnLoad (String itemName)    // Return -1 for not enough store capacity , -2 for not exist in truck , -3 for invalid input  , 1 for success
    {
        Store store=Store.getInstance();
        switch (itemName)
        {
            case "egg" :
                if (this.eggs.size()>0){
                    if (store.currentStorage +Storage.EGG.getStorage()<=store.STORAGE){
                        store.storeEggs.add(this.eggs.get(this.eggs.size()-1));
                        this.eggs.remove(this.eggs.get(this.eggs.size()-1));
                        this.currentStorage-=Storage.EGG.getStorage();
                        store.currentStorage +=Storage.EGG.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "feather" :
                if (this.feathers.size()>0){
                    if (store.currentStorage +Storage.FEATHER.getStorage()<=store.STORAGE){
                        store.storeFeathers.add(this.feathers.get(this.feathers.size()-1));
                        this.feathers.remove(this.feathers.get(this.feathers.size()-1));
                        this.currentStorage-=Storage.FEATHER.getStorage();
                        store.currentStorage +=Storage.FEATHER.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "milk" :
                if (this.milks.size()>0){
                    if (store.currentStorage +Storage.MILK.getStorage()<=store.STORAGE){
                        store.storeMilks.add(this.milks.get(this.milks.size()-1));
                        this.milks.remove(this.milks.get(this.milks.size()-1));
                        this.currentStorage-=Storage.MILK.getStorage();
                        store.currentStorage +=Storage.MILK.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "flour" :
                if (this.flours.size()>0){
                    if (store.currentStorage +Storage.FLOUR.getStorage()<=store.STORAGE){
                        store.storeFlours.add(this.flours.get(this.flours.size()-1));
                        this.flours.remove(this.flours.get(this.flours.size()-1));
                        this.currentStorage-=Storage.FLOUR.getStorage();
                        store.currentStorage +=Storage.FLOUR.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "cloth" :
                if (this.clothes.size()>0){
                    if (store.currentStorage +Storage.CLOTH.getStorage()<=store.STORAGE){
                        store.storeClothes.add(this.clothes.get(this.clothes.size()-1));
                        this.clothes.remove(this.clothes.get(this.clothes.size()-1));
                        this.currentStorage-=Storage.CLOTH.getStorage();
                        store.currentStorage +=Storage.CLOTH.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "pack milk" :
                if (this.packMilks.size()>0){
                    if (store.currentStorage +Storage.PACK_MILK.getStorage()<=store.STORAGE){
                        store.storePackMilks.add(this.packMilks.get(this.packMilks.size()-1));
                        this.packMilks.remove(this.packMilks.get(this.packMilks.size()-1));
                        this.currentStorage-=Storage.PACK_MILK.getStorage();
                        store.currentStorage +=Storage.PACK_MILK.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "bread" :
                if (this.breads.size()>0){
                    if (store.currentStorage +Storage.BREAD.getStorage()<=store.STORAGE){
                        store.storeBreads.add(this.breads.get(this.breads.size()-1));
                        this.breads.remove(this.breads.get(this.breads.size()-1));
                        this.currentStorage-=Storage.BREAD.getStorage();
                        store.currentStorage +=Storage.BREAD.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "shirt" :
                if (this.shirts.size()>0){
                    if (store.currentStorage +Storage.SHIRT.getStorage()<=store.STORAGE){
                        store.storeShirts.add(this.shirts.get(this.shirts.size()-1));
                        this.shirts.remove(this.shirts.get(this.shirts.size()-1));
                        this.currentStorage-=Storage.SHIRT.getStorage();
                        store.currentStorage +=Storage.SHIRT.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "ice cream" :
                if (this.iceCreams.size()>0){
                    if (store.currentStorage +Storage.ICE_CREAM.getStorage()<=store.STORAGE){
                        store.storeIceCreams.add(this.iceCreams.get(this.iceCreams.size()-1));
                        this.iceCreams.remove(this.iceCreams.get(this.iceCreams.size()-1));
                        this.currentStorage-=Storage.ICE_CREAM.getStorage();
                        store.currentStorage +=Storage.ICE_CREAM.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "bear" :
                if (this.checkBear()!=null){
                    if (store.currentStorage+Storage.BEAR.getStorage()<=store.STORAGE){
                        Wild wild =this.checkBear();
                        store.storeWilds.add(wild);
                        this.wilds.remove(wild);
                        this.currentStorage-=Storage.BEAR.getStorage();
                        store.currentStorage +=Storage.BEAR.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "lion" :
                if (this.checkLion()!=null){
                    if (store.currentStorage+Storage.LION.getStorage()<=store.STORAGE){
                        Wild wild =this.checkLion();
                        store.storeWilds.add(wild);
                        this.wilds.remove(wild);
                        this.currentStorage-=Storage.LION.getStorage();
                        store.currentStorage +=Storage.LION.getStorage();
                    } else return -1;
                } else return -2;
                break;
            case "tiger" :
                if (this.checkTiger()!=null){
                    if (store.currentStorage+Storage.TIGER.getStorage()<=store.STORAGE){
                        Wild wild =this.checkTiger();
                        store.storeWilds.remove(wild);
                        this.wilds.add(wild);
                        this.currentStorage-=Storage.TIGER.getStorage();
                        store.currentStorage +=Storage.TIGER.getStorage();
                    } else return -1;
                } else return -2;
                break;
            default:
                return -3;
        }
        return 1;
    }



    Wild checkLion ()
    {
        for (Wild wild : this.wilds)
            if (wild instanceof Lion) {
                return wild;
            }
        return null;
    }
    Wild checkBear ()
    {
        for (Wild wild : this.wilds)
            if (wild instanceof Bear) {
                return wild;
            }
        return null;
    }
    Wild checkTiger ()
    {
        for (Wild wild : this.wilds)
            if (wild instanceof Tiger) {
                return wild;
            }
        return null;
    }

    public void setState(boolean state) {
        this.state = state;
    }

    public boolean isState() {
        return state;
    }
    /// singleton design

    private static Vehicle vehicleInstance = null;
    private Vehicle() {
    }
    public static Vehicle getInstance()
    {
        if (vehicleInstance==null)
        {
            vehicleInstance=new Vehicle();
            vehicleInstance.state=true;
            vehicleInstance.currentStorage=0;
            vehicleInstance.wilds=new ArrayList<>();
            vehicleInstance.eggs=new ArrayList<>();
            vehicleInstance.feathers=new ArrayList<>();
            vehicleInstance.milks=new ArrayList<>();
            vehicleInstance.flours=new ArrayList<>();
            vehicleInstance.clothes=new ArrayList<>();
            vehicleInstance.packMilks=new ArrayList<>();
            vehicleInstance.breads=new ArrayList<>();
            vehicleInstance.shirts=new ArrayList<>();
            vehicleInstance.iceCreams=new ArrayList<>();


        }
        return vehicleInstance;
    }

    public void setCurrentStorage(int currentStorage) {
        this.currentStorage = currentStorage;
    }
}
