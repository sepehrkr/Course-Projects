package sample.Model.animal;

import java.util.Random;


public abstract class Animal {
    public String side;
    public String type;
    public int row;
    public int col;
    int step;

    Animal() {
        Random random = new Random();
        row = random.nextInt(6) + 1;
        col = random.nextInt(6) + 1;
    }


    public void move() {
        Random random = new Random();
        int rowP = row;
        int colP = col;

        if (row < 7 - step && col < 7 - step && row > step && col > step) {
            int m = random.nextInt(4);
            if (m < 2) {
                row += m == 0 ? -step : +step;
            } else {
                col += m == 2 ? -step : +step;
            }
        } else if (row <= step && col > step && col < 7 - step) {
            int m = random.nextInt(3);
            if (m < 2) {
                col += m == 0 ? -step : +step;
            } else {
                row += step;
            }
        } else if (row >= 7 - step && col > step && col < 7 - step) {
            int m = random.nextInt(3);
            if (m < 2) {
                col += m == 0 ? -step : +step;
            } else {
                row -= step;
            }
        } else if (col <= step && row > step && row < 7 - step) {
            int m = random.nextInt(3);
            if (m < 2) {
                row += m == 0 ? -step : +step;
            } else {
                col += step;
            }
        } else if (col >= 7 - step && row > step && row < 7 - step) {
            int m = random.nextInt(3);
            if (m < 2) {
                row += m == 0 ? -step : +step;
            } else {
                col -= step;
            }
        } else if (row <= step && col <= step) {
            int m = random.nextInt(2);
            if (m == 0) {
                row += step;
            } else {
                col += step;
            }
        } else if (row <= step) {
            int m = random.nextInt(2);
            if (m == 0) {
                row += step;
            } else {
                col -= step;
            }
        } else if (col <= step) {
            int m = random.nextInt(2);
            if (m == 0) {
                row -= step;
            } else {
                col += step;
            }
        } else {
            int m = random.nextInt(2);
            if (m == 0) {
                row -= step;
            } else {
                col -= step;
            }
        }

        if (row > rowP) {
            side = "down";
        } else if (row < rowP) {
            side = "up";
        } else if (col > colP) {
            side = "right";
        } else if (col < colP) {
            side = "left";
        }
    }

    public abstract void setType();
}
