package sample.Model.animal;

public class Bear extends Wild {
    public Bear() {
        maxCage = 4;
        step = 1;
        this.setType();
    }

    @Override
    public void setType() {
        this.type="bear";
    }


}
