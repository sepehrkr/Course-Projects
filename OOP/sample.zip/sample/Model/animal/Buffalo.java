package sample.Model.animal;

public class Buffalo extends Domestic {

    public Buffalo() {
        cost = 400;
        produceTime = 5;
        this.setType();
    }

    @Override
    public void setType() {
        this.type="buffalo";
    }
}
