package sample.Model.animal;

import sample.Model.Map;
import sample.Model.Store;
import sample.Model.product.*;

import java.util.Random;

public class Cat extends Other {

    boolean picked = false;

    public Cat() {
        step = 1;
        cost = 150;
        this.setType();
    }

    public static void productChecker() {
        if (!Map.products.isEmpty()) {
            for (Cat cat : Map.cats) {
                cat.seekForProduct();
            }
        }
    }

    void seekForProduct() {
        double m = pDistance(Map.products.get(0));
        Product product1 = Map.products.get(0);
        for (Product product : Map.products) {
            if (pDistance(product) <= m) {
                m = pDistance(product);
                product1 = product;
            }
        }
        moveToProduct(product1);
    }

    void moveToProduct(Product product) {
        Random random = new Random();
        int rowP = row;
        int colP = col;

        int m = random.nextInt(2);
        if (product.row > row && product.col > col) {
            if (m == 0) row++;
            else col++;
        } else if (product.row > row && product.col < col) {
            if (m == 0) row++;
            else col--;
        } else if (product.row < row && product.col < col) {
            if (m == 0) row--;
            else col--;
        } else if (product.row < row && product.col > col) {
            if (m == 0) row--;
            else col++;
        } else if (product.row == row && product.col > col) {
            col++;
        } else if (product.row == row && product.col < col) {
            col--;
        } else if (product.row > row) {
            row++;
        } else if (product.row < row) {
            row--;
        }

        if (row > rowP) {
            side = "down";
        } else if (row < rowP) {
            side = "up";
        } else if (col > colP) {
            side = "right";
        } else if (col < colP) {
            side = "left";
        }
    }

    double pDistance(Product product) {
        return Math.sqrt((product.row - row) * (product.row - row) + (product.col - col) * (product.col - col));
    }


    @Override
    public void move() {
        if (Map.products.isEmpty()) {
            Random random = new Random();
            int rowP = row;
            int colP = col;

            if (row < 7 - step && col < 7 - step && row > step && col > step) {
                int m = random.nextInt(4);
                if (m < 2) {
                    row += m == 0 ? -step : +step;
                } else {
                    col += m == 2 ? -step : +step;
                }
            } else if (row <= step && col > step && col < 7 - step) {
                int m = random.nextInt(3);
                if (m < 2) {
                    col += m == 0 ? -step : +step;
                } else {
                    row += step;
                }
            } else if (row >= 7 - step && col > step && col < 7 - step) {
                int m = random.nextInt(3);
                if (m < 2) {
                    col += m == 0 ? -step : +step;
                } else {
                    row -= step;
                }
            } else if (col <= step && row > step && row < 7 - step) {
                int m = random.nextInt(3);
                if (m < 2) {
                    row += m == 0 ? -step : +step;
                } else {
                    col += step;
                }
            } else if (col >= 7 - step && row > step && row < 7 - step) {
                int m = random.nextInt(3);
                if (m < 2) {
                    row += m == 0 ? -step : +step;
                } else {
                    col -= step;
                }
            } else if (row <= step && col <= step) {
                int m = random.nextInt(2);
                if (m == 0) {
                    row += step;
                } else {
                    col += step;
                }
            } else if (row <= step) {
                int m = random.nextInt(2);
                if (m == 0) {
                    row += step;
                } else {
                    col -= step;
                }
            } else if (col <= step) {
                int m = random.nextInt(2);
                if (m == 0) {
                    row -= step;
                } else {
                    col += step;
                }
            } else {
                int m = random.nextInt(2);
                if (m == 0) {
                    row -= step;
                } else {
                    col -= step;
                }
            }

            if (row > rowP) {
                side = "down";
            } else if (row < rowP) {
                side = "up";
            } else if (col > colP) {
                side = "right";
            } else if (col < colP) {
                side = "left";
            }
        }
    }


    @Override
    public void setType() {
        this.type = "cat";
    }

    public static void pick() {
        for (Cat cat : Map.cats) {
            if (!Map.products.isEmpty()) {
                for (Product product : Map.products) {
                    if (product.row == cat.row && product.col == cat.col) {
                        cat.pickP(product);
                        if (cat.picked) {
                            Map.products.remove(product);
                            cat.picked = false;
                            break;
                        }
                    }
                }
                if (Map.products.isEmpty()) {
                    break;
                }
            }
        }
    }

    void pickP(Product product) {
        int a = 0;
        Store store = Store.getInstance();
        if (product instanceof Egg) {
            if ((a = store.insertProduct("Egg")) == 1) {
                picked = true;
            }
        } else if (product instanceof Milk) {
            if ((a = store.insertProduct("Milk")) == 1) {
                picked = true;
            }
        } else if (product instanceof Feather) {
            if ((a = store.insertProduct("Feather")) == 1) {
                picked = true;
            }
        } else if (product instanceof Flour) {
            if ((a = store.insertProduct("Flour")) == 1) {
                picked = true;
            }
        } else if (product instanceof Cloth) {
            if ((a = store.insertProduct("Cloth")) == 1) {
                picked = true;
            }
        } else if (product instanceof PackMilk) {
            if ((a = store.insertProduct("PackMilk")) == 1) {
                picked = true;
            }
        } else if (product instanceof Bread) {
            if ((a = store.insertProduct("Bread")) == 1) {
                picked = true;
            }
        } else if (product instanceof Shirt) {
            if ((a = store.insertProduct("Shirt")) == 1) {
                picked = true;
            }
        } else if (product instanceof IceCream) {
            if ((a = store.insertProduct("IceCream")) == 1) {
                picked = true;
            }
        }
    }

}
