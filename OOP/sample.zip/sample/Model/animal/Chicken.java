package sample.Model.animal;

public class Chicken extends Domestic {

    public Chicken() {
        cost = 100;
        produceTime = 2;
        this.setType();
    }

    @Override
    public void setType() {
        this.type="chicken";
    }

}
