package sample.Model.animal;

import sample.Model.Map;

import java.util.ArrayList;

public class Dog extends Other {

    public Dog() {
        step = 1;
        cost = 100;
        this.setType();
    }

    @Override
    public void setType() {
        this.type = "dog";
    }

    public static void kill() {
        if (!Map.dogs.isEmpty() && !Map.wilds.isEmpty()) {
            ArrayList<Dog> killedDogs = new ArrayList<>();
            for (Dog dog : Map.dogs) {
                for (Wild wild : Map.wilds) {
                    if (dog.row == wild.row && dog.col == wild.col && !wild.isCaged) {
                        killedDogs.add(dog);
                        Map.wilds.remove(wild);
                        break;
                    }
                }
            }
            for (Dog dog : killedDogs) {
                Map.dogs.remove(dog);
            }
        }
    }
    public static void killT() {
        if (!Map.dogs.isEmpty() && !Map.wilds.isEmpty()) {
            ArrayList<Dog> killedDogs = new ArrayList<>();
            for (Dog dog : Map.dogs) {
                for (Wild wild : Map.wilds) {
                    if (wild instanceof Tiger && !wild.isCaged) {
                        if (((Tiger) wild).down == 1) {
                            if (dog.row == wild.row - 1 && dog.col == wild.col) {
                                killedDogs.add(dog);
                                Map.wilds.remove(wild);
                                break;
                            }
                        } else if (((Tiger) wild).down == -1) {
                            if (dog.row == wild.row + 1 && dog.col == wild.col) {
                                killedDogs.add(dog);
                                Map.wilds.remove(wild);
                                break;
                            }
                        } else if (((Tiger) wild).right == 1) {
                            if (dog.row == wild.row && dog.col == wild.col - 1) {
                                killedDogs.add(dog);
                                Map.wilds.remove(wild);
                                break;
                            }
                        } else if (((Tiger) wild).right == -1) {
                            if (dog.row == wild.row && dog.col == wild.col + 1) {
                                killedDogs.add(dog);
                                Map.wilds.remove(wild);
                                break;
                            }
                        }
                    }
                }
                for (Dog dog1 : killedDogs) {
                    Map.dogs.remove(dog1);
                }
            }
        }
    }
}
