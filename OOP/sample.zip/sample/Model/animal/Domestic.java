package sample.Model.animal;

import sample.Controller.*;
import sample.Model.Grass;
import sample.Model.Map;
import sample.Model.product.Egg;
import sample.Model.product.Feather;
import sample.Model.product.Milk;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import sample.Model.Map;

import java.util.ArrayList;
import java.util.Random;

@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = "type")
@JsonSubTypes({
        @JsonSubTypes.Type(value = Chicken.class, name = "chicken"),
        @JsonSubTypes.Type(value = Turkey.class, name = "turkey"),
        @JsonSubTypes.Type(value = Buffalo.class, name = "buffalo")
})

public abstract class Domestic extends Animal {

    public boolean isHungry;
    int cost;
    public int life;
    int produceTime;
    int counter;

    Domestic() {
        life = 100;
        step = 1;
        isHungry = false;
        counter = 0;
    }

    public static void lifeDecrease() {
        for (Domestic domestic : Map.domestics) {
            domestic.life -= 10;
        }
    }

    public static void lifeChecker() {
        ArrayList<Domestic> removeDomestics = new ArrayList<>();
        Task task = Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].task;
        for (Domestic domestic : Map.domestics) {
            if (domestic.life <= 0) {
                removeDomestics.add(domestic);
                Log.logCompile("domestic in " + domestic.row + " , " + domestic.col + " died", "info");
                if (domestic instanceof Chicken) {
                    task.setDomestic("Chicken", -1);
                } else if (domestic instanceof Turkey) {
                    task.setDomestic("Turkey", -1);
                } else if (domestic instanceof Buffalo) {
                    task.setDomestic("Buffalo", -1);
                }
            }
        }
        Map.domestics.removeAll(removeDomestics);
    }

    public static void foodChecker() {
        for (Domestic domestic : Map.domestics) {
            if (domestic.life <= 50) {
                domestic.isHungry = true;
                domestic.seekForFood();
            }
        }
    }

    void seekForFood() {
        if (!Map.grasses.isEmpty()) {
            double m = gDistance(Map.grasses.get(0));
            Grass grass1 = Map.grasses.get(0);
            for (Grass grass : Map.grasses) {
                if (gDistance(grass) <= m) {
                    m = gDistance(grass);
                    grass1 = grass;
                }
            }
            moveToFood(grass1);
        } else {
            isHungry = false;
            move();
            isHungry = true;
        }
    }

    void moveToFood(Grass grass) {
        Random random = new Random();
        int rowP = row;
        int colP = col;

        int m = random.nextInt(2);
        if (grass.row > row && grass.col > col) {
            if (m == 0) row++;
            else col++;
        } else if (grass.row > row && grass.col < col) {
            if (m == 0) row++;
            else col--;
        } else if (grass.row < row && grass.col < col) {
            if (m == 0) row--;
            else col--;
        } else if (grass.row < row && grass.col > col) {
            if (m == 0) row--;
            else col++;
        } else if (grass.row == row && grass.col > col) {
            col++;
        } else if (grass.row == row && grass.col < col) {
            col--;
        } else if (grass.row > row) {
            row++;
        } else if (grass.row < row) {
            row--;
        }

        if (row > rowP) {
            side = "down";
        } else if (row < rowP) {
            side = "up";
        } else if (col > colP) {
            side = "right";
        } else if (col < colP) {
            side = "left";
        }
    }

    double gDistance(Grass grass) {
        return Math.sqrt((grass.row - row) * (grass.row - row) + (grass.col - col) * (grass.col - col));
    }


    @Override
    public void move() {
        if (!isHungry) {
            Random random = new Random();
            int rowP = row;
            int colP = col;

            if (row < 7 - step && col < 7 - step && row > step && col > step) {
                int m = random.nextInt(4);
                if (m < 2) {
                    row += m == 0 ? -step : +step;
                } else {
                    col += m == 2 ? -step : +step;
                }
            } else if (row <= step && col > step && col < 7 - step) {
                int m = random.nextInt(3);
                if (m < 2) {
                    col += m == 0 ? -step : +step;
                } else {
                    row += step;
                }
            } else if (row >= 7 - step && col > step && col < 7 - step) {
                int m = random.nextInt(3);
                if (m < 2) {
                    col += m == 0 ? -step : +step;
                } else {
                    row -= step;
                }
            } else if (col <= step && row > step && row < 7 - step) {
                int m = random.nextInt(3);
                if (m < 2) {
                    row += m == 0 ? -step : +step;
                } else {
                    col += step;
                }
            } else if (col >= 7 - step && row > step && row < 7 - step) {
                int m = random.nextInt(3);
                if (m < 2) {
                    row += m == 0 ? -step : +step;
                } else {
                    col -= step;
                }
            } else if (row <= step && col <= step) {
                int m = random.nextInt(2);
                if (m == 0) {
                    row += step;
                } else {
                    col += step;
                }
            } else if (row <= step) {
                int m = random.nextInt(2);
                if (m == 0) {
                    row += step;
                } else {
                    col -= step;
                }
            } else if (col <= step) {
                int m = random.nextInt(2);
                if (m == 0) {
                    row -= step;
                } else {
                    col += step;
                }
            } else {
                int m = random.nextInt(2);
                if (m == 0) {
                    row -= step;
                } else {
                    col -= step;
                }
            }

            if (row > rowP) {
                side = "down";
            } else if (row < rowP) {
                side = "up";
            } else if (col > colP) {
                side = "right";
            } else if (col < colP) {
                side = "left";
            }
        }
    }

    public static void update() {
        for (Domestic domestic : Map.domestics) {
            if (!domestic.isHungry) {
                domestic.counter++;
            }
        }
    }

    public static void produce() {
        for (Domestic domestic : Map.domestics) {
            if (domestic.counter == domestic.produceTime && !domestic.isHungry) {
                domestic.produceP(domestic);
                domestic.counter = 0;
            }
        }
    }

    void produceP(Domestic domestic) {
        if (domestic instanceof Chicken) {
            Egg egg = new Egg(row, col);
            Map.products.add(egg);
        } else if (domestic instanceof Turkey) {
            Feather feather = new Feather(row, col);
            Map.products.add(feather);
        } else if (domestic instanceof Buffalo) {
            Milk milk = new Milk(row, col);
            Map.products.add(milk);
        }
    }

    public static void eat() {
        for (Domestic domestic : Map.domestics) {
            if (domestic.isHungry) {
                for (Grass grass : Map.grasses) {
                    if (grass.row == domestic.row && grass.col == domestic.col) {
                        if (!domestic.interDomestics(domestic).isEmpty()) {
                            Domestic weak = domestic;
                            for (Domestic domestic1 : domestic.interDomestics(domestic)) {
                                weak = domestic1.weaker(domestic1, weak);
                            }
                            domestic = weak;
                        }
                        domestic.life = 100;
                        domestic.isHungry = false;
                        Map.grasses.remove(grass);
                        break;
                    }
                }
                if (Map.grasses.isEmpty()) {
                    break;
                }
            }
        }
    }

    ArrayList<Domestic> interDomestics(Domestic domestic) {
        ArrayList<Domestic> inter = new ArrayList<>();
        if (isHungry) {
            for (Domestic domestic1 : Map.domestics) {
                if (domestic1 != domestic && domestic.row == domestic1.row && domestic.col == domestic1.col && domestic1.isHungry) {
                    inter.add(domestic1);
                }
            }
        }
        return inter;
    }

    Domestic weaker(Domestic domestic1, Domestic domestic2) {
        if (domestic1.life > domestic2.life) {
            return domestic2;
        } else if (domestic1.life < domestic2.life) {
            return domestic1;
        } else {
            Random random = new Random();
            int m = random.nextInt(2);
            if (m == 0) return domestic1;
            else return domestic2;
        }
    }
}
