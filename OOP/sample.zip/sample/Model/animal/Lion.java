package sample.Model.animal;

import sample.Model.Map;

public class Lion extends Wild {
    public Lion() {
        maxCage = 3;
        step = 1;
        this.setType();
    }

    @Override
    public void setType() {
        this.type="lion";
    }


}
