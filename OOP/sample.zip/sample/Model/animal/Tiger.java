package sample.Model.animal;

import sample.Model.Map;
import sample.Model.Map;

import java.util.Random;

public class Tiger extends Wild {
    int right = 0;
    int down = 0;


    public Tiger() {
        maxCage = 4;
        step = 2;
        this.setType();
    }

    @Override
    public void setType() {
        this.type = "tiger";
    }

    public void move() {
        right = 0;
        down = 0;
        Random random = new Random();
        int rowP = row;
        int colP = col;

        if (!isCaged) {
            if (row < 7 - step && col < 7 - step && row > step && col > step) {
                int m = random.nextInt(4);
                if (m < 2) {
                    row += m == 0 ? -step : +step;
                } else {
                    col += m == 2 ? -step : +step;
                }
            } else if (row <= step && col > step && col < 7 - step) {
                int m = random.nextInt(3);
                if (m < 2) {
                    col += m == 0 ? -step : +step;
                } else {
                    row += step;
                }
            } else if (row >= 7 - step && col > step && col < 7 - step) {
                int m = random.nextInt(3);
                if (m < 2) {
                    col += m == 0 ? -step : +step;
                } else {
                    row -= step;
                }
            } else if (col <= step && row > step && row < 7 - step) {
                int m = random.nextInt(3);
                if (m < 2) {
                    row += m == 0 ? -step : +step;
                } else {
                    col += step;
                }
            } else if (col >= 7 - step && row > step && row < 7 - step) {
                int m = random.nextInt(3);
                if (m < 2) {
                    row += m == 0 ? -step : +step;
                } else {
                    col -= step;
                }
            } else if (row <= step && col <= step) {
                int m = random.nextInt(2);
                if (m == 0) {
                    row += step;
                } else {
                    col += step;
                }
            } else if (row <= step) {
                int m = random.nextInt(2);
                if (m == 0) {
                    row += step;
                } else {
                    col -= step;
                }
            } else if (col <= step) {
                int m = random.nextInt(2);
                if (m == 0) {
                    row -= step;
                } else {
                    col += step;
                }
            } else {
                int m = random.nextInt(2);
                if (m == 0) {
                    row -= step;
                } else {
                    col -= step;
                }
            }

            if (row > rowP) {
                down = 1;
                side = "down";
            } else if (row < rowP) {
                down = -1;
                side = "up";
            } else if (col > colP) {
                right = 1;
                side = "right";
            } else if (col < colP) {
                right = -1;
                side = "left";
            }
        }
    }

    public static void killT() {
        for (Wild wild : Map.wilds) {
            if (wild instanceof Tiger && !wild.isCaged) {
                if (((Tiger) wild).down == 1) {
                    Map.domestics.removeIf(domestic -> domestic.row == wild.row - 1 && domestic.col == wild.col);
                    Map.products.removeIf(product -> product.row == wild.row - 1 && product.col == wild.col);
                    Map.cats.removeIf(cat -> cat.row == wild.row - 1 && cat.col == wild.col);
                } else if (((Tiger) wild).down == -1) {
                    Map.domestics.removeIf(domestic -> domestic.row == wild.row + 1 && domestic.col == wild.col);
                    Map.products.removeIf(product -> product.row == wild.row + 1 && product.col == wild.col);
                    Map.cats.removeIf(cat -> cat.row == wild.row + 1 && cat.col == wild.col);
                } else if (((Tiger) wild).right == 1) {
                    Map.domestics.removeIf(domestic -> domestic.row == wild.row && domestic.col == wild.col - 1);
                    Map.products.removeIf(product -> product.row == wild.row && product.col == wild.col - 1);
                    Map.cats.removeIf(cat -> cat.row == wild.row && cat.col == wild.col - 1);
                } else if (((Tiger) wild).right == -1) {
                    Map.domestics.removeIf(domestic -> domestic.row == wild.row && domestic.col == wild.col + 1);
                    Map.products.removeIf(product -> product.row == wild.row && product.col == wild.col + 1);
                    Map.cats.removeIf(cat -> cat.row == wild.row && cat.col == wild.col + 1);
                }
                ((Tiger) wild).right = 0;
                ((Tiger) wild).down = 0;
            }
        }
    }

}
