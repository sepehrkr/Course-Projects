package sample.Model.animal;

public class Turkey extends Domestic {

    public Turkey() {
        cost = 200;
        produceTime = 3;
        this.setType();
    }

    @Override
    public void setType() {
        this.type="turkey";
    }

}
