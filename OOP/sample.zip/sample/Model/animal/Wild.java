package sample.Model.animal;

import sample.Model.Map;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import sample.Model.Map;

import java.util.ArrayList;
import java.util.Random;

@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = "type")
@JsonSubTypes({
        @JsonSubTypes.Type(value = Bear.class, name = "bear"),
        @JsonSubTypes.Type(value = Lion.class, name = "lion"),
        @JsonSubTypes.Type(value = Tiger.class, name = "tiger")
})
public abstract class Wild extends Animal implements Cloneable {
    public int cages;
    public int cageTimer;
    public int maxCage;
    final static int CAGE_TIME = 5;
    boolean cageChecker;
    boolean cageStart;
    public boolean isCaged;


    Wild() {
        cages = 0;
        cageTimer = 0;
        cageStart = false;
        isCaged = false;
        cageChecker = false;
    }

    public static void kill() {
        for (Wild wild : Map.wilds) {
            if (!wild.isCaged) {
                Map.domestics.removeIf(domestic -> domestic.row == wild.row && domestic.col == wild.col);
                Map.products.removeIf(product -> product.row == wild.row && product.col == wild.col);
                Map.cats.removeIf(cat -> cat.row == wild.row && cat.col == wild.col);
            }
        }
    }

    public static void update() {
        ArrayList<Wild> removedWilds = new ArrayList<>();
        for (Wild wild : Map.wilds) {
            if (wild.cageStart) {
                if (wild.cageChecker) {
                    wild.cageChecker = false;
                    if (wild.cages == wild.maxCage) {
                        wild.isCaged = true;
                        wild.cageStart = false;
                    }
                } else {
                    wild.cages--;
                    if (wild.cages == 0) {
                        wild.cageStart = false;
                    }
                }
            } else if (wild.isCaged) {
                wild.cageTimer++;
                if (wild.cageTimer == Wild.CAGE_TIME) {
                    removedWilds.add(wild);
                }
            }
        }
        for (Wild wild : removedWilds) {
            Map.wilds.remove(wild);
        }
    }


    @Override
    public void move() {
        if (!isCaged) {
            Random random = new Random();
            int rowP = row;
            int colP = col;

            if (row < 7 - step && col < 7 - step && row > step && col > step) {
                int m = random.nextInt(4);
                if (m < 2) {
                    row += m == 0 ? -step : +step;
                } else {
                    col += m == 2 ? -step : +step;
                }
            } else if (row <= step && col > step && col < 7 - step) {
                int m = random.nextInt(3);
                if (m < 2) {
                    col += m == 0 ? -step : +step;
                } else {
                    row += step;
                }
            } else if (row >= 7 - step && col > step && col < 7 - step) {
                int m = random.nextInt(3);
                if (m < 2) {
                    col += m == 0 ? -step : +step;
                } else {
                    row -= step;
                }
            } else if (col <= step && row > step && row < 7 - step) {
                int m = random.nextInt(3);
                if (m < 2) {
                    row += m == 0 ? -step : +step;
                } else {
                    col += step;
                }
            } else if (col >= 7 - step && row > step && row < 7 - step) {
                int m = random.nextInt(3);
                if (m < 2) {
                    row += m == 0 ? -step : +step;
                } else {
                    col -= step;
                }
            } else if (row <= step && col <= step) {
                int m = random.nextInt(2);
                if (m == 0) {
                    row += step;
                } else {
                    col += step;
                }
            } else if (row <= step) {
                int m = random.nextInt(2);
                if (m == 0) {
                    row += step;
                } else {
                    col -= step;
                }
            } else if (col <= step) {
                int m = random.nextInt(2);
                if (m == 0) {
                    row -= step;
                } else {
                    col += step;
                }
            } else {
                int m = random.nextInt(2);
                if (m == 0) {
                    row -= step;
                } else {
                    col -= step;
                }
            }

            if (row > rowP) {
                side = "down";
            } else if (row < rowP) {
                side = "up";
            } else if (col > colP) {
                side = "right";
            } else if (col < colP) {
                side = "left";
            }
        }
    }

    public int cage() {
        if (!isCaged) {
            if (cageChecker) {
                return 0;
            }
            cages++;
            cageChecker = true;
            if (!cageStart) {
                cageStart = true;
            }
            return 1;
        } else return -1;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
