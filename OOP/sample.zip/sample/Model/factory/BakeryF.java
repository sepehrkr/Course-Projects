package sample.Model.factory;

import sample.Model.Storage;
import sample.Model.Store;

public class BakeryF extends Factory {

    public BakeryF() {
        cost = 250;
        timeUnit = 5;
    }

    @Override
    void fillChecker() {
        if (!Store.getInstance().storeFlours.isEmpty()) {
            isFilled = true;
            Store.getInstance().storeFlours.remove(0);
            Store.getInstance().currentStorage -= Storage.FLOUR.getStorage();
            if (level == 2) {
                if (Store.getInstance().storeFlours.size() >= 1) {
                    Store.getInstance().storeFlours.remove(0);
                    Store.getInstance().currentStorage -= Storage.FLOUR.getStorage();
                    isTwo = true;
                }
            }
        }
    }
}
