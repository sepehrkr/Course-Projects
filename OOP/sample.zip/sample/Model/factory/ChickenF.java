package sample.Model.factory;

import sample.Model.Storage;
import sample.Model.Store;

public class ChickenF extends Factory {
    public ChickenF() {
        cost = 250;
        timeUnit = 5;
    }

    @Override
    void fillChecker() {
        if (!Store.getInstance().storeEggs.isEmpty()) {
            isFilled = true;
            Store.getInstance().storeEggs.remove(0);
            Store.getInstance().currentStorage -= Storage.EGG.getStorage();
            if (level == 2) {
                if (Store.getInstance().storeEggs.size() >= 1) {
                    Store.getInstance().storeEggs.remove(0);
                    Store.getInstance().currentStorage -= Storage.EGG.getStorage();
                    isTwo = true;
                }
            }
        }
    }
}
