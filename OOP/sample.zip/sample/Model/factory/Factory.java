package sample.Model.factory;

import sample.Model.Map;
import sample.Model.animal.Chicken;
import sample.Model.product.*;

import java.util.ArrayList;

import sample.Model.Map;
import sample.Model.product.*;

public abstract class Factory {

    int level;
    boolean isFilled;
    public boolean isWorking;
    int cost;
    int timeUnit;
    int counter;
    boolean isTwo;

    Factory() {
        counter = 0;
        isWorking = false;
        isFilled = false;
        isTwo = false;
        level = 1;
    }

    public static void update() {
        for (Factory factory : Map.factories) {
            if (factory.isWorking) {
                factory.counter++;
            }
        }
    }

    public static void produce() {
        for (Factory factory : Map.factories) {
            if (factory.level == 2 && !factory.isTwo) {
                int h;
                if (factory.timeUnit % 2 == 1) {
                    h = 1 + factory.timeUnit / 2;
                } else h = factory.timeUnit / 2;
                if (factory.counter == h && factory.isWorking) {
                    factory.produceP(factory);
                    factory.isFilled = false;
                    factory.isTwo = false;
                    factory.isWorking = false;
                    factory.counter = 0;
                }
            } else {
                if (factory.counter == factory.timeUnit && factory.isWorking) {
                    factory.produceP(factory);
                    factory.isTwo = false;
                    factory.isFilled = false;
                    factory.isWorking = false;
                    factory.counter = 0;
                }
            }
        }
    }

    void produceP(Factory factory) {
        if (factory instanceof MillF) {
            Map.products.add(new Flour());
            if (level == 2 && isTwo) {
                Map.products.add(new Flour());
            }
        } else if (factory instanceof TextileF) {
            Map.products.add(new Cloth());
            if (level == 2 && isTwo) {
                Map.products.add(new Cloth());
            }
        } else if (factory instanceof MilkF) {
            Map.products.add(new PackMilk());
            if (level == 2 && isTwo) {
                Map.products.add(new PackMilk());
            }
        } else if (factory instanceof BakeryF) {
            Map.products.add(new Bread());
            if (level == 2 && isTwo) {
                Map.products.add(new Bread());
            }
        } else if (factory instanceof TailoringF) {
            Map.products.add(new Shirt());
            if (level == 2 && isTwo) {
                Map.products.add(new Shirt());
            }
        } else if (factory instanceof IceCreamF) {
            Map.products.add(new IceCream());
            if (level == 2 && isTwo) {
                Map.products.add(new IceCream());
            }
        } else if (factory instanceof ChickenF) {
            Chicken chicken = new Chicken();
            chicken.row = 6;
            chicken.col = 5;
            Map.domestics.add(chicken);
            if (level == 2 && isTwo) {
                Chicken chicken1 = new Chicken();
                chicken.row = 6;
                chicken.col = 5;
                Map.domestics.add(chicken1);
            }
        }
    }

    public int work()       // Return -1 for No Supply , -2 for Already working , 1 success
    {
        if (!isWorking) {
            fillChecker();
            if (isFilled) {
                isWorking = true;
                return 1;
            } else {
                return -1;
            }
        } else {
            return -2;
        }
    }

    public int upgrade() // Return -1 for Max Level , -2 for Is Working , 1 success
    {
        if (!isWorking) {
            if (level == 1) {
                level++;
                return 1;
            } else {
                return -1;
            }
        } else {
            return -2;
        }
    }

    abstract void fillChecker();
}
