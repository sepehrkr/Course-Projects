package sample.Model.factory;

import sample.Model.Storage;
import sample.Model.Store;

public class IceCreamF extends Factory {

    public IceCreamF() {
        cost = 550;
        timeUnit = 7;
    }

    @Override
    void fillChecker() {
        if (!Store.getInstance().storePackMilks.isEmpty()) {
            isFilled = true;
            Store.getInstance().storePackMilks.remove(0);
            Store.getInstance().currentStorage -= Storage.PACK_MILK.getStorage();
            if (level == 2) {
                if (Store.getInstance().storePackMilks.size() >= 1) {
                    Store.getInstance().storePackMilks.remove(0);
                    Store.getInstance().currentStorage -= Storage.PACK_MILK.getStorage();
                    isTwo = true;
                }
            }
        }
    }
}
