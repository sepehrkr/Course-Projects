package  sample.Model.factory;

import sample.Model.Storage;
import sample.Model.Store;

public class MilkF extends Factory {

    public MilkF() {
        cost = 400;
        timeUnit = 6;
    }

    @Override
    void fillChecker() {
        if (!Store.getInstance().storeMilks.isEmpty()) {
            isFilled = true;
            Store.getInstance().storeMilks.remove(0);
            Store.getInstance().currentStorage -= Storage.MILK.getStorage();
            if (level == 2) {
                if (Store.getInstance().storeMilks.size() >= 1) {
                    Store.getInstance().storeMilks.remove(0);
                    Store.getInstance().currentStorage -= Storage.MILK.getStorage();
                    isTwo = true;
                }
            }
        }
    }
}
