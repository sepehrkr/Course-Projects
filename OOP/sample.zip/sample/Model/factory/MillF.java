package sample.Model.factory;

import sample.Model.Storage;
import sample.Model.Store;

public class MillF extends Factory {

    public MillF() {
        cost = 150;
        timeUnit = 4;
    }

    @Override
    void fillChecker() {
        if (!Store.getInstance().storeEggs.isEmpty()) {
            isFilled = true;
            Store.getInstance().storeEggs.remove(0);
            Store.getInstance().currentStorage -= Storage.EGG.getStorage();
            if (level == 2) {
                if (Store.getInstance().storeEggs.size() >= 1) {
                    Store.getInstance().storeEggs.remove(0);
                    Store.getInstance().currentStorage -= Storage.EGG.getStorage();
                    isTwo = true;
                }
            }
        }
    }
}
