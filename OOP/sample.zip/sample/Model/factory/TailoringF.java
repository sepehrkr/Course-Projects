package sample.Model.factory;

import sample.Model.Storage;
import sample.Model.Store;

public class TailoringF extends Factory {

    public TailoringF() {
        cost = 400;
        timeUnit = 6;
    }

    @Override
    void fillChecker() {
        if (!Store.getInstance().storeClothes.isEmpty()) {
            isFilled = true;
            Store.getInstance().storeClothes.remove(0);
            Store.getInstance().currentStorage -= Storage.CLOTH.getStorage();
            if (level == 2) {
                if (Store.getInstance().storeClothes.size() >= 1) {
                    Store.getInstance().storeClothes.remove(0);
                    Store.getInstance().currentStorage -= Storage.CLOTH.getStorage();
                    isTwo = true;
                }
            }
        }
    }
}
