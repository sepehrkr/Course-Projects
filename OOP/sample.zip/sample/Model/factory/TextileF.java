package sample.Model.factory;

import sample.Model.Storage;
import sample.Model.Store;

public class TextileF extends Factory {

    public TextileF() {
        cost = 250;
        timeUnit = 5;
    }

    @Override
    void fillChecker() {
        if (!Store.getInstance().storeFeathers.isEmpty()) {
            isFilled = true;
            Store.getInstance().storeFeathers.remove(0);
            Store.getInstance().currentStorage -= Storage.FEATHER.getStorage();
            if (level == 2) {
                if (Store.getInstance().storeFeathers.size() >= 1) {
                    Store.getInstance().storeFeathers.remove(0);
                    Store.getInstance().currentStorage -= Storage.FEATHER.getStorage();
                    isTwo = true;
                }
            }
        }
    }
}
