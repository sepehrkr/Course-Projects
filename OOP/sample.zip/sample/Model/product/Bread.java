package sample.Model.product;

public class Bread extends Product {
    public Bread() {
        row = 5;
        col = 6;
        expireTime = 6;
    }
}
