package sample.Model.product;

public class Cloth extends Product {
    public Cloth() {
        row = 5;
        col = 1;
        expireTime = 5;
    }
}
