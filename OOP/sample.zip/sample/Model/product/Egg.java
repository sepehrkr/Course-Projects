package sample.Model.product;

public class Egg extends Product {

    public Egg(int row, int col) {
        super(row, col);
        expireTime = 4;
    }

    public Egg() {
        expireTime = 4;
    }
}
