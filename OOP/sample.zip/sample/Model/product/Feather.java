package sample.Model.product;

public class Feather extends Product {

    public Feather(int row, int col) {
        super(row, col);
        expireTime = 4;
    }

    public Feather() {
        expireTime = 4;
    }
}
