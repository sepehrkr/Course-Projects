package sample.Model.product;

public class Flour extends Product {
    public Flour() {
        row = 2;
        col = 1;
        expireTime = 5;
    }
}
