package sample.Model.product;

public class IceCream extends Product {
    public IceCream() {
        row = 1;
        col = 2;
        expireTime = 6;
    }
}
