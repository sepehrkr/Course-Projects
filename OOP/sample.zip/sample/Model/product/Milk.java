package sample.Model.product;

public class Milk extends Product {

    public Milk(int row, int col) {
        super(row, col);
        expireTime = 4;
    }

    public Milk() {
        expireTime = 4;
    }
}
