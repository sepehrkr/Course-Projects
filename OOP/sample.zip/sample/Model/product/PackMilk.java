package sample.Model.product;

public class PackMilk extends Product {
    public PackMilk(){
        row = 3;
        col = 6;
        expireTime = 5;
    }
}
