package sample.Model.product;

import sample.Model.Map;

import java.util.ArrayList;
import java.util.Random;

public abstract class Product {
    int expireTime;
    int timer = 0;
    public int row;
    public int col;

    public Product(int row, int col) {
        this.row = row;
        this.col = col;
    }

    public Product() {
        Random random = new Random();
        row = random.nextInt(6) + 1;
        col = random.nextInt(6) + 1;
    }

    public static void update() {
        ArrayList<Product> expired = new ArrayList<>();
        for (Product product : Map.products) {
            product.timer++;
            if (product.timer == product.expireTime) {
                expired.add(product);
                product.timer = 0;
            }
        }
        for (Product product : expired) {
            Map.products.remove(product);
        }
    }
}
