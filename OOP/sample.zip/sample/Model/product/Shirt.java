package sample.Model.product;

public class Shirt extends Product {
    public Shirt() {
        row = 1;
        col = 6;
        expireTime = 6;
    }
}
