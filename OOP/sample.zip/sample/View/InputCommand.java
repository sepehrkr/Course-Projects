package sample.View;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum InputCommand {
    BUY("(?i)^\\s*buy\\s+([\\w,\\s]+)\\s*$"),
    PICKUP("(?i)^\\s*pickup\\s+(\\d+)\\s+(\\d+)s*$"),
    WELL("(?i)^\\s*WELL\\s*$"),
    PLANT("(?i)^\\s*plant\\s+(\\d+)\\s+(\\d+)\\s*$"),
    WORK("(?i)^\\s*work\\s+([\\w,\\s]+)\\s*$"),
    CAGE("(?i)^\\s*cage\\s+(\\d+)\\s+(\\d+)\\s*$"),
    TURN("(?i)^\\s*turn\\s+(\\d+)\\s*$"),
    TRUCK_LOAD("(?i)^\\s*TRUCK\\s+LOAD\\s+([\\w,\\s]+)\\s*$"),
    TRUCK_UNLOAD("(?i)^\\s*TRUCK\\s+UNLOAD\\s+([\\w,\\s]+)\\s*$"),
    TRUCK_GO("(?i)^\\s*TRUCK\\s+GO\\s*$"),
    MENU("(?i)^\\s*Menu\\s*$"),
    START("(?i)^\\s*Start\\s+(\\d+)\\s*$"),
    SIGN_IN("(?i)^\\s*sign\\s+in\\s*$"),
    SIGN_UP("(?i)^\\s*sign\\s+up\\s*$"),
    EXIT("(?i)^\\s*exit\\s*$"),
    BUILD("(?i)^\\s*build\\s+([\\w,\\s]+)\\s*$"),
    UPGRADE("(?i)^\\s*upgrade\\s+([\\w,\\s]+)\\s*$"),
    INQUIRY("(?i)^\\s*Inquiry\\s*$");



    Pattern pattern;

    InputCommand(String s) {
        pattern=Pattern.compile(s);
    }
    public Matcher getMatcher (String input)
    {
        return pattern.matcher(input);
    }
}
