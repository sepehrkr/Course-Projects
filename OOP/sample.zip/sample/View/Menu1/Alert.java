package sample.View.Menu1;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import sample.Main;

import java.util.concurrent.TimeUnit;

public class Alert {

    public Label label;
    public Button no;
    public Button yes;

    public void quit() {
        try {
            TimeUnit.MILLISECONDS.sleep(250);
        } catch (InterruptedException ignored) {

        }
        Main.alertStage.close();
        Main.window.close();
    }

    public void back() {
        Main.alertStage.close();
    }
}
