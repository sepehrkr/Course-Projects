package sample.View.Menu1;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import sample.Controller.Controller;
import sample.Main;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class FinishLevel implements Initializable {

    public static long time=-1;
    public static long prize = -1;

    @FXML
    private Label firstPrize;

    @FXML
    private Label thirdPrize;

    @FXML
    private Label secondPrize;

    @FXML
    private Label yourPrize;

    @FXML
    private Label timeFinished;

    @FXML
    private Label firstTime;

    @FXML
    private Label secondTime;

    @FXML
    private Label thirdTime;

    @FXML
    void back(MouseEvent event) throws IOException {
        GameMenu.shopStage.close();
        Main.mp.stop();
            if (Login1.level == Login1.levelW) {
                Login1.level++;
        }
        Login1.setLevels(Login1.level);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        timeFinished.setText(Long.toString(time));
        yourPrize.setText(Long.toString(prize));

        switch (GameMenu.level){

            case 0 :
                firstPrize.setText("400");
                firstTime.setText("40");
                secondPrize.setText("200");
                secondTime.setText("45");
                thirdPrize.setText("100");
                thirdTime.setText("50");
                break;
            case 1:
                firstPrize.setText("400");
                firstTime.setText("50");
                secondPrize.setText("200");
                secondTime.setText("55");
                thirdPrize.setText("100");
                thirdTime.setText("60");
                break;
            case 2:
                firstPrize.setText("400");
                firstTime.setText("60");
                secondPrize.setText("200");
                secondTime.setText("65");
                thirdPrize.setText("100");
                thirdTime.setText("70");
                break;
            case 3:
                firstPrize.setText("400");
                firstTime.setText("70");
                secondPrize.setText("200");
                secondTime.setText("75");
                thirdPrize.setText("100");
                thirdTime.setText("80");
                break;
            case 4:
                firstPrize.setText("400");
                firstTime.setText("80");
                secondPrize.setText("200");
                secondTime.setText("85");
                thirdPrize.setText("100");
                thirdTime.setText("90");
                break;

        }

    }
}
