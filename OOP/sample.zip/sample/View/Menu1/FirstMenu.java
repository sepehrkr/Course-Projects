package sample.View.Menu1;

import sample.Controller.Controller;
import sample.Controller.Log;
import sample.Main;
import sample.View.Menu1.Login1;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;


public class FirstMenu implements Initializable {

    public void exit() throws IOException {
        Main.alertStage.setTitle("Exit");
        Main.newStage("View/Menu1/Alert.fxml", 450, 300);
    }

    public void signUpMenu() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("View/Menu1/loginMenu.fxml"));
        Parent root = loader.load();
        Main.window.getScene().setRoot(root);
        Login1 logIn = loader.getController();
        logIn.enter.setText("Sign Up");
        logIn.wrongLog.setLayoutX(530 - 40);
        logIn.enter.setOnAction(e -> {
            String name = logIn.username.getText().trim();
            String pass = logIn.password.getText().trim();
            if (name.isEmpty() || pass.isEmpty()){
                logIn.wrongLog.setText("Enter your data");
            } else if (Controller.checkRegistration(name)) {
                Controller.addPerson(name, pass);
                Controller.getInstance().doRegistration();
                Login1.level = 1;
                try {
                    Login1.setLevels(Login1.level);
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
            }  else {
                logIn.wrongLog.setText("Username already exists");
            }
        });
    }

    public void signInMenu() throws IOException {
        try {
            TimeUnit.MILLISECONDS.sleep(250);
        } catch (InterruptedException ignored) {

        }
        Main.changeScene("View/Menu1/loginMenu.fxml");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        Controller.readPerson();
    }
}
