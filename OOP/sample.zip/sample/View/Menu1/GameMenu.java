package sample.View.Menu1;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.Transition;
import javafx.animation.TranslateTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;
import sample.Controller.*;
import sample.Main;
import sample.Model.Grass;
import sample.Model.Map;
import sample.Model.Price;
import sample.Model.Vehicle;
import sample.Model.animal.*;
import sample.Model.factory.*;
import sample.Model.product.*;
import sample.Model.product.Product;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class GameMenu implements Initializable {

    Controller controller = Controller.getInstance();

    public static ObservableList<ImageView> domestics = FXCollections.observableArrayList();
    public static ObservableList<ImageView> wilds = FXCollections.observableArrayList();
    public static  ObservableList<ImageView> cats = FXCollections.observableArrayList();
    public static ObservableList<ImageView> dogs = FXCollections.observableArrayList();
    public static ObservableList<ImageView> grasses = FXCollections.observableArrayList();
    public static ObservableList<ImageView> products = FXCollections.observableArrayList();

    public static boolean gotoMouseMethod = true;

    public static Animation wellAnimation;

    public static Animation bakeryAnimation;

    public static Animation textileAnimation;

    public static Animation tailoringAnimation;

    public static Animation milkAnimation;

    public static Animation millAnimation;

    public static Animation iceCreamAnimation;

    public static Animation chickenFAnimation;

    @FXML
    private AnchorPane farm;

    @FXML
    public ImageView well;

    @FXML
    public ImageView bakeryF;

    @FXML
    public ImageView millF;

    @FXML
    public ImageView textileF;

    @FXML
    public ImageView tailoringF;

    @FXML
    public ImageView milkF;

    @FXML
    public ImageView iceCreamF;

    @FXML
    public ImageView chickenF;


    @FXML
    private ImageView buildBakery;

    @FXML
    private ImageView millBuild;

    @FXML
    private ImageView textileBuild;

    @FXML
    private ImageView tailoring;

    @FXML
    private ImageView milkBuild;

    @FXML
    private ImageView iceCreamBuild;

    @FXML
    private ImageView chickenFBuild;

    @FXML
    public Label time;

    @FXML
    public Label coin;

    @FXML
    public ImageView vehicle;

    @FXML
    public AnchorPane mainPane;

    static boolean eggC = false;
    static boolean featherC = false;
    static boolean milkC = false;
    static boolean flourC = false;
    static boolean clothC = false;
    static boolean packC = false;
    static boolean breadC = false;
    static boolean shirtC = false;
    static boolean iceC = false;

    @FXML
    void buildingBakery(MouseEvent event) {

        int b  = controller.upgrade("bakery f");
        int a =  controller.build("bakery f");

        if (a==1) {
            buildBakery.setImage(MyImage.upgrade);
            coin.setText(Long.toString(Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].coins));
            return;
        }
        if (b==1){
            buildBakery.setVisible(false);
            coin.setText(Long.toString(Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].coins));
        }
    }

    @FXML
    void chickenFBuilding(MouseEvent event) {
        int b  = controller.upgrade("chicken f");
        int a =  controller.build("chicken f");

        if (a==1) {
            chickenFBuild.setImage(MyImage.upgrade);
            coin.setText(Long.toString(Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].coins));
            return;
        }
        if (b==1){
            chickenFBuild.setVisible(false);
            coin.setText(Long.toString(Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].coins));
        }
    }

    @FXML
    void iceCreamBuilding(MouseEvent event) {
        int b  = controller.upgrade("ice cream f");
        int a =  controller.build("ice cream f");

        if (a==1) {
            iceCreamBuild.setImage(MyImage.upgrade);
            coin.setText(Long.toString(Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].coins));
            return;
        }
        if (b==1){
            iceCreamBuild.setVisible(false);
            coin.setText(Long.toString(Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].coins));
        }
    }

    @FXML
    void milkBuilding(MouseEvent event) {
        int b  = controller.upgrade("milk f");
        int a =  controller.build("milk f");

        if (a==1) {
            milkBuild.setImage(MyImage.upgrade);
            coin.setText(Long.toString(Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].coins));
            return;
        }
        if (b==1){
            milkBuild.setVisible(false);
            coin.setText(Long.toString(Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].coins));
        }
    }

    @FXML
    void millBuilding(MouseEvent event) {
        System.out.println(Map.factories.size());
        int b  = controller.upgrade("mill f");
        int a =  controller.build("mill f");

        if (a==1) {
            millBuild.setImage(MyImage.upgrade);
            System.out.println(Map.factories.size());
            coin.setText(Long.toString(Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].coins));
            return;
        }
        if (b==1){
            millBuild.setVisible(false);
            System.out.println(Map.factories.size());
            coin.setText(Long.toString(Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].coins));
        }
    }

    @FXML
    void tailoringBuilding(MouseEvent event) {
        int b  = controller.upgrade("tailoring f");
        int a =  controller.build("tailoring f");

        if (a==1) {
            tailoring.setImage(MyImage.upgrade);
            coin.setText(Long.toString(Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].coins));
            return;
        }
        if (b==1){
            tailoring.setVisible(false);
            coin.setText(Long.toString(Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].coins));
        }
    }

    @FXML
    void textileBuilding(MouseEvent event) {
        int b  = controller.upgrade("textile f");
        int a =  controller.build("textile f");

        if (a==1) {
            textileBuild.setImage(MyImage.upgrade);
            coin.setText(Long.toString(Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].coins));
            return;
        }
        if (b==1){
            textileBuild.setVisible(false);
            coin.setText(Long.toString(Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].coins));
        }
    }

    @FXML
    void welling(MouseEvent event) {
        boolean truth = Controller.getInstance().well();
        if (truth) {
            well.setImage(MyImage.well);
            well.setViewport(new Rectangle2D(0, 0, MyImage.wellFixed_width, MyImage.wellFixed_height));
            wellAnimation = new SpriteAnimation(well, Duration.millis(700), MyImage.wellFixed_count, MyImage.wellFixed_col, 0, 0, MyImage.wellFixed_width, MyImage.wellFixed_height);
            wellAnimation.setCycleCount(Animation.INDEFINITE);
            wellAnimation.play();
        }
    }

    @FXML
    void workBakery(MouseEvent event) {
        boolean truth = controller.work("bakery f");
        if (truth){
            bakeryF.setImage(MyImage.bakery);
            bakeryAnimation = new SpriteAnimation(bakeryF,Duration.millis(800),MyImage.bakery_count,MyImage.bakery_column,0,0,MyImage.bakery_width,MyImage.bakery_height);
            bakeryAnimation.setCycleCount(Animation.INDEFINITE);
            bakeryAnimation.play();
        }
    }

    @FXML
    void workChicken(MouseEvent event) {
        boolean truth = controller.work("chicken f");
        if (truth){
            chickenF.setImage(MyImage.chickenF);
            chickenFAnimation = new SpriteAnimation(chickenF,Duration.millis(800),MyImage.chickenF_count,MyImage.chickenF_column,0,0,MyImage.chickenF_width,MyImage.chickenF_height);
            chickenFAnimation.setCycleCount(Animation.INDEFINITE);
            chickenFAnimation.play();
        }
    }

    @FXML
    void workIceCream(MouseEvent event) {
        boolean truth = controller.work("ice cream f");
        if (truth){
            iceCreamF.setImage(MyImage.iceCreamF);
            iceCreamAnimation = new SpriteAnimation(iceCreamF,Duration.millis(800),MyImage.iceCreamF_count,MyImage.iceCreamF_column,0,0,MyImage.iceCreamF_width,MyImage.iceCreamF_height);
            iceCreamAnimation.setCycleCount(Animation.INDEFINITE);
            iceCreamAnimation.play();
        }
    }

    @FXML
    void workMilk(MouseEvent event) {
        boolean truth = controller.work("milk f");
        if (truth){
            milkF.setImage(MyImage.milkF);
            milkAnimation = new SpriteAnimation(milkF,Duration.millis(800),MyImage.milkF_count,MyImage.milkF_column,0,0,MyImage.milkF_width,MyImage.milkF_height);
            milkAnimation.setCycleCount(Animation.INDEFINITE);
            milkAnimation.play();
        }
    }

    @FXML
    void workMill(MouseEvent event) {
        boolean truth = controller.work("mill f");
        if (truth){
            millF.setImage(MyImage.millF);
            millF.setViewport(new Rectangle2D(0,0,MyImage.millF_width,MyImage.milkF_height));
            millAnimation = new SpriteAnimation(millF,Duration.millis(800),MyImage.millF_count,MyImage.millF_column,0,0,MyImage.millF_width,MyImage.millF_height);
            millAnimation.setCycleCount(Animation.INDEFINITE);
            millAnimation.play();
        }
    }

    @FXML
    void workTailoring(MouseEvent event) {
        boolean truth = controller.work("tailoring f");
        if (truth){
            tailoringF.setImage(MyImage.tailoringF);
            tailoringAnimation = new SpriteAnimation(tailoringF,Duration.millis(800),MyImage.tailoringF_count,MyImage.tailoringF_column,0,0,MyImage.tailoringF_width,MyImage.tailoringF_height);
            tailoringAnimation.setCycleCount(Animation.INDEFINITE);
            tailoringAnimation.play();
        }
    }

    @FXML
    void workTextile(MouseEvent event) {
        boolean truth = controller.work("textile f");
        if (truth){
            textileF.setImage(MyImage.textileF);
            textileAnimation = new SpriteAnimation(textileF,Duration.millis(800),MyImage.textileF_count,MyImage.textileF_column,0,0,MyImage.textileF_width,MyImage.textileF_height);
            textileAnimation.setCycleCount(Animation.INDEFINITE);
            textileAnimation.play();
        }
    }




    @FXML
    void mouseClick(MouseEvent event) {
        int [] coordinate  = convertTo(event.getX(),event.getY());
        int row = coordinate[0];
        int col = coordinate[1];
        double [] point = convertTo(row,col);
        System.out.println(row+" , "+col);
        System.out.println(event.getX() +" , " +event.getY());

        if (controller.cage(row,col)){
            ImageView cage = new ImageView();
            for (Wild wild : Map.wilds){
                if (wild.row == row && wild.col==col){
                    if (wild instanceof Lion){
                        if (wild.cages==1){
                            cage.setImage(MyImage.cage1);
                            cage.setLayoutX(event.getX()-50);
                            cage.setLayoutY(event.getY()-100);
                            farm.getChildren().add(cage);
                            return;
                        }
                        if (wild.cages==2){
                            cage.setImage(MyImage.cage5);
                            cage.setLayoutX(event.getX()-50);
                            cage.setLayoutY(event.getY()-100);
                            farm.getChildren().add(cage);
                            return;
                        }
                        if (wild.cages==3){
                            cage.setImage(MyImage.cage7);
                            cage.setLayoutX(event.getX()-50);
                            cage.setLayoutY(event.getY()-100);
                            farm.getChildren().add(cage);
                            return;
                        }
                    } else if (wild instanceof Bear || wild instanceof Tiger){
                        if (wild.cages==1){
                            cage.setImage(MyImage.cage1);
                            cage.setLayoutX(event.getX()-50);
                            cage.setLayoutY(event.getY()-100);
                            farm.getChildren().add(cage);
                            return;
                        }
                        if (wild.cages==2){
                            cage.setImage(MyImage.cage3);
                            cage.setLayoutX(event.getX()-50);
                            cage.setLayoutY(event.getY()-100);
                            farm.getChildren().add(cage);
                            return;
                        }
                        if (wild.cages==3){
                            cage.setImage(MyImage.cage5);
                            cage.setLayoutX(event.getX()-50);
                            cage.setLayoutY(event.getY()-100);
                            farm.getChildren().add(cage);
                            return;
                        }
                        if (wild.cages==4){
                            cage.setImage(MyImage.cage7);
                            cage.setLayoutX(event.getX()-50);
                            cage.setLayoutY(event.getY()-100);
                            farm.getChildren().add(cage);
                            return;
                        }
                    }





                }
            }
        }

        if (controller.pickupWild(row,col)){
            return;
        }

        if (gotoMouseMethod) {
            if (controller.plant(row, col)) {
                ImageView grass_moving = new ImageView(MyImage.grass);
                Animation animation = new SpriteAnimation(grass_moving, Duration.millis(900), MyImage.grass_count, MyImage.grass_col, 0, 0, MyImage.grass_width, MyImage.grass_height);
                grass_moving.setLayoutX(point[0]);
                grass_moving.setLayoutY(point[1]);
                //setObject();
                farm.getChildren().add(grass_moving);
                animation.setCycleCount(1);
                animation.play();
            }
        }
        GameMenu.gotoMouseMethod=true;

    }

    @FXML
    void pause(MouseEvent event) throws IOException {
        pause();
    }


    public static Stage shopStage;

    @FXML
    void shop(MouseEvent event) throws IOException {
        shopStage = new Stage();
        shopStage.initModality(Modality.APPLICATION_MODAL);
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("shop.fxml")));
        Scene scene = new Scene(root);
        shopStage.setScene(scene);
        shopStage.showAndWait();
    }

    @FXML
    void store(MouseEvent event) throws IOException {
        shopStage = new Stage();
        shopStage.initModality(Modality.APPLICATION_MODAL);
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("wareHouse.fxml")));
        Scene scene = new Scene(root);
        shopStage.setScene(scene);
        shopStage.showAndWait();
    }

    @FXML
    void turn(MouseEvent event) throws IOException {
        controller.turn(1);
    }

    public static int level;


    // Pause
    public void pause() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("View/Menu1/pause.fxml"));
        Parent root = loader.load();
        Main.alertStage.setScene(new Scene(root, 600, 400));
        Main.alertStage.setTitle("Pause");
        Main.alertStage.show();
        Pause pause = loader.getController();
        if (Main.mp.isMute()) {
            pause.musicImg.setImage(new Image("soundOff.png"));
        }
        Task task = Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].task;
        Level level = Controller.getInstance().levelAlter[Controller.getInstance().currentLevel];
        if (Login1.levelW == 1) {
            pause.task1.setText("Eggs:   " + task.getCurrentEggs() + "/" + task.EGGS);
            pause.task2.setText("Feathers:   " + task.getCurrentFeathers() + "/" + task.FEATHERS);
            pause.task3.setText("Chickens:   " + task.getCurrentChickens() + "/" + task.CHICKENS);
            pause.task4.setText("Coins:   " + level.coins + "/" + task.COINS);
            if (task.getCurrentEggs() >= task.EGGS) {
                eggC = true;
            }
            if (task.getCurrentFeathers() >= task.FEATHERS) {
                featherC = true;
            }
            if (eggC) {
                pause.image1.setImage(new Image("check.jpg"));
            }
            if (featherC) {
                pause.image2.setImage(new Image("check.jpg"));
            }
            if (task.getCurrentChickens() >= task.CHICKENS) {
                pause.image3.setImage(new Image("check.jpg"));
            }
            if (level.coins >= task.COINS) {
                pause.image4.setImage(new Image("check.jpg"));
            }
        } else if (Login1.levelW == 2) {
            pause.task1.setText("Eggs:   " + task.getCurrentEggs() + "/" + task.EGGS);
            pause.task2.setText("Feathers:   " + task.getCurrentFeathers() + "/" + task.FEATHERS);
            pause.task3.setText("Milks:   " + task.getCurrentMilks() + "/" + task.MILKS);
            pause.task4.setText("Flours:   " + task.getCurrentFlours() + "/" + task.FLOURS);
            pause.task5.setText("Chickens:   " + task.getCurrentChickens() + "/" + task.CHICKENS);
            pause.task6.setText("Coins:   " + level.coins + "/" + task.COINS);
            if (task.getCurrentEggs() >= task.EGGS) {
                eggC = true;
            }
            if (task.getCurrentFeathers() >= task.FEATHERS) {
                featherC = true;
            }
            if (task.getCurrentMilks() >= task.MILKS) {
                milkC = true;
            }
            if (task.getCurrentFlours() >= task.FLOURS) {
                flourC = true;
            }
            if (eggC) {
                pause.image1.setImage(new Image("check.jpg"));
            }
            if (featherC) {
                pause.image2.setImage(new Image("check.jpg"));
            }
            if (milkC) {
                pause.image3.setImage(new Image("check.jpg"));
            }
            if (flourC) {
                pause.image4.setImage(new Image("check.jpg"));
            }
            if (task.getCurrentChickens() >= task.CHICKENS) {
                pause.image5.setImage(new Image("check.jpg"));
            }
            if (level.coins >= task.COINS) {
                pause.image6.setImage(new Image("check.jpg"));
            }
        } else if (Login1.levelW == 3) {
            pause.task1.setText("Clothes   " + task.getCurrentCloths() + "/" + task.CLOTHS);
            pause.task2.setText("Pack Milks:   " + task.getCurrentPackMilks() + "/" + task.PACK_MILKS);
            pause.task3.setText("Chickens:   " + task.getCurrentChickens() + "/" + task.CHICKENS);
            pause.task4.setText("Turkeys:   " + task.getCurrentTurkeys() + "/" + task.TURKEYS);
            pause.task5.setText("Coins:   " + level.coins + "/" + task.COINS);
            if (task.getCurrentCloths() >= task.CLOTHS) {
                clothC = true;
            }
            if (task.getCurrentPackMilks() >= task.PACK_MILKS) {
                packC = true;
            }
            if (clothC) {
                pause.image1.setImage(new Image("check.jpg"));
            }
            if (packC) {
                pause.image2.setImage(new Image("check.jpg"));
            }
            if (task.getCurrentChickens() >= task.CHICKENS) {
                pause.image3.setImage(new Image("check.jpg"));
            }
            if (task.getCurrentTurkeys() >= task.TURKEYS) {
                pause.image4.setImage(new Image("check.jpg"));
            }
            if (level.coins >= task.COINS) {
                pause.image5.setImage(new Image("check.jpg"));
            }
        } else if (Login1.levelW == 4) {
            pause.task1.setText("Breads:   " + task.getCurrentBreads() + "/" + task.BREADS);
            pause.task2.setText("Shirts:   " + task.getCurrentShirts() + "/" + task.SHIRTS);
            pause.task3.setText("IceCreams:   " + task.getCurrentIceCreams() + "/" + task.ICE_CREAMS);
            pause.task4.setText("Chickens:   " + task.getCurrentChickens() + "/" + task.CHICKENS);
            pause.task5.setText("Turkeys:   " + task.getCurrentTurkeys() + "/" + task.TURKEYS);
            pause.task6.setText("Coins:   " + level.coins + "/" + task.COINS);
            if (task.getCurrentBreads() >= task.BREADS) {
                breadC = true;
            }
            if (task.getCurrentShirts() >= task.SHIRTS) {
                shirtC = true;
            }
            if (task.getCurrentIceCreams() >= task.ICE_CREAMS) {
                iceC = true;
            }
            if (breadC) {
                pause.image1.setImage(new Image("check.jpg"));
            }
            if (shirtC) {
                pause.image2.setImage(new Image("check.jpg"));
            }
            if (iceC) {
                pause.image3.setImage(new Image("check.jpg"));
            }
            if (task.getCurrentChickens() >= task.CHICKENS) {
                pause.image4.setImage(new Image("check.jpg"));
            }
            if (task.getCurrentTurkeys() >= task.TURKEYS) {
                pause.image5.setImage(new Image("check.jpg"));
            }
            if (level.coins >= task.COINS) {
                pause.image6.setImage(new Image("check.jpg"));
            }
        } else if (Login1.levelW == 5) {
            pause.task1.setText("Breads:   " + task.getCurrentBreads() + "/" + task.BREADS);
            pause.task2.setText("Shirts:   " + task.getCurrentShirts() + "/" + task.SHIRTS);
            pause.task3.setText("IceCreams:   " + task.getCurrentIceCreams() + "/" + task.ICE_CREAMS);
            pause.task4.setText("Turkeys:   " + task.getCurrentTurkeys() + "/" + task.TURKEYS);
            pause.task5.setText("Buffaloes:   " + task.getCurrentBuffaloes() + "/" + task.BUFFALOES);
            pause.task6.setText("Coins:   " + level.coins+ "/" + task.COINS);
            if (task.getCurrentBreads() >= task.BREADS) {
                breadC = true;
            }
            if (task.getCurrentShirts() >= task.SHIRTS) {
                shirtC = true;
            }
            if (task.getCurrentIceCreams() >= task.ICE_CREAMS) {
                iceC = true;
            }
            if (breadC) {
                pause.image1.setImage(new Image("check.jpg"));
            }
            if (shirtC) {
                pause.image2.setImage(new Image("check.jpg"));
            }
            if (iceC) {
                pause.image3.setImage(new Image("check.jpg"));
            }
            if (task.getCurrentTurkeys() >= task.TURKEYS) {
                pause.image4.setImage(new Image("check.jpg"));
            }
            if (task.getCurrentBuffaloes() >= task.BUFFALOES) {
                pause.image5.setImage(new Image("check.jpg"));
            }
            if (level.coins >= task.COINS) {
                pause.image6.setImage(new Image("check.jpg"));
            }
        }
    }
    ///////////////////////////////////////////////////////////////////////////

    public static void checkTask () throws IOException {
        if (Controller.checkTask(level)) {
            //MyTime.getInstance().exited = true;
            Log.logCompile("tasks of this Level finished.","info");
            Controller.getInstance().levelAlter[level].timeFinished = (int) MyTime.getInstance().getTime();
            try {
                FinishLevel.time = MyTime.getInstance().getTime();
                long totalPrize = Controller.getInstance().ResetLevel();
                FinishLevel.prize = totalPrize;
                Log.logCompile("The Rest of the level is done","info");
                shopStage = new Stage();
                shopStage.initModality(Modality.APPLICATION_MODAL);
                Parent root = FXMLLoader.load(Objects.requireNonNull(GameMenu.class.getResource("finishLevel.fxml")));
                Scene scene = new Scene(root);
                //shopStage.setOnCloseRequest(e -> { });
                shopStage.setScene(scene);
                shopStage.showAndWait();
            } catch (CloneNotSupportedException e) {
                e.printStackTrace();
            }
        }
    }






    public  void moveDomestic (Domestic domestic , int row , int col ,  int i) {
        System.out.println("---------------------------------------");
        System.out.println("moveDomestic method called...");
        System.out.println(domestics.size());
        System.out.println(farm.getChildren().size());
        System.out.println("---------------------------------------");
        if (!domestic.isHungry) {
            TranslateTransition transition = new TranslateTransition();
            transition.setDuration(Duration.millis(1400));
            transition.setInterpolator(Interpolator.LINEAR);

            //ImageView imageView = domestics.get(i);
            ImageView imageView = new ImageView();
            System.out.println(imageView.getLayoutX()+"     "+imageView.getLayoutY());
            /*double[] before = new double[2];
            before[0] = domestics.get(i).getLayoutX();
            before[1] = domestics.get(i).getLayoutY();*/
            double [] before = convertTo(row,col);
            double[] after = convertTo(domestic.row, domestic.col);
            //imageView.setLayoutX(before[0]);
            //imageView.setLayoutY(before[1]);

            if (domestic.type.equals("chicken")) {
                Animation animation;
                switch (domestic.side) {
                    case "down":
                        imageView.setImage(MyImage.chicken_down);
                        imageView.setViewport(new Rectangle2D(0, 0, MyImage.width_chicken_down, MyImage.height_chicken_down));
                        animation = new SpriteAnimation(imageView, Duration.millis(1000), MyImage.countChicken, MyImage.columnChicken, 0, 0, MyImage.width_chicken_down, MyImage.height_chicken_down);
                        animation.setCycleCount(Animation.INDEFINITE);
                        animation.play();
                        transition.setNode(imageView);
                        transition.setOnFinished(e -> {
                            animation.stop();
                        });
                        break;
                    case "up":
                        imageView.setImage(MyImage.chicken_up);
                        imageView.setViewport(new Rectangle2D(0, 0, MyImage.width_chicken_up, MyImage.height_chicken_up));
                        animation = new SpriteAnimation(imageView, Duration.millis(1000), MyImage.countChicken, MyImage.columnChicken, 0, 0, MyImage.width_chicken_up, MyImage.height_chicken_up);
                        animation.setCycleCount(Animation.INDEFINITE);
                        animation.play();
                        transition.setNode(imageView);
                        transition.setOnFinished(e -> {
                            animation.stop();
                        });
                        break;
                    case "left":
                        imageView.setImage(MyImage.chicken_left);
                        imageView.setViewport(new Rectangle2D(0, 0, MyImage.width_chicken_left, MyImage.height_chicken_left));
                        animation = new SpriteAnimation(imageView, Duration.millis(1000), MyImage.countChicken, MyImage.columnChicken, 0, 0, MyImage.width_chicken_left, MyImage.height_chicken_left);
                        animation.setCycleCount(Animation.INDEFINITE);
                        animation.play();
                        transition.setNode(imageView);
                        transition.setOnFinished(e -> {
                            animation.stop();
                        });
                        break;
                    case "right":
                        imageView.setImage(MyImage.chicken_right);
                        imageView.setViewport(new Rectangle2D(0, 0, MyImage.width_chicken_right, MyImage.height_chicken_right));
                        animation = new SpriteAnimation(imageView, Duration.millis(1000), MyImage.countChicken, MyImage.columnChicken, 0, 0, MyImage.width_chicken_right, MyImage.height_chicken_right);
                        animation.setCycleCount(Animation.INDEFINITE);
                        animation.play();
                        transition.setNode(imageView);
                        transition.setOnFinished(e -> {
                            animation.stop();
                        });
                        break;
                }
                farm.getChildren().add(imageView);
                transition.setFromX(before[0]);
                transition.setFromY(before[1]);
                transition.setToX(after[0]);
                transition.setToY(after[1]);
                transition.play();

            } else if (domestic.type.equals("turkey")) {
                Animation animation;
                switch (domestic.side) {
                    case "down":
                        imageView.setImage(MyImage.turkey_down);
                        imageView.setViewport(new Rectangle2D(0, 0, MyImage.width_turkey_down, MyImage.height_turkey_down));
                        animation = new SpriteAnimation(imageView, Duration.millis(1000), MyImage.countTurkey, MyImage.columnTurkey_down, 0, 0, MyImage.width_turkey_down, MyImage.height_turkey_down);
                        animation.setCycleCount(Animation.INDEFINITE);
                        animation.play();
                        transition.setNode(imageView);
                        transition.setOnFinished(e -> animation.stop());
                        break;
                    case "up":
                        imageView.setImage(MyImage.turkey_up);
                        imageView.setViewport(new Rectangle2D(0, 0, MyImage.width_turkey_up, MyImage.height_turkey_up));
                        animation = new SpriteAnimation(imageView, Duration.millis(1000), MyImage.countTurkey, MyImage.columnTurkey_up_left_right, 0, 0, MyImage.width_turkey_up, MyImage.height_turkey_up);
                        animation.setCycleCount(Animation.INDEFINITE);
                        animation.play();
                        transition.setNode(imageView);
                        transition.setOnFinished(e -> animation.stop());
                        break;
                    case "left":
                        imageView.setImage(MyImage.turkey_left);
                        imageView.setViewport(new Rectangle2D(0, 0, MyImage.width_turkey_left, MyImage.height_turkey_left));
                        animation = new SpriteAnimation(imageView, Duration.millis(1000), MyImage.countTurkey, MyImage.columnTurkey_up_left_right, 0, 0, MyImage.width_turkey_left, MyImage.height_turkey_left);
                        animation.setCycleCount(Animation.INDEFINITE);
                        animation.play();
                        transition.setNode(imageView);
                        transition.setOnFinished(e -> animation.stop());
                        break;
                    case "right":
                        imageView.setImage(MyImage.turkey_right);
                        imageView.setViewport(new Rectangle2D(0, 0, MyImage.width_turkey_right, MyImage.height_turkey_right));
                        animation = new SpriteAnimation(imageView, Duration.millis(1000), MyImage.countTurkey, MyImage.columnTurkey_up_left_right, 0, 0, MyImage.width_turkey_right, MyImage.height_turkey_right);
                        animation.setCycleCount(Animation.INDEFINITE);
                        animation.play();
                        transition.setNode(imageView);
                        transition.setOnFinished(e -> animation.stop());
                        break;
                }
                farm.getChildren().add(imageView);
                transition.setFromX(before[0]);
                transition.setFromY(before[1]);
                transition.setToX(after[0]);
                transition.setToY(after[1]);
                transition.play();

            } else if (domestic.type.equals("buffalo")) {
                Animation animation;
                switch (domestic.side) {
                    case "down":
                        imageView.setImage(MyImage.buffalo_down);
                        imageView.setViewport(new Rectangle2D(0, 0, MyImage.width_buffalo_down, MyImage.height_buffalo_down));
                        animation = new SpriteAnimation(imageView, Duration.millis(1000), MyImage.countBuffalo, MyImage.columnBuffalo_down_up, 0, 0, MyImage.width_buffalo_down, MyImage.height_buffalo_down);
                        animation.setCycleCount(Animation.INDEFINITE);
                        animation.play();
                        transition.setNode(imageView);
                        transition.setOnFinished(e -> animation.stop());
                        break;
                    case "up":
                        imageView.setImage(MyImage.buffalo_up);
                        imageView.setViewport(new Rectangle2D(0, 0, MyImage.width_buffalo_up, MyImage.height_buffalo_up));
                        animation = new SpriteAnimation(imageView, Duration.millis(1000), MyImage.countBuffalo, MyImage.columnBuffalo_down_up, 0, 0, MyImage.width_buffalo_up, MyImage.height_buffalo_up);
                        animation.setCycleCount(Animation.INDEFINITE);
                        animation.play();
                        transition.setNode(imageView);
                        transition.setOnFinished(e -> animation.stop());
                        break;
                    case "left":
                        imageView.setImage(MyImage.buffalo_left);
                        imageView.setViewport(new Rectangle2D(0, 0, MyImage.width_buffalo_left, MyImage.height_buffalo_left));
                        animation = new SpriteAnimation(imageView, Duration.millis(1000), MyImage.countBuffalo, MyImage.columnBuffalo_left_right, 0, 0, MyImage.width_buffalo_left, MyImage.height_buffalo_left);
                        animation.setCycleCount(Animation.INDEFINITE);
                        animation.play();
                        transition.setNode(imageView);
                        transition.setOnFinished(e -> animation.stop());
                        break;
                    case "right":
                        imageView.setImage(MyImage.buffalo_right);
                        imageView.setViewport(new Rectangle2D(0, 0, MyImage.width_buffalo_right, MyImage.height_buffalo_right));
                        animation = new SpriteAnimation(imageView, Duration.millis(1000), MyImage.countBuffalo, MyImage.columnBuffalo_left_right, 0, 0, MyImage.width_buffalo_right, MyImage.height_buffalo_right);
                        animation.setCycleCount(Animation.INDEFINITE);
                        animation.play();
                        transition.setNode(imageView);
                        transition.setOnFinished(e -> animation.stop());
                        break;
                }
                farm.getChildren().add(imageView);
                transition.setFromX(before[0]);
                transition.setFromY(before[1]);
                transition.setToX(after[0]);
                transition.setToY(after[1]);
                transition.play();
            }
        }
        else {
            //ImageView imageView = domestics.get(i);
            ImageView imageView = new ImageView();
            double [] coordinate = convertTo(row,col);
            /*coordinate[0] = imageView.getLayoutX();
            coordinate[1] = imageView.getLayoutY();*/
            if (domestic.type.equals("chicken")){
                imageView.setImage(MyImage.chicken_eat);
                imageView.setLayoutX(coordinate[0]);
                imageView.setLayoutY(coordinate[1]);
                Animation animation = new SpriteAnimation(imageView,Duration.millis(900),MyImage.chicken_eat_count,MyImage.chicken_eat_column,0,0,MyImage.chicken_eat_width,MyImage.chicken_eat_height);
                animation.setCycleCount(Animation.INDEFINITE);
                farm.getChildren().add(imageView);
                animation.play();
            } else if (domestic.type.equals("turkey")){
                imageView.setImage(MyImage.turkey_eat);
                imageView.setLayoutX(coordinate[0]);
                imageView.setLayoutY(coordinate[1]);
                Animation animation = new SpriteAnimation(imageView,Duration.millis(900),MyImage.turkey_eat_count,MyImage.turkey_eat_column,0,0,MyImage.turkey_eat_width,MyImage.turkey_eat_height);
                animation.setCycleCount(Animation.INDEFINITE);
                farm.getChildren().add(imageView);
                animation.play();
            } else if (domestic.type.equals("buffalo")){
                imageView.setImage(MyImage.buffalo_eat);
                imageView.setLayoutX(coordinate[0]);
                imageView.setLayoutY(coordinate[1]);
                Animation animation = new SpriteAnimation(imageView,Duration.millis(900),MyImage.buffalo_eat_count,MyImage.buffalo_eat_column,0,0,MyImage.buffalo_eat_width,MyImage.buffalo_eat_height);
                animation.setCycleCount(Animation.INDEFINITE);
                farm.getChildren().add(imageView);
                animation.play();
            }
        }
    }

    public  void moveDog (Dog dogInstance , int beforeRow , int beforeCol) {
        TranslateTransition transition = new TranslateTransition();
        transition.setDuration(Duration.millis(1200));
        transition.setInterpolator(Interpolator.LINEAR);

        double [] before = GameMenu.convertTo(beforeRow,beforeCol);
        double [] after =  GameMenu.convertTo(dogInstance.row , dogInstance.col);
        ImageView imageView = new ImageView();
        Animation animation;
        switch (dogInstance.side) {
            case "down":
                imageView.setImage(MyImage.dog_down);
                imageView.setViewport(new Rectangle2D(0,0,MyImage.width_dog_down,MyImage.height_dog_down));
                animation = new SpriteAnimation(imageView,Duration.millis(800),MyImage.countDog,MyImage.columnDog,0,0,MyImage.width_dog_down,MyImage.height_dog_down);
                animation.setCycleCount(Animation.INDEFINITE);
                animation.play();
                transition.setNode(imageView);
                transition.setOnFinished(e -> {
                    animation.stop();
                });
                break;
            case "up":
                imageView.setImage(MyImage.dog_up);
                imageView.setViewport(new Rectangle2D(0,0,MyImage.width_dog_up,MyImage.height_dog_up));
                animation = new SpriteAnimation(imageView,Duration.millis(800),MyImage.countDog,MyImage.columnDog,0,0,MyImage.width_dog_up,MyImage.height_dog_up);
                animation.setCycleCount(Animation.INDEFINITE);
                animation.play();
                transition.setNode(imageView);
                transition.setOnFinished(e -> {
                    animation.stop();
                });
                break;
            case "left":
                imageView.setImage(MyImage.dog_left);
                imageView.setViewport(new Rectangle2D(0,0,MyImage.width_dog_left,MyImage.height_dog_left));
                animation = new SpriteAnimation(imageView,Duration.millis(800),MyImage.countDog,MyImage.columnDog,0,0,MyImage.width_dog_left,MyImage.height_dog_left);
                animation.setCycleCount(Animation.INDEFINITE);
                animation.play();
                transition.setNode(imageView);
                transition.setOnFinished(e -> {
                    animation.stop();
                });
                break;
            case "right":
                imageView.setImage(MyImage.dog_right);
                imageView.setViewport(new Rectangle2D(0,0,MyImage.width_dog_right,MyImage.height_dog_right));
                animation = new SpriteAnimation(imageView,Duration.millis(800),MyImage.countDog,MyImage.columnDog,0,0,MyImage.width_dog_right,MyImage.height_dog_right);
                animation.setCycleCount(Animation.INDEFINITE);
                animation.play();
                transition.setNode(imageView);
                transition.setOnFinished(e -> {
                    animation.stop();
                });
                break;
        }
        farm.getChildren().add(imageView);
        transition.setFromX(before[0]);
        transition.setFromY(before[1]);
        transition.setToX(after[0]);
        transition.setToY(after[1]);
        transition.play();

    }

    public  void moveCat (Cat catInstance , int beforeRow , int beforeCol){
        TranslateTransition transition = new TranslateTransition();
        transition.setDuration(Duration.millis(1200));
        transition.setInterpolator(Interpolator.LINEAR);

        double [] before = GameMenu.convertTo(beforeRow,beforeCol);
        double [] after =  GameMenu.convertTo(catInstance.row , catInstance.col);
        ImageView imageView = new ImageView();
        Animation animation;
        switch (catInstance.side) {
            case "down":
                imageView.setImage(MyImage.cat_down);
                imageView.setViewport(new Rectangle2D(0,0,MyImage.width_cat_down,MyImage.height_cat_down));
                animation = new SpriteAnimation(imageView,Duration.millis(800),MyImage.countCat,MyImage.columnCat,0,0,MyImage.width_cat_down,MyImage.height_cat_down);
                animation.setCycleCount(Animation.INDEFINITE);
                animation.play();
                transition.setNode(imageView);
                transition.setOnFinished(e -> {
                    animation.stop();
                });
                break;
            case "up":
                imageView.setImage(MyImage.cat_up);
                imageView.setViewport(new Rectangle2D(0,0,MyImage.width_cat_up,MyImage.height_cat_up));
                animation = new SpriteAnimation(imageView,Duration.millis(800),MyImage.countCat,MyImage.columnCat,0,0,MyImage.width_cat_up,MyImage.height_cat_up);
                animation.setCycleCount(Animation.INDEFINITE);
                animation.play();
                transition.setNode(imageView);
                transition.setOnFinished(e -> {
                    animation.stop();
                });
                break;
            case "left":
                imageView.setImage(MyImage.cat_left);
                imageView.setViewport(new Rectangle2D(0,0,MyImage.width_cat_left,MyImage.height_cat_left));
                animation = new SpriteAnimation(imageView,Duration.millis(800),MyImage.countCat,MyImage.columnCat,0,0,MyImage.width_cat_left,MyImage.height_cat_left);
                animation.setCycleCount(Animation.INDEFINITE);
                animation.play();
                transition.setNode(imageView);
                transition.setOnFinished(e -> {
                    animation.stop();
                });
                break;
            case "right":
                imageView.setImage(MyImage.cat_right);
                imageView.setViewport(new Rectangle2D(0,0,MyImage.width_cat_right,MyImage.height_cat_right));
                animation = new SpriteAnimation(imageView,Duration.millis(800),MyImage.countCat,MyImage.columnCat,0,0,MyImage.width_cat_right,MyImage.height_cat_right);
                animation.setCycleCount(Animation.INDEFINITE);
                animation.play();
                transition.setNode(imageView);
                transition.setOnFinished(e -> {
                    animation.stop();
                });
                break;
        }
        farm.getChildren().add(imageView);
        transition.setFromX(before[0]);
        transition.setFromY(before[1]);
        transition.setToX(after[0]);
        transition.setToY(after[1]);
        transition.play();

    }

    public  void moveWild (Wild wild , int row , int col ,int i){
        TranslateTransition transition = new TranslateTransition();
        transition.setDuration(Duration.millis(1100));
        transition.setInterpolator(Interpolator.LINEAR);

        ImageView imageView = new ImageView();
        double [] before = convertTo(row,col);
        double [] after =  GameMenu.convertTo(wild.row , wild.col);
        if (wild.type.equals("lion")) {
                Animation animation;
                switch (wild.side) {
                    case "down":
                        imageView.setImage(MyImage.lion_down);
                        imageView.setViewport(new Rectangle2D(0, 0, MyImage.width_lion_down, MyImage.height_lion_down));
                        animation = new SpriteAnimation(imageView, Duration.millis(1000), MyImage.countLion, MyImage.columnLion_up_down, 0, 0, MyImage.width_lion_down, MyImage.height_lion_down);
                        //animation.setCycleCount(MyTime.timeUnit*1000/(MyImage.countLion*600));
                        animation.setCycleCount(Animation.INDEFINITE);
                        animation.play();
                        transition.setNode(imageView);
                        transition.setOnFinished(e -> {
                            animation.stop();
                            if (wild.cages > 0) {
                                ImageView cage = new ImageView();
                                cage.setLayoutX(after[0]-20);
                                cage.setLayoutY(after[1]-60);
                                if (wild.cages == 1) {
                                    cage.setImage(MyImage.cage1);
                                } else if (wild.cages == 2) {
                                    cage.setImage(MyImage.cage5);
                                } else if (wild.cages == 3) {
                                    cage.setImage(MyImage.cage7);
                                }
                                farm.getChildren().add(cage);
                            }

                        });
                        break;
                    case "up":
                        imageView.setImage(MyImage.lion_up);
                        imageView.setViewport(new Rectangle2D(0, 0, MyImage.width_lion_up, MyImage.height_lion_up));
                        animation = new SpriteAnimation(imageView, Duration.millis(1000), 24, 6, 0, 0, MyImage.width_lion_up, MyImage.height_lion_up);
                        //animation.setCycleCount(MyTime.timeUnit*1000/(MyImage.countLion*600));
                        animation.setCycleCount(Animation.INDEFINITE);
                        animation.play();
                        transition.setNode(imageView);
                        transition.setOnFinished(e -> {
                            animation.stop();
                            if (wild.cages > 0) {
                                ImageView cage = new ImageView();
                                if (wild.cages == 1) {
                                    cage.setImage(MyImage.cage1);
                                } else if (wild.cages == 2) {
                                    cage.setImage(MyImage.cage5);
                                } else if (wild.cages == 3) {
                                    cage.setImage(MyImage.cage7);
                                }
                                cage.setLayoutX(after[0]-20);
                                cage.setLayoutY(after[1]-60);
                                farm.getChildren().add(cage);
                            }
                        });
                        break;
                    case "left":
                        imageView.setImage(MyImage.lion_left);
                        imageView.setViewport(new Rectangle2D(0, 0, MyImage.width_lion_left, MyImage.height_lion_left));
                        animation = new SpriteAnimation(imageView, Duration.millis(1000), MyImage.countLion, MyImage.columnLion_left_right, 0, 0, MyImage.width_lion_left, MyImage.height_lion_left);
                        //animation.setCycleCount(MyTime.timeUnit*1000/(MyImage.countLion*600));
                        animation.setCycleCount(Animation.INDEFINITE);
                        animation.play();
                        transition.setNode(imageView);
                        transition.setOnFinished(e -> {
                            animation.stop();
                            if (wild.cages > 0) {
                                ImageView cage = new ImageView();
                                cage.setLayoutX(after[0]-25);
                                cage.setLayoutY(after[1]-60);
                                if (wild.cages == 1) {
                                    cage.setImage(MyImage.cage1);
                                } else if (wild.cages == 2) {
                                    cage.setImage(MyImage.cage5);
                                } else if (wild.cages == 3) {
                                    cage.setImage(MyImage.cage7);
                                }
                                farm.getChildren().add(cage);
                            }
                        });
                        break;
                    case "right":
                        imageView.setImage(MyImage.lion_right);
                        imageView.setViewport(new Rectangle2D(0, 0, MyImage.width_lion_right, MyImage.height_lion_right));
                        animation = new SpriteAnimation(imageView, Duration.millis(1000), MyImage.countLion, MyImage.columnLion_left_right, 0, 0, MyImage.width_lion_right, MyImage.height_lion_right);
                        //animation.setCycleCount(MyTime.timeUnit*1000/(MyImage.countLion*600));
                        animation.setCycleCount(Animation.INDEFINITE);
                        animation.play();
                        transition.setNode(imageView);
                        transition.setOnFinished(e -> {
                            animation.stop();
                            if (wild.cages > 0) {
                                ImageView cage = new ImageView();
                                cage.setLayoutX(after[0]-20);
                                cage.setLayoutY(after[1]-60);
                                if (wild.cages == 1) {
                                    cage.setImage(MyImage.cage1);
                                } else if (wild.cages == 2) {
                                    cage.setImage(MyImage.cage5);
                                } else if (wild.cages == 3) {
                                    cage.setImage(MyImage.cage7);
                                }
                                farm.getChildren().add(cage);
                            }
                        });
                        break;
                }
                farm.getChildren().add(imageView);
                transition.setFromX(before[0]);
                transition.setFromY(before[1]);
                transition.setToX(after[0]);
                transition.setToY(after[1]);
                transition.play();


        } else if (wild.type.equals("bear")) {
            Animation animation;
            switch (wild.side) {
                case "down":
                    imageView.setImage(MyImage.bear_down);
                    imageView.setViewport(new Rectangle2D(0,0,MyImage.width_bear_down,MyImage.height_bear_down));
                    animation = new SpriteAnimation(imageView,Duration.millis(800),MyImage.countBear,MyImage.columnBear,0,0,MyImage.width_bear_down,MyImage.height_bear_down);
                    animation.setCycleCount(Animation.INDEFINITE);
                    animation.play();
                    transition.setNode(imageView);
                    transition.setOnFinished(e -> {
                        animation.stop();
                        if (wild.cages > 0) {
                            ImageView cage = new ImageView();
                            cage.setLayoutX(after[0]-20);
                            cage.setLayoutY(after[1]-60);
                            if (wild.cages == 1) {
                                cage.setImage(MyImage.cage1);
                            } else if (wild.cages == 2) {
                                cage.setImage(MyImage.cage3);
                            } else if (wild.cages == 3) {
                                cage.setImage(MyImage.cage5);
                            } else if (wild.cages==4){
                                cage.setImage(MyImage.cage7);
                            }
                            farm.getChildren().add(cage);
                        }
                    });
                    break;
                case "up":
                    imageView.setImage(MyImage.bear_up);
                    imageView.setViewport(new Rectangle2D(0,0,MyImage.width_bear_up,MyImage.height_bear_up));
                    animation = new SpriteAnimation(imageView,Duration.millis(800),MyImage.countBear,MyImage.columnBear,0,0,MyImage.width_bear_up,MyImage.height_bear_up);
                    animation.setCycleCount(Animation.INDEFINITE);
                    animation.play();
                    transition.setNode(imageView);
                    transition.setOnFinished(e -> {
                        animation.stop();
                        if (wild.cages > 0) {
                            ImageView cage = new ImageView();
                            cage.setLayoutX(after[0]-20);
                            cage.setLayoutY(after[1]-60);
                            if (wild.cages == 1) {
                                cage.setImage(MyImage.cage1);
                            } else if (wild.cages == 2) {
                                cage.setImage(MyImage.cage3);
                            } else if (wild.cages == 3) {
                                cage.setImage(MyImage.cage5);
                            } else if (wild.cages==4){
                                cage.setImage(MyImage.cage7);
                            }
                            farm.getChildren().add(cage);
                        }
                    });
                    break;
                case "left":
                    imageView.setImage(MyImage.bear_left);
                    imageView.setViewport(new Rectangle2D(0,0,MyImage.width_bear_left,MyImage.height_bear_left));
                    animation = new SpriteAnimation(imageView,Duration.millis(800),MyImage.countBear,MyImage.columnBear,0,0,MyImage.width_bear_left,MyImage.height_bear_left);
                    animation.setCycleCount(Animation.INDEFINITE);
                    animation.play();
                    transition.setNode(imageView);
                    transition.setOnFinished(e -> {
                        animation.stop();
                        if (wild.cages > 0) {
                            ImageView cage = new ImageView();
                            cage.setLayoutX(after[0]-20);
                            cage.setLayoutY(after[1]-60);
                            if (wild.cages == 1) {
                                cage.setImage(MyImage.cage1);
                            } else if (wild.cages == 2) {
                                cage.setImage(MyImage.cage3);
                            } else if (wild.cages == 3) {
                                cage.setImage(MyImage.cage5);
                            } else if (wild.cages==4){
                                cage.setImage(MyImage.cage7);
                            }
                            farm.getChildren().add(cage);
                        }
                    });
                    break;
                case "right":
                    imageView.setImage(MyImage.bear_right);
                    imageView.setViewport(new Rectangle2D(0,0,MyImage.width_bear_right,MyImage.height_bear_right));
                    animation = new SpriteAnimation(imageView,Duration.millis(800),MyImage.countBear,MyImage.columnBear,0,0,MyImage.width_bear_right,MyImage.height_bear_right);
                    animation.setCycleCount(Animation.INDEFINITE);
                    animation.play();
                    transition.setNode(imageView);
                    transition.setOnFinished(e -> {
                        animation.stop();
                        if (wild.cages > 0) {
                            ImageView cage = new ImageView();
                            cage.setLayoutX(after[0]-20);
                            cage.setLayoutY(after[1]-60);
                            if (wild.cages == 1) {
                                cage.setImage(MyImage.cage1);
                            } else if (wild.cages == 2) {
                                cage.setImage(MyImage.cage3);
                            } else if (wild.cages == 3) {
                                cage.setImage(MyImage.cage5);
                            } else if (wild.cages==4){
                                cage.setImage(MyImage.cage7);
                            }
                            farm.getChildren().add(cage);
                        }
                    });
                    break;
            }
            farm.getChildren().add(imageView);
            transition.setFromX(before[0]);
            transition.setFromY(before[1]);
            transition.setToX(after[0]);
            transition.setToY(after[1]);
            transition.play();

        } else if (wild.type.equals("tiger")) {
            Animation animation;
            switch (wild.side) {
                case "down":
                    imageView.setImage(MyImage.tiger_down);
                    imageView.setViewport(new Rectangle2D(0,0,MyImage.width_tiger_down,MyImage.height_tiger_down));
                    animation = new SpriteAnimation(imageView,Duration.millis(500),MyImage.countTiger,MyImage.columnTiger,0,0,MyImage.width_tiger_down,MyImage.height_tiger_down);
                    animation.setCycleCount(Animation.INDEFINITE);
                    animation.play();
                    transition.setNode(imageView);
                    transition.setOnFinished(e -> {
                        animation.stop();
                        if (wild.cages > 0) {
                            ImageView cage = new ImageView();
                            cage.setLayoutX(after[0]-20);
                            cage.setLayoutY(after[1]-60);
                            if (wild.cages == 1) {
                                cage.setImage(MyImage.cage1);
                            } else if (wild.cages == 2) {
                                cage.setImage(MyImage.cage3);
                            } else if (wild.cages == 3) {
                                cage.setImage(MyImage.cage5);
                            } else if (wild.cages==4){
                                cage.setImage(MyImage.cage7);
                            }
                            farm.getChildren().add(cage);
                        }
                    });
                    break;
                case "up":
                    imageView.setImage(MyImage.tiger_up);
                    imageView.setViewport(new Rectangle2D(0,0,MyImage.width_tiger_up,MyImage.height_tiger_up));
                    animation = new SpriteAnimation(imageView,Duration.millis(500),MyImage.countTiger,MyImage.columnTiger,0,0,MyImage.width_tiger_up,MyImage.height_tiger_up);
                    animation.setCycleCount(Animation.INDEFINITE);
                    animation.play();
                    transition.setNode(imageView);
                    transition.setOnFinished(e -> {
                        animation.stop();
                        if (wild.cages > 0) {
                            ImageView cage = new ImageView();
                            cage.setLayoutX(after[0]-20);
                            cage.setLayoutY(after[1]-60);
                            if (wild.cages == 1) {
                                cage.setImage(MyImage.cage1);
                            } else if (wild.cages == 2) {
                                cage.setImage(MyImage.cage3);
                            } else if (wild.cages == 3) {
                                cage.setImage(MyImage.cage5);
                            } else if (wild.cages==4){
                                cage.setImage(MyImage.cage7);
                            }
                            farm.getChildren().add(cage);
                        }
                    });
                    break;
                case "left":
                    imageView.setImage(MyImage.tiger_left);
                    imageView.setViewport(new Rectangle2D(0,0,MyImage.width_tiger_left,MyImage.height_tiger_left));
                    animation = new SpriteAnimation(imageView,Duration.millis(500),MyImage.countTiger,MyImage.columnTiger,0,0,MyImage.width_tiger_left,MyImage.height_tiger_left);
                    animation.setCycleCount(Animation.INDEFINITE);
                    animation.play();
                    transition.setNode(imageView);
                    transition.setOnFinished(e -> {
                        animation.stop();
                        if (wild.cages > 0) {
                            ImageView cage = new ImageView();
                            cage.setLayoutX(after[0]-20);
                            cage.setLayoutY(after[1]-60);
                            if (wild.cages == 1) {
                                cage.setImage(MyImage.cage1);
                            } else if (wild.cages == 2) {
                                cage.setImage(MyImage.cage3);
                            } else if (wild.cages == 3) {
                                cage.setImage(MyImage.cage5);
                            } else if (wild.cages==4){
                                cage.setImage(MyImage.cage7);
                            }
                            farm.getChildren().add(cage);
                        }
                    });
                    break;
                case "right":
                    imageView.setImage(MyImage.tiger_right);
                    imageView.setViewport(new Rectangle2D(0,0,MyImage.width_tiger_right,MyImage.height_tiger_right));
                    animation = new SpriteAnimation(imageView,Duration.millis(500),MyImage.countTiger,MyImage.columnTiger,0,0,MyImage.width_tiger_right,MyImage.height_tiger_right);
                    animation.setCycleCount(Animation.INDEFINITE);
                    animation.play();
                    transition.setNode(imageView);
                    transition.setOnFinished(e -> {
                        animation.stop();
                        if (wild.cages > 0) {
                            ImageView cage = new ImageView();
                            cage.setLayoutX(after[0]-20);
                            cage.setLayoutY(after[1]-60);
                            if (wild.cages == 1) {
                                cage.setImage(MyImage.cage1);
                            } else if (wild.cages == 2) {
                                cage.setImage(MyImage.cage3);
                            } else if (wild.cages == 3) {
                                cage.setImage(MyImage.cage5);
                            } else if (wild.cages==4){
                                cage.setImage(MyImage.cage7);
                            }
                            farm.getChildren().add(cage);
                        }
                    });
                    break;
            }
            farm.getChildren().add(imageView);
            transition.setFromX(before[0]);
            transition.setFromY(before[1]);
            transition.setToX(after[0]);
            transition.setToY(after[1]);
            transition.play();


        }
    }


    public static int [] convertTo (double x , double y ){
        System.out.println(x+" , "+y);
        int row = 0;
        int col =0;
        if (x>=0 && x<=150){
            col =1;
        } else if (x>150 && x<=300){
            col =2;
        } else if (x>300 && x<=450){
            col =3 ;
        } else if (x> 450 && x<=600){
            col=4;
        } else if (x>600 && x<=750){
            col =5;
        } else if (x>750 && x<=900){
            col = 6;
        }
        if (y>0 && y<=380.0/6){
            row =1;
        } else if (y>380.0/6 && y<=380.0/3){
            row = 2;
        }  else if (y>380.0/3 && y<=190.0){
            row = 3;
        } else if (y>190.0 && y<=760.0/3){
            row = 4;
        } else if (y > 760.0/3 && y <= 1900.0/6) {
            row=5;
        } else if (y>1900.0/6 && y<=380.0){
            row = 6;
        }
        int [] coordinate = new int[2];
        coordinate[0] = row;
        coordinate[1] =  col;
        return coordinate;
    }


    public static double[] convertTo (int row , int col){
        double [] coordinate = new double[2];
        coordinate[0] = 150 * (col-1);
        coordinate[1] = (380.0/6) * (row-1);
        System.out.println("In convert to coordinate method : ");
        System.out.println(row+" , "+col);
        System.out.println(coordinate[0]+" , "+coordinate[1]);
        return coordinate;
    }

    public AnchorPane getFarm (){
        return farm;
    }

    public void setObject (){
        System.out.println("---------------------------------------");
        System.out.println("setObject method called...");
        System.out.println(farm.getChildren().size());
        farm.getChildren().clear();
        farm.getChildren().addAll(domestics);
        farm.getChildren().addAll(wilds);
        farm.getChildren().addAll(cats);
        farm.getChildren().addAll(dogs);
        farm.getChildren().addAll(products);
        farm.getChildren().addAll(grasses);
        System.out.println(farm.getChildren().size());
        System.out.println("---------------------------------------");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        Log.logCompile("User is in Game Menu","info");
        //Map.domestics.add(new Chicken());
        //setObject();
        //farm.getChildren().addAll(Shop.images);
        coin.setText(Long.toString(Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].coins));
        time.setText(Long.toString(MyTime.getInstance().time));
        boolean finishedLevel=false;
        MyTime.getInstance().exited=false;
        //System.out.println("Thread start...");
        //MyTime.getInstance().execute();


    }
}
