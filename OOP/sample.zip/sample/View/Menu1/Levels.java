package sample.View.Menu1;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import sample.Controller.Controller;
import sample.Main;

import java.io.IOException;

public class Levels {


    public ImageView image3;
    public ImageView image2;
    public ImageView image4;
    public ImageView image5;
    public Button level1;
    public Button level2;
    public Button level3;
    public Button level4;
    public Button level5;

    public void chooseLevel(ActionEvent actionEvent) throws IOException {

        if (actionEvent.getSource() == level1) {
            Login1.levelW = 1;
            Controller.getInstance().currentLevel=0;
            GameMenu.level=0;
            setPrizes(1);
            System.out.println(1);
        }
        if (actionEvent.getSource() == level2) {
            Login1.levelW = 2;
            Controller.getInstance().currentLevel= 1;
            GameMenu.level=1;
            setPrizes(2);
            System.out.println(2);
        }
        if (actionEvent.getSource() == level3) {
            Login1.levelW = 3;
            Controller.getInstance().currentLevel= 2;
            GameMenu.level=2;
            setPrizes(3);
            System.out.println(3);
        }
        if (actionEvent.getSource() == level4) {
            Login1.levelW = 4;
            Controller.getInstance().currentLevel= 3;
            GameMenu.level=3;
            setPrizes(4);
            System.out.println(4);
        }
        if (actionEvent.getSource() == level5) {
            Login1.levelW = 5;
            Controller.getInstance().currentLevel=4;
            GameMenu.level=4;
            setPrizes(5);
            System.out.println(5);
        }
        Controller.getInstance().levelAlter[Controller.getInstance().currentLevel].coins = Controller.getInstance().level[Controller.getInstance().currentLevel].coins;
    }

    public static void setPrizes(int level) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("View/Menu1/prize.fxml"));
        Parent root = loader.load();
        Main.window.getScene().setRoot(root);
        Prize prize = loader.getController();
        GameMenu.eggC = false;
        GameMenu.featherC = false;
        GameMenu.milkC = false;
        GameMenu.flourC = false;
        GameMenu.clothC = false;
        GameMenu.packC = false;
        GameMenu.breadC = false;
        GameMenu.shirtC = false;
        GameMenu.iceC = false;
        if (level == 1) {
            prize.level.setText("Level 1!");
            prize.label1.setText("40 time unit:      400 coins!");
            prize.label2.setText("45 time unit:      200 coins!");
            prize.label3.setText("50 time unit:      100 coins!");
        }
        if (level == 2) {
            prize.level.setText("Level 2!");
            prize.label1.setText("50 time unit:      400 coins!");
            prize.label2.setText("55 time unit:      200 coins!");
            prize.label3.setText("60 time unit:      100 coins!");
        }
        if (level == 3) {
            prize.level.setText("Level 3!");
            prize.label1.setText("60 time unit:      400 coins!");
            prize.label2.setText("65 time unit:      200 coins!");
            prize.label3.setText("70 time unit:      100 coins!");
        }
        if (level == 4) {
            prize.level.setText("Level 4!");
            prize.label1.setText("70 time unit:      400 coins!");
            prize.label2.setText("75 time unit:      200 coins!");
            prize.label3.setText("80 time unit:      100 coins!");
        }
        if (level == 5) {
            prize.level.setText("Level 5!");
            prize.label1.setText("80 time unit:      400 coins!");
            prize.label2.setText("85 time unit:      200 coins!");
            prize.label3.setText("90 time unit:      100 coins!");
        }
        Main.window.getScene().setRoot(root);
    }

    public void back() throws IOException {
        Controller.getInstance().saveGame();
        Controller.saveUsers();
        try {
            Controller.getInstance().ResetLevel();

        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        Main.changeScene("View/Menu1/firstMenu.fxml");
    }
}
