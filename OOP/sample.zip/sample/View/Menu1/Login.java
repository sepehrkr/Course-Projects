package sample.View.Menu1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import sample.Controller.Controller;
import sample.Controller.Log;
import sample.Main;
import sample.Model.Person;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Login implements Initializable {

    Person person ;

    @FXML
     private TextField usename;

    @FXML
    private  TextField password;

    @FXML
    void login(ActionEvent event) throws IOException {
        String username = usename.getText().trim();
        String pass = password.getText().trim();
        if (Controller.getPerson(username,pass)!=null){
            this.person = Controller.getPerson(username,pass);
            Log.initialize(this.person);
            Log.logCompile("Signing in is successful.","info");
            Controller.getInstance().initializeMission(Controller.getPerson(username,pass));
            Log.logCompile("Reading Mission List from file","info");
            Main.changeScene("View/Menu1/mainMenu.fxml");
        }
    }

    @FXML
    void signup(ActionEvent event) throws IOException {
        Main.changeScene("View/Menu1/signup.fxml");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        Controller.readPerson();
    }
}
