package sample.View.Menu1;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import sample.Controller.Controller;
import sample.Main;
import sample.Model.Person;

import java.io.IOException;

public class Login1 {
    public static Person user = new Person();
    static int level;
    static int levelW;

    @FXML
    Label wrongLog;
    @FXML
    TextField username;
    @FXML
    PasswordField password;
    @FXML
    Button back;
    @FXML
    Button enter;

    public void userLogin() throws IOException {
        checkLogin();
    }

    void checkLogin() throws IOException {
        String name = username.getText().trim();
        String pass = password.getText().trim();
        if (Controller.getPerson(name, pass) != null) {
            user = Controller.getPerson(name, pass);
            Controller.getInstance().initializeMission(Controller.getPerson(name, pass));
            for (int i = 0; i < 5; i++) {
                if (Controller.getInstance().mission.levels[i].timeFinished == -1) {
                    level = i+1;
                    break;
                }
            }
            setLevels(level);
        } else if (name.isEmpty() || pass.isEmpty()) {
            wrongLog.setText("Enter your data");
        } else
            wrongLog.setText("Wrong data");
    }

    public void backToMain() throws IOException {
        Main.changeScene("View/Menu1/firstMenu.fxml");
    }

    static void setLevels(int level) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("View/Menu1/levelsMenu.fxml"));
        Parent root = loader.load();
        Levels levels = loader.getController();
        if (level < 5) {
            levels.image5.setImage(new Image("CircleButtonLocked.png"));
            levels.level5.setOnAction(e -> {
            });
        }
        if (level < 4) {
            levels.image4.setImage(new Image("CircleButtonLocked.png"));
            levels.level4.setOnAction(e -> {
            });
        }
        if (level < 3) {
            levels.image3.setImage(new Image("CircleButtonLocked.png"));
            levels.level3.setOnAction(e -> {
            });
        }
        if (level < 2) {
            levels.image2.setImage(new Image("CircleButtonLocked.png"));
            levels.level2.setOnAction(e -> {
            });
        }
        Main.window.getScene().setRoot(root);
    }
}
