package sample.View.Menu1;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import sample.Controller.Controller;
import sample.Controller.Log;
import sample.Main;
import sample.View.Color;
import sample.View.OutputProcessor;

import java.io.IOException;

public class MainMenu {

    public static GameMenu gameMenu = new GameMenu();

    void checkLevel (int level) throws IOException {
        String s = Controller.getInstance().checkLevelForStart(level-1);
        boolean truth=false;
        switch (s){
            case "the first try for level 1":
                Controller.getInstance().currentLevel=0;
                GameMenu.level=0;
                Log.logCompile("User want to start Level 1","info");
                truth=true;
                break;
            case "the first try for level [stage]":
            case "again level" :
                Controller.getInstance().currentLevel= level-1;
                GameMenu.level=level-1;
                Log.logCompile("User want to Start Level "+Integer.toString(0),"info");
                truth=true;
                break;
            case "incorrect level":
                /*OutputProcessor.getInstance().printError("You can't start this level!");*/
                Log.logCompile("The User can't start from this Level!","error");
                break;
            case "invalid":
                /*OutputProcessor.getInstance().printError("INVALID INPUT");*/
                Log.logCompile("INVALID INPUT  in starting Level","error");
                break;
        }
        if (truth){
            Log.logCompile("Going to Game Menu for Level "+Integer.toString(0),"info");
            Main.Rooting();
            //Main.changeScene("View\\Menu1\\gameMenu.fxml");
        }
    }

    @FXML
    void level1(ActionEvent event) throws IOException {
       checkLevel(1);
    }

    @FXML
    void level2(ActionEvent event) throws IOException {
        checkLevel(2);
    }

    @FXML
    void level3(ActionEvent event) throws IOException {
        checkLevel(3);
    }

    @FXML
    void level4(ActionEvent event) throws IOException {
        checkLevel(4);
    }

    @FXML
    void level5(ActionEvent event) throws IOException {
        checkLevel(5);
    }

    @FXML
    void logout(ActionEvent event) throws IOException {
        Controller.getInstance().saveGame();
        Controller.saveUsers();
        try {
            Controller.getInstance().ResetLevel();

        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        Log.logCompile("User log out of his/her account But Game saved","info");
        Main.changeScene("View/Menu1/login.fxml");
    }
}
