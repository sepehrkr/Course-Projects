package sample.View.Menu1;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import sample.Main;

import java.util.Objects;

public class MyImage {

    // Chicken
    public static final Image chicken_up = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/chicken_up.png")).toString());
    public static final Image chicken_down = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/chicken_down.png")).toString());
    public static final Image chicken_right = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/chicken_right.png")).toString());
    public static final Image chicken_left = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/chicken_left.png")).toString());

    public static final int width_chicken_down = 66;
    public static final int height_chicken_down = 72;
    public static final int width_chicken_left = 80;
    public static final int height_chicken_left = 74;
    public static final int width_chicken_right = 80;
    public static final int height_chicken_right = 74;
    public static final int width_chicken_up = 64;
    public static final int height_chicken_up = 84;

    public static final int countChicken = 24;
    public static final int columnChicken = 5;

    // Turkey
    public static final Image turkey_up = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/turkey_up.png")).toString());
    public static final Image turkey_down = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/turkey_down.png")).toString());
    public static final Image turkey_right = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/turkey_right.png")).toString());
    public static final Image turkey_left = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/turkey_left.png")).toString());

    public static final int width_turkey_down = 86;
    public static final int height_turkey_down = 126;
    public static final int width_turkey_left = 100;
    public static final int height_turkey_left = 132;
    public static final int width_turkey_right = 100;
    public static final int height_turkey_right = 132;
    public static final int width_turkey_up = 86;
    public static final int height_turkey_up = 142;

    public static final int countTurkey = 24;
    public static final int columnTurkey_up_left_right = 4;
    public static final int columnTurkey_down = 6;

    // Buffalo
    public static final Image buffalo_up = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/buffalo_up.png")).toString());
    public static final Image buffalo_down = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/buffalo_down.png")).toString());
    public static final Image buffalo_right = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/buffalo_right.png")).toString());
    public static final Image buffalo_left = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/buffalo_left.png")).toString());

    public static final int width_buffalo_down = 132;
    public static final int height_buffalo_down = 110;
    public static final int width_buffalo_left = 174;
    public static final int height_buffalo_left = 128;
    public static final int width_buffalo_right = 174;
    public static final int height_buffalo_right = 128;
    public static final int width_buffalo_up =134;
    public static final int height_buffalo_up = 124;

    public static final int countBuffalo = 24;
    public static final int columnBuffalo_down_up = 6;
    public static final int columnBuffalo_left_right = 4;

    // Cat
    public static final Image cat_up = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/cat_up.png")).toString());
    public static final Image cat_down = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/cat_down.png")).toString());
    public static final Image cat_right = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/cat_right.png")).toString());
    public static final Image cat_left = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/cat_left.png")).toString());

    public static final int width_cat_down = 72;
    public static final int height_cat_down = 80;
    public static final int width_cat_left = 72;
    public static final int height_cat_left = 80;
    public static final int width_cat_right = 72;
    public static final int height_cat_right = 80;
    public static final int width_cat_up =72;
    public static final int height_cat_up = 80;

    public static final int countCat = 24;
    public static final int columnCat = 4;

    // Dog
    public static final Image dog_up = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/dog_up.png")).toString());
    public static final Image dog_down = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/dog_down.png")).toString());
    public static final Image dog_right = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/dog_right.png")).toString());
    public static final Image dog_left = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/dog_left.png")).toString());

    public static final int width_dog_down = 108;
    public static final int height_dog_down = 84;
    public static final int width_dog_left = 108;
    public static final int height_dog_left = 86;
    public static final int width_dog_right = 108;
    public static final int height_dog_right = 86;
    public static final int width_dog_up =108;
    public static final int height_dog_up = 84;

    public static final int countDog = 24;
    public static final int columnDog = 6;

    // Lion
    public static final Image lion_up = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/lion_up.png")).toString());
    public static final Image lion_down = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/lion_down.png")).toString());
    public static final Image lion_right = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/lion_right.png")).toString());
    public static final Image lion_left = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/lion_left.png")).toString());

    public static final int width_lion_down = 96;
    public static final int height_lion_down = 92;
    public static final int width_lion_left = 138;
    public static final int height_lion_left = 92;
    public static final int width_lion_right = 138;
    public static final int height_lion_right = 92;
    public static final int width_lion_up =94;
    public static final int height_lion_up = 116;

    public static final int countLion = 24;
    public static final int columnLion_up_down = 5;
    public static final int columnLion_left_right = 3;


    // Bear
    public static final Image bear_up = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/bear_up.png")).toString());
    public static final Image bear_down = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/bear_down.png")).toString());
    public static final Image bear_right = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/bear_right.png")).toString());
    public static final Image bear_left = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/bear_left.png")).toString());

    public static final int width_bear_down = 120;
    public static final int height_bear_down = 108;
    public static final int width_bear_left = 120;
    public static final int height_bear_left = 108;
    public static final int width_bear_right = 120;
    public static final int height_bear_right = 108;
    public static final int width_bear_up =120;
    public static final int height_bear_up = 108;

    public static final int countBear = 24;
    public static final int columnBear = 4;

    // Tiger
    public static final Image tiger_up = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/tiger_up.png")).toString());
    public static final Image tiger_down = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/tiger_down.png")).toString());
    public static final Image tiger_right = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/tiger_right.png")).toString());
    public static final Image tiger_left = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/tiger_left.png")).toString());


    public static final int width_tiger_down = 96;
    public static final int height_tiger_down = 98;
    public static final int width_tiger_left = 96;
    public static final int height_tiger_left = 84;
    public static final int width_tiger_right = 96;
    public static final int height_tiger_right = 84;
    public static final int width_tiger_up =96;
    public static final int height_tiger_up = 88;

    public static final int countTiger = 6;
    public static final int columnTiger = 6;


    // Well
    public static final Image well = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/well.png")).toString());
    public static int wellFixed_width = 148;
    public static int wellFixed_height = 150;
    public static int wellFixed_count = 16;
    public static int wellFixed_col = 4;

    public static final Image well_fixed = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/well_fixed.png")).toString());

    public static Image grassFixed = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/grass_fisxed.png")).toString());

    public static Image upgrade = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/upgrade.png")).toString());

    public static Image chicken_eat = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/chicken_eat.png")).toString());

    public static final int chicken_eat_column = 5;
    public static final int chicken_eat_count = 24;
    public static final int chicken_eat_width = 74;
    public static final int chicken_eat_height = 64;

    public static Image buffalo_eat = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/buffalo_eat.png")).toString());
    public static final int buffalo_eat_column = 6;
    public static final int buffalo_eat_count = 22;
    public static final int buffalo_eat_width = 160;
    public static final int buffalo_eat_height = 122;

    public static Image turkey_eat = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/turkey_eat.png")).toString());
    public static final int turkey_eat_column = 4;
    public static final int turkey_eat_count = 24;
    public static final int turkey_eat_width = 114;
    public static final int turkey_eat_height = 114;

    public static Image grass = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/grass.png")).toString());
    public static final int grass_col = 4;
    public static final int grass_count = 16;
    public static final int grass_width = 48;
    public static final int grass_height = 48;


    public static Image bakery = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/bakeryF.png")).toString());
    public static int bakery_column = 4;
    public static int bakery_count = 16;
    public static int bakery_width = 184;
    public static int bakery_height = 172;

    public static Image iceCreamF = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/iceCreamF.png")).toString());
    public static int iceCreamF_column = 4;
    public static int iceCreamF_count = 16;
    public static int iceCreamF_width = 190;
    public static int iceCreamF_height = 176;

    public static Image milkF = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/milkF.png")).toString());
    public static int milkF_column = 4;
    public static int milkF_count = 16;
    public static int milkF_width = 184;
    public static int milkF_height = 178;

    public static Image millF = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/millF.png")).toString());
    public static int millF_column = 4;
    public static int millF_count = 16;
    public static int millF_width = 200;
    public static int millF_height = 200;

    public static Image tailoringF = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/tailoringF.png")).toString());
    public static int tailoringF_column = 4;
    public static int tailoringF_count = 16;
    public static int tailoringF_width = 200;
    public static int tailoringF_height = 200;

    public static Image textileF = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/textileF.png")).toString());
    public static int textileF_column = 4;
    public static int textileF_count = 16;
    public static int textileF_width = 200;
    public static int textileF_height = 200;

    public static Image chickenF = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/chickenF.png")).toString());
    public static int chickenF_column = 4;
    public static int chickenF_count = 16;
    public static int chickenF_width = 178;
    public static int chickenF_height = 162;



    public static Image bakery_fixed = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/bakeryFfixed.png")).toString());

    public static Image textile_fixed = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/textileFfixed.png")).toString());

    public static Image tailoring_fixed = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/tailoringFfixed.png")).toString());

    public static Image milk_fixed = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/milkFfixed.png")).toString());

    public static Image mill_fixed = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/millFfixed.png")).toString());

    public static Image iceCream_fixed = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/iceCreamFfixed.png")).toString());

    public static Image chickenF_fixed = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/chickenFfixed.png")).toString());

    public static Image cage1 = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/cage1.png")).toString());

    public static Image cage2 = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/cage2.png")).toString());

    public static Image cage3 = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/cage3.png")).toString());

    public static Image cage4 = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/cage4.png")).toString());

    public static Image cage5 = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/cage5.png")).toString());

    public static Image cage6 = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/cage6.png")).toString());

    public static Image cage7 = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/cage7.png")).toString());

    public static Image bread = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/bread.png")).toString());
    public static Image iceCream = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/iceCream.png")).toString());
    public static Image flour = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/flour.png")).toString());
    public static Image cloth = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/cloth.png")).toString());
    public static Image egg = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/egg.png")).toString());
    public static Image feather = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/feather.png")).toString());
    public static Image milk = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/milk.png")).toString());
    public static Image packMilk = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/packMilk.png")).toString());
    public static Image shirt = new Image(Objects.requireNonNull(MyImage.class.getResource("/images/shirt.png")).toString());


    public static Image vehicle_right =  new Image(Objects.requireNonNull(MyImage.class.getResource("/images/vehicle_right1.png")).toString());
    public static int vehicle_right_column = 3;
    public static int vehicle_right_count = 6;
    public static int vehicle_right_width = 96;
    public static int vehicle_right_height = 96;

    public static Image vehicle_left=  new Image(Objects.requireNonNull(MyImage.class.getResource("/images/vehicle_left1.png")).toString());
    public static int vehicle_left_column = 3;
    public static int vehicle_left_count = 6;
    public static int vehicle_left_width = 96;
    public static int vehicle_left_height = 96;

}
