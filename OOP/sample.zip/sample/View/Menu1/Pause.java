package sample.View.Menu1;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;
import sample.Controller.Controller;
import sample.Main;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Pause {
    public Label task1;
    public Label task2;
    public Label task3;
    public Label task4;
    public Label task5;
    public Label task6;
    public ImageView musicImg;
    public ImageView image1;
    public ImageView image2;
    public ImageView image3;
    public ImageView image4;
    public ImageView image5;
    public ImageView image6;


    public void back() {
        try {
            TimeUnit.MILLISECONDS.sleep(250);
        } catch (InterruptedException ignored) {

        }
        Main.alertStage.close();
    }

    public void music() {
        if (Main.mp.isMute()) {
            musicImg.setImage(new Image("soundOn.png"));
            Main.mp.setMute(false);
        } else {
            musicImg.setImage(new Image("soundOff.png"));
            Main.mp.setMute(true);
        }
    }

    public void backToMenu() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("View/Menu1/alert.fxml"));
        Parent root = loader.load();
        Alert alert = loader.getController();
        alert.label.setFont(new Font("System", 22));
        alert.label.setLayoutX(alert.label.getLayoutX() - 15);
        alert.label.setText("Sure you want to back to the levels menu?");
        Stage stage = new Stage();
        alert.no.setOnAction(e -> {
            try {
                TimeUnit.MILLISECONDS.sleep(250);
            } catch (InterruptedException ignored) {

            }
            stage.close();
        });
        alert.yes.setOnAction(e -> {
            try {
                TimeUnit.MILLISECONDS.sleep(250);
            } catch (InterruptedException ignored) {

            }
            Main.mp.stop();
            stage.close();
            Main.alertStage.close();
            try {
                Controller.getInstance().ResetLevel();
                Login1.setLevels(Login1.level);
            } catch (IOException | CloneNotSupportedException ioException) {
                ioException.printStackTrace();
            }
        });
        stage.setScene(new Scene(root, 450, 300));
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setResizable(false);
        stage.setTitle("Back");
        stage.show();
    }
}
