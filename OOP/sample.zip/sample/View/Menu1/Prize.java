package sample.View.Menu1;

import sample.Main;
import sample.View.Menu1.Login1;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Label;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Prize {

    @FXML
    Label label1;
    @FXML
    Label label2;
    @FXML
    Label label3;
    @FXML
    Label level;

    public void goOn() throws IOException {
        Main.mp.play();
        Main.Rooting();
        try {
            TimeUnit.MILLISECONDS.sleep(250);
        } catch (InterruptedException ignored) {

        }
    }

    public void back() throws IOException {
        try {
            TimeUnit.MILLISECONDS.sleep(250);
        } catch (InterruptedException ignored) {

        }
        Login1.setLevels(Login1.level);
    }
}
