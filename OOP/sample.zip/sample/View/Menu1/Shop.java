package sample.View.Menu1;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import sample.Controller.Controller;
import sample.Main;
import sample.Model.Map;
import sample.Model.animal.Cat;
import sample.Model.animal.Chicken;
import sample.Model.animal.Dog;
import sample.Model.animal.Domestic;

import java.io.IOException;
import java.net.URL;
import java.util.Observable;
import java.util.ResourceBundle;

public class Shop implements Initializable {
    Controller controller = Controller.getInstance();

    @FXML
    private Label coinLabel;

    public static ObservableList<ImageView> images = FXCollections.observableArrayList();

    @FXML
    void back(ActionEvent event) throws IOException {
        GameMenu.shopStage.close();
    }

    @FXML
    void buyBuffalo(MouseEvent event) {
        int a = controller.buyAnimal("buffalo");
        if (a==1){
           /* Domestic domestic = Map.domestics.get(Map.domestics.size()-1);
            double [] coordinate = GameMenu.convertTo(domestic.row,domestic.col);
            ImageView buffalo = new ImageView(MyImage.buffalo_right);
            buffalo.setViewport(new Rectangle2D(0,0,MyImage.width_buffalo_right,MyImage.height_buffalo_right));
            buffalo.setLayoutX(coordinate[0]);
            buffalo.setLayoutY(coordinate[1]);
            GameMenu.domestics.add(buffalo);*/
            MainMenu.gameMenu.coin.setText(Long.toString(controller.levelAlter[controller.currentLevel].coins));
            coinLabel.setText("Coins : "+controller.levelAlter[controller.currentLevel].coins);
        }
    }

    @FXML
    void buyCat(MouseEvent event) {
        int a = controller.buyAnimal("cat");
        if (a==1){
           /* Cat cat = Map.cats.get(Map.cats.size()-1);
            double [] coordinate = GameMenu.convertTo(cat.row, cat.col);
            ImageView catImage = new ImageView(MyImage.cat_right);
            catImage.setViewport(new Rectangle2D(0,0,MyImage.width_cat_right,MyImage.height_cat_right));
            catImage.setLayoutX(coordinate[0]);
            catImage.setLayoutY(coordinate[1]);
            images.add(catImage);*/
            MainMenu.gameMenu.coin.setText(Long.toString(controller.levelAlter[controller.currentLevel].coins));
            coinLabel.setText("Coins : "+controller.levelAlter[controller.currentLevel].coins);
        }
    }

    @FXML
    void buyChicken(MouseEvent event) {
        int a =  controller.buyAnimal("chicken");
        if (a==1){
            /*Domestic domestic = Map.domestics.get(Map.domestics.size()-1);
            double [] coordinate = GameMenu.convertTo(domestic.row,domestic.col);
            ImageView chicken = new ImageView(MyImage.chicken_right);
            chicken.setViewport(new Rectangle2D(0,0,MyImage.width_chicken_right,MyImage.height_chicken_right));
            chicken.setLayoutX(coordinate[0]);
            chicken.setLayoutY(coordinate[1]);
            //GameMenu.domestics.add(chicken);
            images.add(chicken);*/
            MainMenu.gameMenu.coin.setText(Long.toString(controller.levelAlter[controller.currentLevel].coins));
            coinLabel.setText("Coins : "+controller.levelAlter[controller.currentLevel].coins);
        }
    }

    @FXML
    void buyDog(MouseEvent event) {
        int a =  controller.buyAnimal("dog");
        if (a==1){
            /*Dog dog = Map.dogs.get(Map.cats.size()-1);
            double [] coordinate = GameMenu.convertTo(dog.row, dog.col);
            ImageView dogImage = new ImageView(MyImage.cat_right);
            dogImage.setViewport(new Rectangle2D(0,0,MyImage.width_dog_right,MyImage.height_dog_right));
            dogImage.setLayoutX(coordinate[0]);
            dogImage.setLayoutY(coordinate[1]);
            images.add(dogImage);*/
            MainMenu.gameMenu.coin.setText(Long.toString(controller.levelAlter[controller.currentLevel].coins));
            coinLabel.setText("Coins : "+controller.levelAlter[controller.currentLevel].coins);
        }
    }

    @FXML
    void buyTurkey(MouseEvent event) {
        int a = controller.buyAnimal("turkey");
        if (a==1){
            /*Domestic domestic = Map.domestics.get(Map.domestics.size()-1);
            double [] coordinate = GameMenu.convertTo(domestic.row,domestic.col);
            ImageView turkey = new ImageView(MyImage.turkey_right);
            turkey.setViewport(new Rectangle2D(0,0,MyImage.width_turkey_right,MyImage.height_turkey_right));
            turkey.setLayoutX(coordinate[0]);
            turkey.setLayoutY(coordinate[1]);
            GameMenu.domestics.add(turkey);*/
            MainMenu.gameMenu.coin.setText(Long.toString(controller.levelAlter[controller.currentLevel].coins));
            coinLabel.setText("Coins : "+controller.levelAlter[controller.currentLevel].coins);
        }
    }



    @Override
    public void initialize(URL location, ResourceBundle resources) {
        coinLabel.setText("Coins : "+controller.levelAlter[controller.currentLevel].coins);
    }

}
