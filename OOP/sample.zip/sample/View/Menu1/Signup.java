package sample.View.Menu1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import sample.Controller.Controller;
import sample.Controller.Log;
import sample.Main;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Signup implements Initializable {

    @FXML
    private TextField username;

    @FXML
    private TextField password;

    @FXML
    void signup(ActionEvent event) throws IOException {
        String user = username.getText();
        String pass = password.getText();
        if (Controller.getPerson(user,pass)==null){
            Controller.addPerson(user,pass);
            Controller.getInstance().doRegistration();
            Log.initialize(Controller.users.get(Controller.users.size()-1));
            Log.logCompile("The Signing up is successful","info");
            Main.changeScene("View/Menu1/mainMenu.fxml");
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        Controller.readPerson();
    }
}
