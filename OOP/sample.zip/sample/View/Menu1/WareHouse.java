package sample.View.Menu1;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import sample.Controller.Controller;
import sample.Model.Price;
import sample.Model.Store;
import sample.Model.Vehicle;
import sample.Model.animal.Bear;
import sample.Model.animal.Lion;
import sample.Model.animal.Tiger;
import sample.Model.animal.Wild;
import sample.Model.product.Egg;

import java.net.URL;
import java.util.ResourceBundle;

public class WareHouse implements Initializable {

    @FXML
    private Label eggCount;

    @FXML
    private Label featherCount;

    @FXML
    private Label milkCount;

    @FXML
    private Label floutCount;

    @FXML
    private Label clothCount;

    @FXML
    private Label packMilkCount;

    @FXML
    private Label breadCount;

    @FXML
    private Label shirtCount;

    @FXML
    private Label iceCreamCount;

    @FXML
    private Label lionCount;

    @FXML
    private Label bearCount;

    @FXML
    private Label tigerCount;


    @FXML
    private TextField nameField;

    @FXML
    private Label coins;

    @FXML
    private Label output;

    @FXML
    void back(MouseEvent event) {
        GameMenu.shopStage.close();
    }

    @FXML
    void loading(MouseEvent event) {
        Controller controller = Controller.getInstance();
        int a =0;
        switch (nameField.getText().trim().toLowerCase()){
            case "egg":
                 a = controller.truckLoad("egg");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Loaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())+Price.EGG.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "feather":
                 a = controller.truckLoad("feather");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Loaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())+Price.FEATHER.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "milk":
                 a = controller.truckLoad("milk");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Loaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())+Price.MILK.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "flour":
                 a = controller.truckLoad("flour");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Loaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())+Price.FLOUR.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "cloth":
                 a = controller.truckLoad("cloth");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Loaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())+Price.CLOTH.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "pack milk":
                 a = controller.truckLoad("pack milk");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Loaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())+Price.PACK_MILK.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "bread":
                 a = controller.truckLoad("bread");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Loaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())+Price.BREAD.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "shirt":
                 a =  controller.truckLoad("shirt");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Loaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())+Price.SHIRT.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case  "ice cream":
                 a =  controller.truckLoad("ice cream");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Loaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())+Price.ICE_CREAM.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "bear":
                 a = controller.truckLoad("bear");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Loaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())+Price.BEAR.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "lion":
                 a = controller.truckLoad("lion");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Loaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())+Price.LION.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "tiger":
                 a = controller.truckLoad("tiger");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Loaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())+Price.TIGER.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
        }
        setWareHouse();
    }

    @FXML
    void startTravel(MouseEvent event) {
        boolean truth = Controller.getInstance().truckGO();
        if (truth) {
            setWareHouse();
            coins.setText("0");

            ImageView imageView = new ImageView(MyImage.vehicle_right);
            Animation animation = new SpriteAnimation(imageView, Duration.millis(300), MyImage.vehicle_right_count, MyImage.vehicle_right_column, 0, 0, MyImage.vehicle_right_width, MyImage.vehicle_right_height);
            animation.setCycleCount(Animation.INDEFINITE);
            animation.play();
            MainMenu.gameMenu.mainPane.getChildren().add(imageView);
            TranslateTransition transition = new TranslateTransition();
            transition.setDuration(Duration.millis(3000));
            transition.setInterpolator(Interpolator.LINEAR);
            transition.setNode(imageView);
            transition.setFromX(370);
            transition.setFromY(598);
            transition.setToX(370);
            transition.setToY(200);
            MainMenu.gameMenu.vehicle.setVisible(false);
            transition.play();
            transition.setOnFinished(e -> {
                TranslateTransition transition1 = new TranslateTransition();
                transition1.setDuration(Duration.millis(3000));
                transition1.setInterpolator(Interpolator.LINEAR);
                transition1.setNode(imageView);
                transition1.setFromX(370);
                transition1.setFromY(200);
                transition1.setToX(1250);
                transition1.setToY(200);
                transition1.play();
                transition1.setOnFinished(s -> {
                    MainMenu.gameMenu.mainPane.getChildren().remove(imageView);

                });
            });
        }
    }

    @FXML
    void unloading(MouseEvent event) {
        Controller controller =Controller.getInstance();
        int a =0;
        switch (nameField.getText().trim().toLowerCase()){
            case "egg":
                a = controller.truckUnload("egg");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Unloaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())-Price.EGG.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "feather":
                a = controller.truckUnload("feather");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Unloaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())-Price.FEATHER.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "milk":
                a = controller.truckUnload("milk");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Unloaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())-Price.MILK.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "flour":
                a = controller.truckUnload("flour");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Unloaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())-Price.FLOUR.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "cloth":
                a = controller.truckUnload("cloth");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Unloaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())-Price.CLOTH.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "pack milk":
                a = controller.truckUnload("pack milk");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Unloaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())-Price.PACK_MILK.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "bread":
                a = controller.truckUnload("bread");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Unloaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())-Price.BREAD.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "shirt":
                a =  controller.truckUnload("shirt");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Unloaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())-Price.SHIRT.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case  "ice cream":
                a =  controller.truckUnload("ice cream");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Unloaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())-Price.ICE_CREAM.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "bear":
                a = controller.truckUnload("bear");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Unloaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())-Price.BEAR.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "lion":
                a = controller.truckUnload("lion");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Unloaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())-Price.LION.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
            case "tiger":
                a = controller.truckUnload("tiger");
                if (a==1){
                    output.setTextFill(Color.GREEN);
                    output.setText("Unloaded successfully");
                    coins.setText(Integer.toString(Integer.parseInt(coins.getText())-Price.TIGER.getPrice()));
                } else if (a==-1){
                    output.setTextFill(Color.RED);
                    output.setText("Not enough storage");
                } else if (a==-2 || a==-3) {
                    output.setTextFill(Color.RED);
                    output.setText("Invalid input");
                } else if (a==-4){
                    output.setTextFill(Color.RED);
                    output.setText("Vehicle is not here");
                }
                break;
        }
        setWareHouse();
    }

    void setWareHouse (){
        Store store = Store.getInstance();
        eggCount.setText(Integer.toString(store.storeEggs.size()));
        featherCount.setText(Integer.toString(store.storeFeathers.size()));
        milkCount.setText(Integer.toString(store.storeMilks.size()));
        floutCount.setText(Integer.toString(store.storeFlours.size()));
        clothCount.setText(Integer.toString(store.storeClothes.size()));
        packMilkCount.setText(Integer.toString(store.storePackMilks.size()));
        breadCount.setText(Integer.toString(store.storeBreads.size()));
        shirtCount.setText(Integer.toString(store.storeShirts.size()));
        iceCreamCount.setText(Integer.toString(store.storeIceCreams.size()));
        int countLion=0;
        int countBear=0;
        int countTiger=0;
        for (Wild wild : store.storeWilds){
            if (wild instanceof Lion)
                countLion++;
            else if (wild instanceof Bear)
                countBear++;
            else if (wild instanceof Tiger)
                countTiger++;
        }
        lionCount.setText(Integer.toString(countLion));
        bearCount.setText(Integer.toString(countBear));
        tigerCount.setText(Integer.toString(countTiger));
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setWareHouse();
        coins.setText("0");
    }
}
