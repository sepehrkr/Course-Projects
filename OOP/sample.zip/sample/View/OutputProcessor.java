package sample.View;

public class OutputProcessor {

    public void printResult (String message)
    {
        System.out.println(message);
    }
    public void printError (String error)
    {
        System.out.println(Color.TEXT_RED.getColor()+error+Color.TEXT_RESET.getColor());
    }
    public void invalidInputError ()
    {
        System.out.println(Color.TEXT_RED.getColor()+"INVALID INPUT!"+Color.TEXT_RESET.getColor());
    }



    //singleton design

    private static OutputProcessor outputProcessor =null;

    private OutputProcessor() {
    }
    public static OutputProcessor getInstance()
    {
        if (outputProcessor==null)
        {
            outputProcessor=new OutputProcessor();
        }
        return outputProcessor;
    }

}
