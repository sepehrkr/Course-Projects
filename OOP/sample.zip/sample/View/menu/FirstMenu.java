package sample.View.menu;

import sample.View.Color;
import  sample.View.InputCommand;
import  sample.View.menu.Menu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class FirstMenu extends Menu {
    public FirstMenu(String name , Scanner scanner) {
        super(name,scanner);
        this.subMenus.add(new MainMenu("Menu",this,scanner)); // index 0
        this.subMenus.add(new SignIn("Sign in",this,scanner,(MainMenu) subMenus.get(0)));  // index 1
        this.subMenus.add(new SignUp("Sign Up",this,scanner,(MainMenu) subMenus.get(0)));  // index 2
    }

    @Override
    public void show() {
        System.out.println(Color.TEXT_BLUE.getColor()+"Log In :");
        System.out.println("Sign Up");
        System.out.println("Sign In");
        System.out.println("Exit"+Color.TEXT_BLUE.getColor());
    }

    @Override
    public void execute() {
        Menu nextMenu;
        String command;
        while (true)
        {
            command=scanner.nextLine().trim().toLowerCase();
            if (InputCommand.SIGN_IN.getMatcher(command).matches()){
                nextMenu=subMenus.get(1);
                break;
            } else if (InputCommand.SIGN_UP.getMatcher(command).matches()){
                nextMenu=subMenus.get(2);
                break;
            } else if (InputCommand.EXIT.getMatcher(command).matches()){
                System.exit(0);
            }
            else {
                System.out.println(Color.TEXT_RED.getColor()+"INVALID INPUT!"+Color.TEXT_RESET);
            }
        }
        nextMenu.show();
        nextMenu.execute();
    }
}
