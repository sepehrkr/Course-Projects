package sample.View.menu;

import  sample.Controller.*;
import  sample.View.Color;
import  sample.View.InputCommand;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.Matcher;

public class GameMenu extends Menu {

    Controller controller;
    int level;
    public GameMenu(String name, Menu parentMenu, Scanner scanner) {
        super(name, parentMenu, scanner);
        this.controller=Controller.getInstance();
    }

    @Override
    void show() {
        System.out.println(Color.TEXT_BLUE.getColor()+this.name+" :"+Color.TEXT_RESET.getColor());
        System.out.println(Color.TEXT_BLUE.getColor()+"Buy animal_name"+Color.TEXT_RESET.getColor());
        System.out.println(Color.TEXT_BLUE.getColor()+"Pickup x y"+Color.TEXT_RESET.getColor());
        System.out.println(Color.TEXT_BLUE.getColor()+"Well"+Color.TEXT_RESET.getColor());
        System.out.println(Color.TEXT_BLUE.getColor()+"Plant x y"+Color.TEXT_RESET.getColor());
        System.out.println(Color.TEXT_BLUE.getColor()+"Build workshop_name f"+Color.TEXT_RESET.getColor());
        System.out.println(Color.TEXT_BLUE.getColor()+"Work workshop_name f"+Color.TEXT_RESET.getColor());
        System.out.println(Color.TEXT_BLUE.getColor()+"Upgrade workshop_name f"+Color.TEXT_RESET.getColor());
        System.out.println(Color.TEXT_BLUE.getColor()+"cage x y"+Color.TEXT_RESET.getColor());
        System.out.println(Color.TEXT_BLUE.getColor()+"Turn n"+Color.TEXT_RESET.getColor());
        System.out.println(Color.TEXT_BLUE.getColor()+"Truck load item_name"+Color.TEXT_RESET.getColor());
        System.out.println(Color.TEXT_BLUE.getColor()+"Truck unload item_name"+Color.TEXT_RESET.getColor());
        System.out.println(Color.TEXT_BLUE.getColor()+"Truck Go"+Color.TEXT_RESET.getColor());
        System.out.println(Color.TEXT_BLUE.getColor()+"Inquiry"+Color.TEXT_RESET.getColor());
        System.out.println(Color.TEXT_BLUE.getColor()+"Back"+Color.TEXT_RESET.getColor());
        Long [] prizes = new Long[3];
        prizes = Controller.getInstance().levelAlter[level].Prize.toArray(prizes);
        Integer [] time = new Integer[3];
        time= Controller.getInstance().levelAlter[level].time.toArray(time);
        Arrays.sort(prizes);
        Arrays.sort(time);
        System.out.println("TIME AND PRIZES : ");
        for (int i=0;i<prizes.length;i++)
        {
            System.out.println(time[i]+" Unit : "+prizes[2-i]+" Coins");
        }
        Level level = Controller.getInstance().level[this.level];
        if (level.timeFinished==-1){
            System.out.println("You haven't start this level yet.");
        } else
            System.out.println("Your record : "+level.timeFinished);
    }

    @Override
    void execute() {
        Log.logCompile("User is in Game Menu","info");
        boolean finishedLevel=false;
        Menu nextMenu;
        String command;
        Matcher matcher;
        MyTime.getInstance().exited=false;
        MyTime.getInstance().execute();
        while (!(command=scanner.nextLine().trim().toLowerCase()).equals("back")){
            if ((matcher= InputCommand.BUY.getMatcher(command)).matches() && !finishedLevel){
                Log.logCompile("User want to buy a "+matcher.group(1),"info");
                controller.buyAnimal(matcher.group(1));
            } else if ((matcher=InputCommand.PICKUP.getMatcher(command)).matches() && !finishedLevel){
                Log.logCompile("User want to pick up in "+Integer.parseInt(matcher.group(1))+" , "+Integer.parseInt(matcher.group(2))+" coordinate","info");
                controller.pickUp(Integer.parseInt(matcher.group(1)),Integer.parseInt(matcher.group(2)));
            } else if ((matcher=InputCommand.INQUIRY.getMatcher(command)).matches() && !finishedLevel){
                Log.logCompile("User inquiried.","info");
                controller.showInquiry();
            } else if ((matcher=InputCommand.WELL.getMatcher(command)).matches() && !finishedLevel){
                Log.logCompile("User want to get water","info");
                controller.well();
            } else if ((matcher=InputCommand.PLANT.getMatcher(command)).matches() && !finishedLevel){
                Log.logCompile("User wants to plant in "+Integer.parseInt(matcher.group(1))+" , "+Integer.parseInt(matcher.group(2))+" coordinate","info");
                controller.plant(Integer.parseInt(matcher.group(1)),Integer.parseInt(matcher.group(2)));
            } else if ((matcher=InputCommand.WORK.getMatcher(command)).matches() && !finishedLevel){
                Log.logCompile("User want to Factory "+matcher.group(1)+" Work","info");
                controller.work(matcher.group(1));
            } else if ((matcher=InputCommand.CAGE.getMatcher(command)).matches() && !finishedLevel){
                Log.logCompile("User want to cage wild animal in "+Integer.parseInt(matcher.group(1))+" , "+Integer.parseInt(matcher.group(2))+" coordinate","info");
                controller.cage(Integer.parseInt(matcher.group(1)),Integer.parseInt(matcher.group(2)));
            } else if ((matcher=InputCommand.TURN.getMatcher(command)).matches() && !finishedLevel){
                Log.logCompile("User want to turn time for "+matcher.group(1)+"Unit","info");
                try {
                    controller.turn(Integer.parseInt(matcher.group(1)));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if ((matcher=InputCommand.TRUCK_LOAD.getMatcher(command)).matches() && !finishedLevel){
                Log.logCompile("User want to load "+matcher.group(1)+" in the truck","info");
                controller.truckLoad(matcher.group(1));
            } else if ((matcher=InputCommand.TRUCK_UNLOAD.getMatcher(command)).matches() && !finishedLevel){
                Log.logCompile("User want to unLoad "+matcher.group(1)+" of Truck","info");
                controller.truckUnload(matcher.group(1));
            } else if ((matcher=InputCommand.TRUCK_GO.getMatcher(command)).matches() && !finishedLevel){
                Log.logCompile("User want to statrt trick traveling","info");
                controller.truckGO();
            } else if ((matcher=InputCommand.BUILD.getMatcher(command)).matches() && !finishedLevel){
                Log.logCompile("User want to build Factory "+matcher.group(1) , "info");
                controller.build(matcher.group(1));
            } else if ((matcher=InputCommand.UPGRADE.getMatcher(command)).matches() && !finishedLevel){
                Log.logCompile("User want to upgrade factory "+matcher.group(1),"info");
                controller.upgrade(matcher.group(1));
            } else if (!finishedLevel) {
                System.out.println(Color.TEXT_RED.getColor()+"INVALID INPUT!"+Color.TEXT_RESET.getColor());
            }
            if (Controller.checkTask(level)) {
                MyTime.getInstance().exited = true;
                Log.logCompile("tasks of this Level finished.","info");
                finishedLevel=true;
                controller.levelAlter[level].timeFinished = (int) MyTime.getInstance().getTime();
                try {
                    long totalPrize = controller.ResetLevel();
                    Log.logCompile("The Rest of the level is done","info");
                    System.out.println("Congratulations! You finished this level.\nYour prize : "+ totalPrize);
                    System.out.println("Please back to main menu.");
                    if (this.level==4)
                        System.out.println("The Game is finished.\nWe hope you enjoy this game.");
                } catch (CloneNotSupportedException e) {
                    e.printStackTrace();
                }
            }
        }
        nextMenu=this.parentMenu;
        nextMenu.show();
        nextMenu.execute();
    }
}
