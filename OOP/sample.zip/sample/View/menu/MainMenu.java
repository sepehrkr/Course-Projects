package sample.View.menu;

import  sample.Controller.*;
import  sample.View.Color;
import  sample.View.InputCommand;
import  sample.View.OutputProcessor;
import  sample.View.menu.Menu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.regex.Matcher;

public class MainMenu extends Menu {

    public MainMenu(String name , Menu parentMenu , Scanner scanner) {
        super(name,parentMenu,scanner);
        this.subMenus.add(new GameMenu("Game Menu",this,scanner));   // index 0
        //this.subMenus.add(new SettingMenu("Setting",this));  // index 1
    }

    @Override
    void show() {
        System.out.println(Color.TEXT_BLUE.getColor()+this.name+" :"+Color.TEXT_RESET.getColor());
        System.out.println(Color.TEXT_BLUE.getColor()+"Start [level]"+Color.TEXT_RESET.getColor());
        System.out.println(Color.TEXT_BLUE.getColor()+"Setting"+Color.TEXT_RESET.getColor());
        System.out.println(Color.TEXT_BLUE.getColor()+"log out"+Color.TEXT_RESET.getColor());
    }

    @Override
    void execute() {
        Log.logCompile("We are in Main Menu","info");
        Menu nextMenu;
        String command;
        while (true){
            Matcher matcher;
            command=scanner.nextLine().trim().toLowerCase();
            if ((matcher=InputCommand.START.getMatcher(command)).matches()){
                boolean truth=false;
                switch (Controller.getInstance().checkLevelForStart(Integer.parseInt(matcher.group(1))-1)){
                    case "the first try for level 1":
                        ((GameMenu) this.subMenus.get(0)).level = 0;
                        Controller.getInstance().currentLevel=0;
                        nextMenu = this.subMenus.get(0);
                        Log.logCompile("User want to start Level 1","info");
                        truth=true;
                        break;
                    case "the first try for level [stage]":
                    case "again level" :
                        ((GameMenu) this.subMenus.get(0)).level = Integer.parseInt(matcher.group(1))-1;
                        Controller.getInstance().currentLevel=Integer.parseInt(matcher.group(1))-1;
                        nextMenu = this.subMenus.get(0);
                        Log.logCompile("User want to Start Level "+Integer.toString(Integer.parseInt(matcher.group(1))-1),"info");
                        truth=true;
                        break;
                    case "incorrect level":
                        OutputProcessor.getInstance().printError("You can't start this level!");
                        Log.logCompile("The User can't start from this Level!","error");
                        break;
                    case "invalid":
                        OutputProcessor.getInstance().printError("INVALID INPUT");
                        Log.logCompile("INVALID INPUT  in starting Level","error");
                        break;
                }
                if (truth){
                    nextMenu=subMenus.get(0);
                    Log.logCompile("Going to Game Menu for Level "+Integer.toString(Integer.parseInt(matcher.group(1))-1),"info");
                    break;
                }
            } else if (command.equals("setting")){
                nextMenu = this.subMenus.get(1);
                Log.logCompile("User want to go Setting menu","info");
                break;
            } else if (command.equals("log out")){
                Controller.getInstance().saveGame();
                Controller.saveUsers();
                try {
                    Controller.getInstance().ResetLevel();

                } catch (CloneNotSupportedException e) {
                    e.printStackTrace();
                }
                nextMenu=this.parentMenu;
                Log.logCompile("User log out of his/her account But Game saved","info");
                break;
            } else {
                System.out.println(Color.TEXT_RED.getColor()+"INVALID INPUT!"+Color.TEXT_RESET.getColor());
                Log.logCompile("INVALID INPUT in Main Menu!","error");
            }
        }
        nextMenu.show();
        nextMenu.execute();
    }
}
