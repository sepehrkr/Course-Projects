package sample.View.menu;

import  sample.View.Color;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public abstract class Menu {
    String name;
    Menu parentMenu=null;
    ArrayList<Menu> subMenus;
    Scanner scanner;
    public Menu(String name, Menu parentMenu, Scanner scanner) {
        this.name = name;
        this.parentMenu = parentMenu;
        this.scanner=scanner;
        this.subMenus=new ArrayList<>();
    }

    public Menu(Menu parentMenu ,Scanner scanner) {
        this.parentMenu = parentMenu;
        this.scanner = scanner;
        this.subMenus=new ArrayList<>();
    }

    public Menu(String name ,Scanner scanner) {
        this.name = name;
        this.scanner=scanner;
        this.subMenus=new ArrayList<>();
    }
    void show ()
    {
        System.out.println(Color.TEXT_PURPLE.getColor()+this.name+": "+Color.TEXT_RESET.getColor());
        for (Menu menu : this.subMenus){
            System.out.println(Color.TEXT_PURPLE.getColor()+menu.name+Color.TEXT_RESET.getColor());
        }
        if (this.parentMenu!=null){
            System.out.println(Color.TEXT_PURPLE.getColor()+"back"+Color.TEXT_RESET.getColor());
        } else {
            System.out.println(Color.TEXT_PURPLE.getColor()+"exit"+Color.TEXT_RESET.getColor());
        }
    }
    abstract void execute ();

}
