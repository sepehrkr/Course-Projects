package sample.View.menu;

import  sample.Controller.*;
import  sample.Model.Person;
import  sample.View.Color;

import java.util.ArrayList;
import java.util.Scanner;

public class SignIn extends Menu{
    MainMenu mainMenu;
    Person person;
    public SignIn(String name, Menu parentMenu, Scanner scanner , MainMenu mainMenu) {
        super(name, parentMenu, scanner);
        this.mainMenu=mainMenu;
    }

    @Override
    void show() {
        System.out.println(Color.TEXT_PURPLE.getColor()+this.name+" :"+Color.TEXT_RESET.getColor());
    }

    @Override
    void execute() {
        Controller.readPerson();
        Menu nextMenu;
        String username;
        String password;
        System.out.print("Username : ");
        username=scanner.nextLine();
        System.out.print("Password : ");
        password=scanner.nextLine();
        while (Controller.getPerson(username,password)==null){
            System.out.println(Color.TEXT_RED.getColor()+"Username or password is not correct!\nPlease do your Authentication again."+Color.TEXT_RESET.getColor());
            System.out.print("Username : ");
            username=scanner.nextLine();
            System.out.print("Password : ");
            password=scanner.nextLine();
        }
        this.person = Controller.getPerson(username,password) ;
        Log.initialize(this.person);
        Log.logCompile("Signing in is successful.","info");
        Controller.getInstance().initializeMission(Controller.getPerson(username,password));
        Log.logCompile("Reading Mission List from file","info");
        System.out.println("Your Authentication is successful.\nWelcome to the Farm Frenzy 3");
        nextMenu=mainMenu;
        mainMenu.show();
        mainMenu.execute();
    }
}
