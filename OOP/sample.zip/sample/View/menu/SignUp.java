package sample.View.menu;

import  sample.Controller.*;
import  sample.View.Color;

import java.util.Scanner;
import java.util.logging.Logger;

public class SignUp extends Menu{
    MainMenu mainMenu;
    public SignUp(String name, Menu parentMenu, Scanner scanner , MainMenu mainMenu) {
        super(name, parentMenu, scanner);
        this.mainMenu=mainMenu;
    }

    @Override
    void show() {
        System.out.println(Color.TEXT_BLUE.getColor()+this.name+" :"+Color.TEXT_RESET.getColor());
    }

    @Override
    void execute() {
        Controller.readPerson();
        Menu nextMenu;
        System.out.print("Username : ");
        String username = scanner.nextLine();
        System.out.print("Password : ");
        String password=scanner.nextLine();
        while (!Controller.addPerson(username,password)){
            System.out.println(Color.TEXT_RED.getColor()+"Your username or password is already token!\nPlease do your registration again."+Color.TEXT_RESET.getColor());
            System.out.print("Username : ");
            username = scanner.nextLine();
            System.out.print("Password : ");
            password=scanner.nextLine();
        }
        Controller.getInstance().doRegistration();
        Log.initialize(Controller.users.get(Controller.users.size()-1));
        Log.logCompile("The Signing up is successful","info");
        nextMenu=mainMenu;
        nextMenu.show();
        nextMenu.execute();
    }
}
