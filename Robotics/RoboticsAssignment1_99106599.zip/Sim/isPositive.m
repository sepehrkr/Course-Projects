function y = isPositive(A)
    try chol(A)
        y = 1;
    catch ME
        y = 0;
    end
end

