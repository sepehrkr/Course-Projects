%%
clear; clc; close all;
robot = rigidBodyTree;
q = [0,pi/2,0,0,0,0]; % This can be changed for different robot configuration
dhparams = [0,0,0,q(1);
            0,pi/2,0.396,pi/2;
            0.324,0,0,q(2);
            0,pi/2,0,q(3)+pi/2;
            0,pi/2,0.343,pi+q(4);
            0,pi/2,0,pi/2+q(5)];

field1 = 'JointName';
field2 = 'JointPosition';
val1 = {'joint1','joint2','joint3','joint4','joint5','joint6'};
val2 = {q(1),pi/2,q(2),q(3)+pi/2,pi+q(4),pi/2+q(5)};
%val1 = {'joint1','joint2'};
%val2 = {0,pi/2};
config = struct(field1,val1,field2,val2);
body1 = rigidBody('body1');
joint1 = rigidBodyJoint('joint1','revolute');
joint1.JointAxis = [0,0,1];
joint1.HomePosition = 0;
setFixedTransform(joint1,dhparams(1,:),'dh');
body1.Joint = joint1;
body1.Mass = 10;
addBody(robot,body1,'base');

body2 = rigidBody('body2');
joint2 = rigidBodyJoint('joint2','revolute');
joint2.JointAxis = [0,0,1];
joint2.HomePosition = 0;
setFixedTransform(joint2,dhparams(2,:),'dh');
body2.Joint = joint2;
addBody(robot,body2,'body1');
body2.Mass = 10;

body3 = rigidBody('body3');
joint3 = rigidBodyJoint('joint3','revolute');
joint3.JointAxis = [0,0,1];
joint3.HomePosition = 0;
setFixedTransform(joint3,dhparams(3,:),'dh');
body3.Joint = joint3;
addBody(robot,body3,'body2');
body3.Mass = 10;

body4 = rigidBody('body4');
joint4 = rigidBodyJoint('joint4','revolute');
joint4.JointAxis = [0,0,1];
joint4.HomePosition = 0;
setFixedTransform(joint4,dhparams(4,:),'dh');
body4.Joint = joint4;
addBody(robot,body4,'body3');
body4.Mass = 5;

body5 = rigidBody('body5');
joint5 = rigidBodyJoint('joint5','revolute');
joint5.JointAxis = [0,0,1];
joint5.HomePosition = 0;
setFixedTransform(joint5,dhparams(5,:),'dh');
body5.Joint = joint5;
addBody(robot,body5,'body4');
body5.Mass = 5;

body6 = rigidBody('body6');
joint6 = rigidBodyJoint('joint6','revolute');
joint6.JointAxis = [0,0,1];
joint6.HomePosition = 0;
setFixedTransform(joint6,dhparams(6,:),'dh');
body6.Joint = joint6;
addBody(robot,body6,'body5');
body6.Mass = 5;

showdetails(robot);

figure;
show(robot,config,'Collisions','off','Visuals','on');

A1 = DH1(0,0,q(1),0);
A2 = DH1(0,pi/2,pi/2,0.396);
A3 = DH1(0.324,0,q(2),0);
A4 = DH1(0,pi/2,q(3)+pi/2,0);
A5 = DH1(0,pi/2,pi+q(4),0.343);
A6 = DH1(0,pi/2,pi/2+q(5),0);
H1_0= A1;
H2_0= A1*A2;
H3_0= A1*A2*A3;
H4_0= A1*A2*A3*A4;
H5_0= A1*A2*A3*A4*A5;
H6_0= A1*A2*A3*A4*A5*A6;
display(H6_0);

J = zeros(6,6);
J(4:6,1) = cross([0;0;1],(H6_0(1:3,4)-zeros(3,1)));
J(4:6,2) = cross(H1_0(1:3,3),(H6_0(1:3,4)-H1_0(1:3,4)));
J(4:6,3) = cross(H2_0(1:3,3),(H6_0(1:3,4)-H2_0(1:3,4)));
J(4:6,4) = cross(H3_0(1:3,3),(H6_0(1:3,4)-H3_0(1:3,4)));
J(4:6,5) = cross(H4_0(1:3,3),(H6_0(1:3,4)-H4_0(1:3,4)));
J(4:6,6) = cross(H5_0(1:3,3),(H6_0(1:3,4)-H5_0(1:3,4)));

J(1:3,1) = [0;0;1];
J(1:3,2) = H1_0(1:3,3);
J(1:3,3) = H2_0(1:3,3);
J(1:3,4) = H3_0(1:3,3);
J(1:3,5) = H4_0(1:3,3);
J(1:3,6) = H5_0(1:3,3);
display(J);

% Compute J1,...,J6 with recpect to central math and then compute generelaized J
% Only J4,J6 need to be change because DH and CM origins for other links are the same 
J6 = zeros(6,6);
rcd_6 = -0.165 * H6_0(1:3,3);
    J6(1:3,1) = cross([0;0;1],(H6_0(1:3,4)-zeros(3,1)));
    J6(1:3,2) = cross(H1_0(1:3,3),(H6_0(1:3,4)-H1_0(1:3,4)));
    J6(1:3,3) = cross(H2_0(1:3,3),(H6_0(1:3,4)-H2_0(1:3,4)));
    J6(1:3,4) = cross(H3_0(1:3,3),(H6_0(1:3,4)-H3_0(1:3,4)));
    J6(1:3,5) = cross(H4_0(1:3,3),(H6_0(1:3,4)-H4_0(1:3,4)));
    J6(1:3,6) = cross(H5_0(1:3,3),(H6_0(1:3,4)-H5_0(1:3,4)));
    J6(4:6,1) = [0;0;1];
    J6(4:6,2) = H1_0(1:3,3);
    J6(4:6,3) = H2_0(1:3,3);
    J6(4:6,4) = H3_0(1:3,3);
    J6(4:6,5) = H4_0(1:3,3);
    J6(4:6,6) = H5_0(1:3,3);
    J6 = [eye(3),[0,-rcd_6(3),rcd_6(2);rcd_6(3),0,-rcd_6(1);-rcd_6(2),rcd_6(1),0];zeros(3),eye(3)] * J6;

    J5 = zeros(6,6);
    J5(1:3,1) = cross([0;0;1],(H5_0(1:3,4)-zeros(3,1)));
    J5(1:3,2) = cross(H1_0(1:3,3),(H5_0(1:3,4)-H1_0(1:3,4)));
    J5(1:3,3) = cross(H2_0(1:3,3),(H5_0(1:3,4)-H2_0(1:3,4)));
    J5(1:3,4) = cross(H3_0(1:3,3),(H5_0(1:3,4)-H3_0(1:3,4)));
    J5(1:3,5) = cross(H4_0(1:3,3),(H5_0(1:3,4)-H4_0(1:3,4)));
    J5(1:3,6) = [0;0;0];
    J5(4:6,1) = [0;0;1];
    J5(4:6,2) = H1_0(1:3,3);
    J5(4:6,3) = H2_0(1:3,3);
    J5(4:6,4) = H3_0(1:3,3);
    J5(4:6,5) = H4_0(1:3,3);
    J5(4:6,6) = [0;0;0];
    
    J4 = zeros(6,6);
    rcd_4 = -0.343 * H4_0(1:3,3);
    J4(1:3,1) = cross([0;0;1],(H4_0(1:3,4)-zeros(3,1)));
    J4(1:3,2) = cross(H1_0(1:3,3),(H4_0(1:3,4)-H1_0(1:3,4)));
    J4(1:3,3) = cross(H2_0(1:3,3),(H4_0(1:3,4)-H2_0(1:3,4)));
    J4(1:3,4) = cross(H3_0(1:3,3),(H4_0(1:3,4)-H3_0(1:3,4)));
    J4(1:3,5) = [0;0;0];
    J4(1:3,6) = [0;0;0];
    J4(4:6,1) = [0;0;1];
    J4(4:6,2) = H1_0(1:3,3);
    J4(4:6,3) = H2_0(1:3,3);
    J4(4:6,4) = H3_0(1:3,3);
    J4(4:6,5) = [0;0;0];
    J4(4:6,6) = [0;0;0];
    J4 = [eye(3),[0,-rcd_4(3),rcd_4(2);rcd_4(3),0,-rcd_4(1);-rcd_4(2),rcd_4(1),0];zeros(3),eye(3)] * J4;

    J3 = zeros(6,6);
    J3(1:3,1) = cross([0;0;1],(H3_0(1:3,4)-zeros(3,1)));
    J3(1:3,2) = cross(H1_0(1:3,3),(H3_0(1:3,4)-H1_0(1:3,4)));
    J3(1:3,3) = cross(H2_0(1:3,3),(H3_0(1:3,4)-H2_0(1:3,4)));
    J3(1:3,4) = [0;0;0];
    J3(1:3,5) = [0;0;0];
    J3(1:3,6) = [0;0;0];
    J3(4:6,1) = [0;0;1];
    J3(4:6,2) = H1_0(1:3,3);
    J3(4:6,3) = H2_0(1:3,3);
    J3(4:6,4) = [0;0;0];
    J3(4:6,5) = [0;0;0];
    J3(4:6,6) = [0;0;0];

    J2 = zeros(6,6);
    J2(1:3,1) = cross([0;0;1],(H2_0(1:3,4)-zeros(3,1)));
    J2(1:3,2) = cross(H1_0(1:3,3),(H2_0(1:3,4)-H1_0(1:3,4)));
    J2(1:3,3) = [0;0;0];
    J2(1:3,4) = [0;0;0];
    J2(1:3,5) = [0;0;0];
    J2(1:3,6) = [0;0;0];
    J2(4:6,1) = [0;0;1];
    J2(4:6,2) = H1_0(1:3,3);
    J2(4:6,3) = [0;0;0];
    J2(4:6,4) = [0;0;0];
    J2(4:6,5) = [0;0;0];
    J2(4:6,6) = [0;0;0];

    J1 = zeros(6,6);
    J1(1:3,1) = cross([0;0;1],(H1_0(1:3,4)-zeros(3,1)));
    J1(1:3,2) = [0;0;0];
    J1(1:3,3) = [0;0;0];
    J1(1:3,4) = [0;0;0];
    J1(1:3,5) = [0;0;0];
    J1(1:3,6) = [0;0;0];
    J1(4:6,1) = [0;0;1];
    J1(4:6,2) = [0;0;0];
    J1(4:6,3) = [0;0;0];
    J1(4:6,4) = [0;0;0];
    J1(4:6,5) = [0;0;0];
    J1(4:6,6) = [0;0;0];

    %J_generelaized = [J1(1:3,:);J2(1:3,:);J3(1:3,:);J4(1:3,:);J5(1:3,:);J6(1:3,:);H1_0(1:3,1:3)/J1(4:6,:);H2_0(1:3,1:3)/J2(4:6,:);H3_0(1:3,1:3)/J3(4:6,:);H4_0(1:3,1:3)/J4(4:6,:);H5_0(1:3,1:3)/J5(4:6,:);H6_0(1:3,1:3)/J6(4:6,:)];
    J_generelaized = [J1(1:3,:);J2(1:3,:);J3(1:3,:);J4(1:3,:);J5(1:3,:);J6(1:3,:);inv(H1_0(1:3,1:3))*J1(4:6,:);inv(H2_0(1:3,1:3))*J2(4:6,:);inv(H3_0(1:3,1:3))*J3(4:6,:);inv(H4_0(1:3,1:3))*J4(4:6,:);inv(H5_0(1:3,1:3))*J5(4:6,:);inv(H6_0(1:3,1:3))*J6(4:6,:)];



















